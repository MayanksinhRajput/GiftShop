
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" dir="ltr">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <title>Online Gifts Delivery: Buy/Send Gifts to India, Unique Gift Shop</title>
    <meta name="description" content="Send Gifts to India from USA &amp; Worldwide FREE SHIPPING. IGP #1 online gift shop offers fresh flowers, cakes, customized gifts delivery in India. Get unique gift ideas for family &amp; friends. Easy &amp; fast gift delivery anywhere in India." />
    <meta name="keywords" content="online gifts, online gift delivery, buy gifts online, online gift shop, send gifts, gifts to india, indian gift portal, indian gifts, send gifts to india, send gifts online, same day delivery, gift items online shopping, unique gifts online india, online gift shopping sites, best online gift sites, online shopping gift items, gift items online india, cheap gifts online, online gifts delivery in one day, online gift shopping, gift store" />
    <link rel="canonical" href="https://www.igp.com" />
    
    <!---->
    
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="shortcut icon" href="https://cdn.igp.com/raw/upload/assets/images/favicon_5.ico?v=3" />
    <link href="https://cdn.igp.com/" rel="dns-prefetch" />
    
        <meta name="msvalidate.01" content="FFED38B784DA01215043EAF8F639131B" />
        <meta name="p:domain_verify" content="b68f2e70e71f41aa9fc8641c1d6045e7"/>
        <p id="appType" style="display: none;">desktop</p>
        <p id="userIp" style="display: none;">116.73.220.67</p>
        <p id="userCountry" style="display: none;">IN</p>
    <meta name="google-site-verification" content="HmDF1RZFLzvu7X4pe1W0uGObpHiP_qcPubN1pKMN2NI" />    
    <!-- Facebook META -->
    <meta property="fb:app_id" content="129038544454551" />
    <meta property="og:title" content="Online Gifts Delivery: Buy/Send Gifts to India, Unique Gift Shop" />
    <meta property="og:type" content="website" />
    <meta property="og:url" content="https://www.igp.com" />
    <meta property="og:description" content="Send Gifts to India from USA &amp; Worldwide FREE SHIPPING. IGP #1 online gift shop offers fresh flowers, cakes, customized gifts delivery in India. Get unique gift ideas for family &amp; friends. Easy &amp; fast gift delivery anywhere in India."/>
    <meta property="og:site_name" content="IGP.com"/>
                <meta property="og:image" content="https://cdn.igp.com/assets/images/igp-ograph-20211227.png" />
    
    <meta name="twitter:card" content="summary" />
    <meta name="twitter:title" content="Online Gifts Delivery: Buy/Send Gifts to India, Unique Gift Shop" />
                <meta property="twitter:image" content="https://cdn.igp.com/assets/images/igp-ograph-20211227.png" />
    <meta property="twitter:url" content="https://www.igp.com" />
    <meta property="twitter:description" content="Send Gifts to India from USA &amp; Worldwide FREE SHIPPING. IGP #1 online gift shop offers fresh flowers, cakes, customized gifts delivery in India. Get unique gift ideas for family &amp; friends. Easy &amp; fast gift delivery anywhere in India."/>
    <meta name="twitter:site" content="@IGPcom"/>
    <meta name="twitter:creator" content="@IGPcom"/>
    <style>
        .ie-mask-layer{display: none;}
        #add-ons .slick-next:before {
            content:none;
        }
         #add-ons .slick-next:hover, #add-ons .slick-prev:hover  {
             background-color: #000;
         }
        #add-ons .slick-prev:before {
            content:none;
        }
        </style>
                        

    <!--[if IE]>
        <style>
            .ie-mask-layer{
                display: block;position: fixed;  background: #f2f2f2;  z-index: 99999;  top: 0;  left: 0;  bottom: 0;  right: 0;  display: flex;  justify-content: center;  font-size: 2em;  align-items: center;  font-weight: normal;  color: #c3404e;  text-align: center;  line-height: 2em;
            }
            .ie-mask-layer > img.img-responsive{
                width: 70%;
            }
        </style>
    <![endif]-->
            <style>
            @font-face {
                font-family: "PTSerif-Bold";
                font-display: swap;
                src: url("https://cdn.igp.com/raw/upload/v1640245880/assets/fonts/PTSerif-Bold.ttf") format("truetype");
            }
            @font-face {
                font-family: "Kalam";
                font-display: swap;
                src: url("https://cdn.igp.com/raw/upload/v1640873553/assets/fonts/Kalam-Light.ttf") format("truetype");
            }
        </style>

    <!-- For Store 83 (Added by chetan 7/6/2018) -->
    <!--     -->
    <!-- CSS Includes -->
    <style>
    /* Business page font */
    @font-face {
        font-family: 'intro';
        src: url('/fonts/intro.eot');
        src: url('/fonts/WorkSans-Regular.eot?#iefix') format('embedded-opentype'),
        url('/fonts/intro.eot') format('woff'),
        url('/fonts/intro.eot') format('truetype');
        font-weight: 100;
        font-style: normal;
    }
    /* Ends */
    </style>
    <!-- Google Web Font - Grand Hotel - Font Weights : 4000 -->
    <!--<link href='https://fonts.googleapis.com/css?family=Grand+Hotel' rel='stylesheet' type='text/css'>-->
    <!-- Google Web Font - Montserrat - Font Weights : 400,700 -->
    <!--<link href="https://fonts.googleapis.com/css?family=Montserrat:500,700" rel="stylesheet">-->

    <!--fonts loading through javaScript to improve pagespeed-->
    <script type="text/javascript">
      WebFontConfig = {
        google: { families: [ 'Grand+Hotel:400:latin', 'Montserrat:500,700:latin' ] }
      };
      (function() {
        var wf = document.createElement('script');
        wf.src = ('https:' == document.location.protocol ? 'https' : 'http') +
          '://ajax.googleapis.com/ajax/libs/webfont/1.5.18/webfont.js';
        wf.type = 'text/javascript';
        wf.async = 'true';
        var s = document.getElementsByTagName('script')[0];
        s.parentNode.insertBefore(wf, s);
      })();
    </script>
    <!--fonts loading through javaScript to improve pagespeed-->

    <!--css from hbs widgets-->

    <!-- css form hbswidgets ends-->
            <link rel="stylesheet" href="https://cdn.igp.com/raw/upload/assets/passets/css/baseHomeCSS-311.css" type="text/css">
            <link rel="stylesheet" href="https://cdn.igp.com/raw/upload/assets/passets/css/homeCSS-429.css" type="text/css">

    <link rel="search" type="application/opensearchdescription+xml" title="IGP.com" href="/igosd_5.xml" />
    <script src="https://cdn.trackjs.com/agent/v3/latest/t.js"></script>
    <script>
        window.TrackJS && TrackJS.install({ 
            token: "e570e48dad30483b86fce1356e712252"
            // for more configuration options, see https://docs.trackjs.com
        });
    </script>
    <script>
        if(window.navigator.appVersion.toLocaleLowerCase().indexOf('win') > -1) {
            document.getElementsByTagName('html')[0].classList.add('win');
        }
    </script>
</head>
<body data-pers="0"   data-pagetype="" data-show_reco="" data-reco_d="" data-personalisedbackward="" data-page="" data-type-two="" class="content-wrapper     desktop  " data-cdn-url="https://cdn.igp.com/"
      data-cdn="{&quot;assetsBaseURL&quot;:&quot;https://cdn.igp.com/&quot;,&quot;assetsURL&quot;:&quot;https://cdn.igp.com/raw/upload/assets/&quot;,&quot;bannersURL&quot;:&quot;https://cdn.igp.com/f_auto,q_auto,t_pnoptprodlp/banners/&quot;,&quot;bannersOLDURL&quot;:&quot;https://cdn.igp.com/f_auto,q_auto/banners/&quot;,&quot;inPageBannersURLD&quot;:&quot;https://cdn.igp.com/f_auto,q_auto/banners/&quot;,&quot;inPageBannersURLM&quot;:&quot;https://cdn.igp.com/f_auto,q_auto/banners/&quot;,&quot;bannersURLTMres&quot;:&quot;https://cdn.igp.com/f_auto,q_auto,t_mres/banners/&quot;,&quot;cardsURL&quot;:&quot;https://cdn.igp.com/f_auto,q_auto/cards/&quot;,&quot;cardsURLTMres&quot;:&quot;https://cdn.igp.com/f_auto,q_auto,t_mres/cards/&quot;,&quot;productsURL&quot;:&quot;https://cdn.igp.com/&quot;,&quot;productsURLTransformationF&quot;:&quot;f_auto,q_auto,t_prodf/&quot;,&quot;productsURLTransformationL&quot;:&quot;f_auto,q_auto,t_prodl/&quot;,&quot;productsURLTransformationM&quot;:&quot;f_auto,q_auto,t_prodm/&quot;,&quot;productsURLTransformationMEco&quot;:&quot;f_auto,q_auto,t_prodm/&quot;,&quot;productsURLTransformationTH&quot;:&quot;f_auto,q_auto,t_prodth/&quot;,&quot;productsURLTransformationFNew&quot;:&quot;f_auto,q_auto,t_pnoptprodlp/&quot;,&quot;productsURLTransformationLNew&quot;:&quot;f_auto,q_auto,t_pnoptprodlp/&quot;,&quot;productsURLTransformationMNew&quot;:&quot;f_auto,q_auto,t_pnoptprodlp/&quot;,&quot;productsURLTransformationMEcoNew&quot;:&quot;f_auto,q_auto,t_pnoptprodlp/&quot;,&quot;productsURLTransformationTHNew&quot;:&quot;f_auto,q_auto,t_pnoptprodlp/&quot;,&quot;productsURLBestSellerFlag&quot;:&quot;g_south_east,l_tag&quot;,&quot;blogImageURL&quot;:&quot;f_auto,q_auto,t_blogcard/blogs/&quot;,&quot;productsURLFolder1&quot;:&quot;products/&quot;,&quot;persURL&quot;:&quot;https://d1xs5fw35mbn8b.cloudfront.net/pers/&quot;,&quot;videoURLTransformationTH&quot;:&quot;video/upload/q_auto,t_vth/&quot;,&quot;videoURLTransformationL&quot;:&quot;video/upload/q_auto,t_prodl/&quot;,&quot;videoURLWatermark&quot;:&quot;video/upload/t_vrw&quot;,&quot;videoURLWatermarkReview&quot;:&quot;video/upload/q_auto:low&quot;,&quot;videoURL&quot;:&quot;video/upload/t_vdl&quot;,&quot;video_bannser_URL&quot;:&quot;https://cdn.igp.com/video/upload/f_auto,q_auto/banners/&quot;,&quot;ccsBanner&quot;:&quot;f_auto,q_auto,t_ccstp/banners/&quot;,&quot;showcaseNanner&quot;:&quot;f_auto,q_auto,t_cathprect/banners/&quot;}" data-skipsimilargifts = "" data-device="desktop" data-stid="5" data-selectedcurrency="INR"  data-hidechat="1" >

<!--Just for testing -->
<!-- Google Tag Manager -->
<noscript><iframe src="//www.googletagmanager.com/ns.html?id=GTM-K992H8" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript><script>var pgtype=''; var type=''; var type2='';var rec=''; var rel=''; var occ=''; var per=''; var country_city=''; var cat=''; var sub_cat=''; var prod_type=''; var currentURL =window.location.pathname; if(currentURL === '/'){pgtype = 'home';} if(currentURL === '/cart'){pgtype = 'cart';} if(currentURL === '/checkout'){pgtype = 'checkout';} dataLayer = [];(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'pagetype':pgtype,'gtm.start':new Date().getTime(),event:'gtm.js','type':type ,'type2':type2,'rec':rec,'rel':rel,'occ':occ,'per':per,'cat':cat,'sub_cat':sub_cat,'prod_type':prod_type,'country_city':country_city});var f=d.getElementsByTagName(s)[0],j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.defer=true;j.src='//www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);})(window,document,'script','dataLayer','GTM-K992H8');</script>
<!-- End Google Tag Manager -->
<!-- Site Wrapper begins -->
    
    <div class="header-container  " >
    <div class="ab_trkOrdr hidden">default</div>
        <header class="bg-red   " id="header">
            <div class="row no-margin">
                <div class="col s2 text-center">
                    <a href="/" class="logo-wrapper" tabindex="1" onclick="onclickDataLayer('logo_click')">
                        <img class="img-responsive logo" src="https://cdn.igp.com/raw/upload/assets/images/igp-logo.png?v=6" alt="IGP Gifts India"/>
                    </a>
                </div>
                <div class="col s7">
                    &nbsp;

                    <div class=" search-bar-wrapper morphsearch       " id="morphsearch">
                        <form class="morphsearch-form igp-header-form" id="search-products" action="/search">
                            <input type="text" name="q" placeholder="Search..." class="search-bar m-t-5 p-l-10 p-r-10 morphsearch-input"
                                   value="" autocomplete="off" maxlength="50">
                            <div class="icon-wrapper search-icon-wrapper">
                                <img alt ="Search icon" class="img-responsive" src="https://cdn.igp.com/raw/upload/assets/svg-icons/header-search.svg"></img>
                            </div>
                        </form>

                        <div class="morphsearch-content"></div>
                        <div class="autocomplete-section"></div>
                        <a href="javascript:void(0)"><span class="morphsearch-close"></span></a>
                    </div>

                </div>

                    <div class="col s3 padding-right-0">
                        <div class="row no-margin top-actions-menu">



                                <a title="Currency" class="col t2 top-action-col currency-icon waves-effect">
                                    <div class="icon-wrapper top-action-icons quick-menu">

                                                    <img alt ="INR" class="img-responsive" src="https://cdn.igp.com/raw/upload/assets/svg-icons/Rupee-big.svg"></img>
                                    </div>
                                </a>

                                <div class="currency-container z-depth-1">
                                    <div class="relative">
                                        <div class="arrow-wrapper"></div>
                                        <div class="currency-list">
                                            <ul>
                                                <li data-value="INR" class="currency-change selected">INR</li>
                                                <li data-value="USD" class="currency-change ">USD</li>
                                                <li data-value="CAD" class="currency-change ">CAD</li>
                                                <li data-value="GBP" class="currency-change ">GBP</li>
                                                <li data-value="AED" class="currency-change ">AED</li>
                                                <li data-value="AUD" class="currency-change ">AUD</li>
                                                <li data-value="NZD" class="currency-change ">NZD</li>
                                                <li data-value="SGD" class="currency-change ">SGD</li>
                                                <li data-value="EUR" class="currency-change ">EUR</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>

                            <a title="Track Order" class="col t2 top-action-col dial-pad waves-effect">
                                <div class="icon-wrapper top-action-icons quick-menu">
                                    <img alt ="Track" class="img-responsive" src="https://cdn.igp.com/raw/upload/assets/svg-icons/Track-big.svg"></img>
                                </div>

                            </a>


                                    <a title="Shortlist" class="col t2 top-action-col slist-wrapper waves-effect">
                                        <div class="icon-wrapper top-action-icons sl-top-icon quick-menu">
                                            <img alt ="Heart" class="img-responsive" src="https://cdn.igp.com/raw/upload/assets/svg-icons/heart-2.svg"></img>
                                        </div>
                                        <span class="sl-count">0</span>
                                    </a>

                                <a title="Cart" href="/cart" class="col t2 top-action-col s-cart waves-effect">
                                    <div class="icon-wrapper top-action-icons quick-menu">
                                        <img alt ="Cart" class="img-responsive" src="https://cdn.igp.com/raw/upload/assets/svg-icons/Cart-big.svg"></img>
                                    </div>
                                    <span class="number cart-count">0</span>
                                </a>


                            <a title="Account" class="col t2 top-action-col waves-effect user-menu" id="user-menu">
                                <div class="icon-wrapper top-action-icons quick-menu" >
                                        <img alt ="Profile" class="img-responsive" src="https://cdn.igp.com/raw/upload/assets/svg-icons/Profile-big.svg"></img>                                            
                                </div>
                            </a>
                        </div>
                    </div>
            </div>
            <div class="searched-text-container hide">
                <div id="searched-Items" class="search-suggest-items true igp-suggestedItems old-igp-header">
                    <div class="prod-card-search-suggestions">
                    </div>              
                </div>
            </div>
        </header>
        <div class="row no-margin bg-dark-red sec-header">
            <div class="col s12 text-right">
                    <ul>
                        <li class="sec-menu-item">
                            Quickly Go To:
                        </li>
                        <li class="sec-menu-item"><a href="/birthday-gifts">Birthday Gifts</a></li>
                        <li class="sec-menu-item"><a href="/sweets">Sweets</a></li>
                        <li class="sec-menu-item"><a href="/corporate-gifts">Bulk/Corporate Gifts</a></li>
                    </ul>
            </div>
        </div>
    </div>

            <div id="newMegaMenuTemplate" data-isHome="true" data-isNotFound = "" data-sbi_omp_flag = "false">
                <div class="gc-mm-wrapper   " id="gc-mm-wrapper">
    <div class="gc-flex gc-mm-header">
        <div class="gc-icon-col gc-icon-closed">
            <div class="icon-wrapper gc-header-icon igp-hamburger-icon">
                <img class="img-responsive" alt="hamburger img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/hamburger.svg"></img>
            </div>
        </div>

        <div class="gc-icon-col gc-icon-open">
            <div class="close-mm-icon">
                &#x2715;
            </div>
        </div>
        <div class="gc-text-col">
                <div style="display: inline-block;">Browse&nbsp;</div><h1 itemprop="name" style="display: inline-block; font-size: 1em;" >Gifts</h1>
        </div>
    </div>


</div>

            </div>


    <div id="dialpad-content" class="dialpad-content z-depth-1" style="width:45em;">
        <div class="relative">
            <div class="arrow-wrapper" style="left:55%">

            </div>
            <div class="title-area z-depth-1">
                <h6 class="u-case">Customer Care &amp; Support</h6>
            </div>
            <div class="content-area">
                <div class="row no-margin flex-disp">

                    <div class="col t2 text-center " style="width:25%">
                        <a href="/searchorder" onclick="onclickDataLayer('track_order', {'trigger': 'Header'})">
                            <div class="contact-inner flex-column-center complete-height">

                                <div class="icon-wrapper">
                                    <img alt ="Track" class="img-responsive" src="https://cdn.igp.com/raw/upload/assets/svg-icons/track.svg"></img>                                    
                                </div>
                                <p class="no-margin flex-column-center flex-row-grow text-light-black">Track
                                    Order</p>
                            </div>
                        </a>
                    </div>

                    <div class="col t2 text-center" style="width:25%">
                        <a href="/faq">
                            <div class="contact-inner flex-column-center complete-height">

                                <div class="icon-wrapper">
                                    <img alt ="Help" class="img-responsive s-icon dialpad-icon dialpad-i-content" src="https://cdn.igp.com/raw/upload/assets/svg-icons/help.svg"></img>
                                </div>
                                <p class="no-margin flex-column-center flex-row-grow text-light-black">Help
                                    &amp; FAQ </p>
                            </div>
                        </a>
                    </div>
                    <div class="col t2 text-center" style="width:25%">
                        <a href="/contact-us">
                            <div class="contact-inner flex-column-center complete-height">
                                <div class="icon-wrapper">
                                    <img alt ="Email" class="img-responsive s-icon dialpad-icon dialpad-i-content" src="https://cdn.igp.com/raw/upload/assets/svg-icons/email.svg"></img>
                                </div>
                                <p class="no-margin flex-column-center flex-row-grow text-light-black">Email
                                    Us </p>
                            </div>
                        </a>
                    </div>
                    <div class=" w-44 col t2 text-center" style="width:25%">
                        <a href="/contact-us">
                            <div class="contact-inner flex-column-center complete-height">
                                <div class="icon-wrapper">
                                    <img alt ="Call" class="img-responsive s-icon dialpad-icon dialpad-i-content" src="https://cdn.igp.com/raw/upload/assets/svg-icons/call.svg"></img>
                                </div>
                                <p class="no-margin flex-column-center flex-row-grow text-light-black">+91-(22) 4343-3333</p>

                            </div>
                        </a>
                    </div>

                </div>
            </div>
        </div>
    </div>


<div class="site-wrapper " id="site-wrapper">
    <div class="site-wrapper-desk" itemscope="" itemtype="http://schema.org/Product">
            <meta itemprop="name" content="Gifts"/>
        <div id="https://www.igp.com" itemtype="https://schema.org/AggregateOffer" itemscope="" itemprop="offers">
            <meta itemprop="offerCount" content="1000" />
            <meta itemprop="priceCurrency" content="INR" />
                <meta itemprop="lowPrice" content="150" />
        </div>
            <!-- Image banner with Text Ends -->
<meta itemprop="name" content="Gifts"/>
<div class="banner-wrapper image-banner" data-bnr="[{&quot;id&quot;:278,&quot;group&quot;:&quot;home&quot;,&quot;slot&quot;:10,&quot;hover&quot;:&quot;holi&quot;,&quot;image&quot;:&quot;holi_banner_20220222.jpg&quot;,&quot;sdate&quot;:&quot;2022-02-22&quot;,&quot;edate&quot;:null,&quot;event&quot;:&quot;holi&quot;,&quot;url&quot;:&quot;/holi&quot;},{&quot;id&quot;:280,&quot;group&quot;:&quot;home&quot;,&quot;slot&quot;:15,&quot;hover&quot;:&quot;personalized-gifts&quot;,&quot;image&quot;:&quot;personalised_gifts_banner_20220309.jpg&quot;,&quot;sdate&quot;:&quot;2022-03-09&quot;,&quot;edate&quot;:null,&quot;event&quot;:&quot;personalized-gifts&quot;,&quot;url&quot;:&quot;/personalized-gifts&quot;},{&quot;id&quot;:281,&quot;group&quot;:&quot;home&quot;,&quot;slot&quot;:40,&quot;hover&quot;:&quot;same-day-delivery-gifts&quot;,&quot;image&quot;:&quot;birthday_gifts_banner_20220311.jpg&quot;,&quot;sdate&quot;:&quot;2022-03-11&quot;,&quot;edate&quot;:null,&quot;event&quot;:&quot;same-day-delivery-gifts&quot;,&quot;url&quot;:&quot;/same-day-delivery-gifts&quot;},{&quot;id&quot;:240,&quot;group&quot;:&quot;home&quot;,&quot;slot&quot;:50,&quot;hover&quot;:&quot;Anniversary Gifts&quot;,&quot;image&quot;:&quot;anniversary_gifts_igp_20211113.jpg&quot;,&quot;sdate&quot;:&quot;2021-11-13&quot;,&quot;edate&quot;:null,&quot;event&quot;:&quot;Anniversary Gifts&quot;,&quot;url&quot;:&quot;/anniversary-gifts&quot;}]">
    <div class="home-banner-carousel row no-margin">
                <div>
        <a target="_blank" href="/holi" onclick="onclickDataLayer('banner_click', {'item_url': 'https://www.igp.com/holi', 'item_name': 'holi', 'banner_category': 'home', 'banner_live_date': '2022-02-22', 'item_position': 1,'micrositename':'' })">
            <div  class="banner-overlay"></div>
            <img class="img-responsive banner-image" alt="holi" data-item_url="/holi" data-item_name="holi" data-banner_category="home" data-banner_live_date="2022-02-22" data-item_position="1" src="https://cdn.igp.com/f_auto,q_auto,t_pnopt25prodlp/banners/holi_banner_20220222.jpg" data-original="https://cdn.igp.com/f_auto,q_auto,t_pnoptprodlp/banners/holi_banner_20220222.jpg" />
        </a>

</div>

    </div>
</div>


<div class="relative">

    <!-- Selection Panel begins -->
    <div class="selection-panel-wrapper bg-dark-new">
        <!-- Interactive Selection Panel Starts -->
        <div id="selection-panel">
            <ul id="selection-panel-list">
                <!--<div class="onboard-container animated bounce">Find the right gift by choosing recipient, relationship &amp; occasion<div class="down-arrow-wrapper"></div></div>-->
                <li class="selection-panel-item close clk" data-selectioncode="gs" id="gs">
                    <div class="selection-icon waves-effect waves-light">
                        <div class="icon-wrapper selection-icon-wrapper">
                            <svg viewBox="0 0 2 2" class="s-icon s-panel-icon">
                                <use xlink:href="/svgs/main_v1.svg#shape-gift-someone"></use>
                            </svg>
                        </div>
                        <p>Find The Perfect Gift</p> <!-- Gifts by Recipient &amp; Occasion-->
                    </div>
                    <div class="selection-menu">
                        <div class="selected-panel">
                            <div><div class="select-opt">SELECT <span class="select">A<br>RECIPIENT</span></div></div>
                        </div>
                        <div class="back-button waves-effect waves-light" data-level="0">
                            <div class="icon-wrapper rec-i-wrapper s-back-icon" data-href="/svgs/main_v1.svg#shape-back">
                            </div>
                            <div class="b-button">
                                Back
                            </div>
                        </div>
                    </div>
                </li>

                <li id="pers-gifts" class="selection-panel-item close waves-effect waves-light" data-url="/personalized-gifts">
                    <a href="/personalized-gifts" onclick="onclickDataLayer('selection_panel_click', { 'item_name': 'Personalized Gifts', 'item_position': 2, 'item_url': 'https://www.igp.com/personalized-gifts'})">
                        <div class="selection-icon ">
                            <div class="icon-wrapper selection-icon-wrapper">
                                <svg viewBox="0 0 2 2" class="s-icon s-panel-icon">
                                    <use xlink:href="/svgs/main_v1.svg#shape-personalised_s_panel"></use>
                                </svg>
                            </div>
                            <p>Personalized Gifts</p>
                        </div>
                    </a>
                </li>
                <li id="holi" class="selection-panel-item close waves-effect waves-light" data-url="/holi">
                    <a href="/holi" onclick="onclickDataLayer('selection_panel_click', { 'item_name': 'holi', 'item_position': 3, 'item_url': 'https://www.igp.com/holi'})">
                        <div class="selection-icon ">
                            <div class="icon-wrapper selection-icon-wrapper">
                                <svg viewBox="0 0 2 2" class="s-icon s-panel-icon">
                                    <use xlink:href="/svgs/main_v1.svg#shape-colors-&-sprays white-01"></use>
                                </svg>
                            </div>
                            <p>Holi</p>
                        </div>
                    </a>
                </li>
                <li id="same-day-delivery-gifts" class="selection-panel-item close waves-effect waves-light" data-url="/same-day-delivery-gifts">
                    <a href="/same-day-delivery-gifts" onclick="onclickDataLayer('selection_panel_click', { 'item_name': 'Same Day Delivery', 'item_position': 4, 'item_url': 'https://www.igp.com/same-day-delivery-gifts'})">
                        <div class="selection-icon ">
                            <div class="icon-wrapper selection-icon-wrapper">
                                <svg viewBox="0 0 2 2" class="s-icon s-panel-icon">
                                    <use xlink:href="/svgs/main_v1.svg#shape-sdd_fest_spw"></use>
                                </svg>
                            </div>
                            <p>Same Day Delivery</p>
                        </div>
                    </a>
                </li>
                <li id="flowers" class="selection-panel-item close waves-effect waves-light" data-url="/flowers">
                    <a href="/flowers" onclick="onclickDataLayer('selection_panel_click', { 'item_name': 'Flowers', 'item_position': 5, 'item_url': 'https://www.igp.com/flowers'})">
                        <div class="selection-icon ">
                            <div class="icon-wrapper selection-icon-wrapper">
                                <svg viewBox="0 0 2 2" class="s-icon s-panel-icon">
                                    <use xlink:href="/svgs/main_v1.svg#shape-flowers-spanel"></use>
                                </svg>
                            </div>
                            <p>Flowers</p>

                        </div>
                    </a>
                </li>
                <li id="cakes" class="selection-panel-item close waves-effect waves-light" data-url="/cakes">
                    <a href="/cakes" onclick="onclickDataLayer('selection_panel_click', { 'item_name': 'Cakes', 'item_position': 6, 'item_url': 'https://www.igp.com/cakes'})">
                        <div class="selection-icon ">
                            <div class="icon-wrapper selection-icon-wrapper">
                                <svg viewBox="0 0 2 2" class="s-icon s-panel-icon">
                                    <use xlink:href="/svgs/main_v1.svg#shape-cakes-2021"></use>
                                </svg>
                            </div>
                            <p>Cakes</p>
                        </div>
                    </a>
                </li>
            </ul>

            <div class="clear"></div>
        </div>
        <!-- Interactive Selection Panel ends -->

        <!-- Selection Panel Card Suggestions Starts-->
        <div class="card-group-wrapper" >
            <ul class="card-group row" id="cards-loader">
                <li class="col s4">
                    <div class="card z-depth-1 hoverable">
                        <div class="card-image ">
                        </div>
                        <div class="card-name-w"><p class="card-name animated-background">&nbsp;</p></div>
                    </div>
                </li>
                <li class="col s4">
                    <div class="card z-depth-1 hoverable">
                        <div class="card-image">
                        </div>
                        <div class="card-name-w"><p class="card-name animated-background">&nbsp;</p></div>
                    </div>
                </li>
                <li class="col s4">
                    <div class="card z-depth-1 hoverable">
                        <div class="card-image">
                        </div>
                        <div class="card-name-w"><p class="card-name animated-background">&nbsp;</p></div>
                    </div>
                </li>
                <li class="col s4">
                    <div class="card z-depth-1 hoverable">
                        <div class="card-image ">
                        </div>
                        <div class="card-name-w"><p class="card-name animated-background">&nbsp;</p></div>
                    </div>
                </li>
                <li class="col s4">
                    <div class="card z-depth-1 hoverable">
                        <div class="card-image ">
                        </div>
                        <div class="card-name-w"><p class="card-name animated-background">&nbsp;</p></div>
                    </div>
                </li>
                <li class="col s4">
                    <div class="card z-depth-1 hoverable">
                        <div class="card-image ">
                        </div>
                        <div class="card-name-w"><p class="card-name animated-background">&nbsp;</p></div>
                    </div>
                </li>
            </ul>

            <ul class="card-group row" id="cards-default">
                    <li class="col s4 redirectItem" >

    <div class="card z-depth-1 hoverable">

        <div class="card-image">

                <img alt="Birthday Gifts" class="img-responsive card-image-p redirectItem" data-position="1" src="https://cdn.igp.com/f_auto,q_auto/cards/desktopcards_birthday_20211229.jpg"
                    data-url="/birthday-gifts">


                <div class="overlay-shape text-center">
                    <div class="row overlay-content no-margin">
                              <div class="col s4">
                                  <a class="waves-effect hover-icon" href="/birthday-gifts-for-women" onclick="onclickDataLayer('cards_click', {'micrositename':'IGP','item_url': 'https://www.igp.com/birthday-gifts-for-women', 'card_name': 'Birthday Gifts', 'card_position': 1, 'item_name': 'Women', 'item_selection': 'Primary' })">
                                      <div class="icon-wrapper hover-icon-wrapper" data-href="/svgs/rro.svg#shape-women">
                                      </div>

                                      <p>Women</p>
                                  </a>

                              </div>
                              <div class="col s4">
                                  <a class="waves-effect hover-icon" href="/birthday-gifts-for-men" onclick="onclickDataLayer('cards_click', {'micrositename':'IGP','item_url': 'https://www.igp.com/birthday-gifts-for-men', 'card_name': 'Birthday Gifts', 'card_position': 1, 'item_name': 'Men', 'item_selection': 'Secondary' })">
                                      <div class="icon-wrapper hover-icon-wrapper" data-href="/svgs/rro.svg#shape-men">
                                      </div>

                                      <p>Men</p>
                                  </a>

                              </div>
                              <div class="col s4">
                                      <div class="waves-effect hover-icon redirectItem" data-url="/birthday-gifts" data-position="1">
                                      <div class="icon-wrapper hover-icon-wrapper" data-href="/svgs/rro.svg#shape-view_all_recipients">
                                      </div>

                                      <p>View All Recipients</p>
                                  </div>

                              </div>
                    </div>
                    <a href="/birthday-gifts" onclick="onclickDataLayer('cards_click', {'micrositename':'IGP','item_url': 'https://www.igp.com/birthday-gifts', 'card_name': 'Birthday Gifts', 'card_position': 1, 'item_name': '', 'item_selection': '' })"><div class="triangle-left-up"></div></a>
                    <a href="/birthday-gifts" onclick="onclickDataLayer('cards_click', {'micrositename':'IGP','item_url': 'https://www.igp.com/birthday-gifts', 'card_name': 'Birthday Gifts', 'card_position': 1, 'item_name': '', 'item_selection': '' })"><div class="triangle-right-up"></div></a>
                </div>
        </div>

        <a href="/birthday-gifts" onclick="onclickDataLayer('cards_click', {'micrositename':'IGP','item_url': 'https://www.igp.com/birthday-gifts', 'card_name': 'Birthday Gifts', 'card_position': 1, 'item_name': '', 'item_selection': '' })">

        
            <div class="card-name-w" ><p class="card-name">Birthday Gifts</p></div>
        

        </a>

        <div class="hide int_titl"></div>
    </div>
</li>

                    <li class="col s4 redirectItem" >

    <div class="card z-depth-1 hoverable">

        <div class="card-image">

                <img alt="Anniversary Gifts" class="img-responsive card-image-p redirectItem" data-position="2" src="https://cdn.igp.com/f_auto,q_auto/cards/igp_homepagecards_anniversary_20210710.jpg"
                    data-url="/anniversary-gifts">


                <div class="overlay-shape text-center">
                    <div class="row overlay-content no-margin">
                              <div class="col s4">
                                  <a class="waves-effect hover-icon" href="/anniversary-gifts-for-women" onclick="onclickDataLayer('cards_click', {'micrositename':'IGP','item_url': 'https://www.igp.com/anniversary-gifts-for-women', 'card_name': 'Anniversary Gifts', 'card_position': 2, 'item_name': 'Women', 'item_selection': 'Primary' })">
                                      <div class="icon-wrapper hover-icon-wrapper" data-href="/svgs/rro.svg#shape-women">
                                      </div>

                                      <p>Women</p>
                                  </a>

                              </div>
                              <div class="col s4">
                                  <a class="waves-effect hover-icon" href="/anniversary-gifts-for-men" onclick="onclickDataLayer('cards_click', {'micrositename':'IGP','item_url': 'https://www.igp.com/anniversary-gifts-for-men', 'card_name': 'Anniversary Gifts', 'card_position': 2, 'item_name': 'Men', 'item_selection': 'Secondary' })">
                                      <div class="icon-wrapper hover-icon-wrapper" data-href="/svgs/rro.svg#shape-men">
                                      </div>

                                      <p>Men</p>
                                  </a>

                              </div>
                              <div class="col s4">
                                      <div class="waves-effect hover-icon redirectItem" data-url="/anniversary-gifts" data-position="2">
                                      <div class="icon-wrapper hover-icon-wrapper" data-href="/svgs/rro.svg#shape-view_all_recipients">
                                      </div>

                                      <p>View All Recipients</p>
                                  </div>

                              </div>
                    </div>
                    <a href="/anniversary-gifts" onclick="onclickDataLayer('cards_click', {'micrositename':'IGP','item_url': 'https://www.igp.com/anniversary-gifts', 'card_name': 'Anniversary Gifts', 'card_position': 2, 'item_name': '', 'item_selection': '' })"><div class="triangle-left-up"></div></a>
                    <a href="/anniversary-gifts" onclick="onclickDataLayer('cards_click', {'micrositename':'IGP','item_url': 'https://www.igp.com/anniversary-gifts', 'card_name': 'Anniversary Gifts', 'card_position': 2, 'item_name': '', 'item_selection': '' })"><div class="triangle-right-up"></div></a>
                </div>
        </div>

        <a href="/anniversary-gifts" onclick="onclickDataLayer('cards_click', {'micrositename':'IGP','item_url': 'https://www.igp.com/anniversary-gifts', 'card_name': 'Anniversary Gifts', 'card_position': 2, 'item_name': '', 'item_selection': '' })">

        
            <div class="card-name-w" ><p class="card-name">Anniversary Gifts</p></div>
        

        </a>

        <div class="hide int_titl"></div>
    </div>
</li>

                    <li class="col s4 redirectItem" data-url="/holi">

    <div class="card z-depth-1 hoverable">

        <div class="card-image">

                <img alt="Holi Gifts" class="img-responsive card-image-p redirectItem" data-position="3" src="https://cdn.igp.com/f_auto,q_auto/cards/desktopcards_holi_20220301.jpg"
                    data-url="/"data-url="/holi">


        </div>

        <a href="/" onclick="onclickDataLayer('cards_click', {'micrositename':'IGP','item_url': 'https://www.igp.com/', 'card_name': 'Holi Gifts', 'card_position': 3, 'item_name': '', 'item_selection': '' })">

        <a href="/holi" onclick="onclickDataLayer('cards_click', {'micrositename':'IGP','item_url': 'https://www.igp.com/holi', 'card_name': 'Holi Gifts', 'card_position': 3, 'item_name': '', 'item_selection': '' })">
            <div class="card-name-w" ><p class="card-name">Holi Gifts</p></div>
        </a>

        </a>

        <div class="hide int_titl"></div>
    </div>
</li>

                    <li class="col s4 redirectItem" >

    <div class="card z-depth-1 hoverable">

        <div class="card-image">

                <img alt="Gifts for Women" class="img-responsive card-image-p redirectItem" data-position="4" src="https://cdn.igp.com/f_auto,q_auto/cards/igp_homepagecards_giftforwomen.jpg"
                    data-url="/gifts-for-women">


                <div class="overlay-shape text-center">
                    <div class="row overlay-content no-margin">
                              <div class="col s4">
                                  <a class="waves-effect hover-icon" href="/gifts-for-wife" onclick="onclickDataLayer('cards_click', {'micrositename':'IGP','item_url': 'https://www.igp.com/gifts-for-wife', 'card_name': 'Gifts for Women', 'card_position': 4, 'item_name': 'Wife', 'item_selection': 'Primary' })">
                                      <div class="icon-wrapper hover-icon-wrapper" data-href="/svgs/rro.svg#shape-wife">
                                      </div>

                                      <p>Wife</p>
                                  </a>

                              </div>
                              <div class="col s4">
                                  <a class="waves-effect hover-icon" href="/gifts-for-mother" onclick="onclickDataLayer('cards_click', {'micrositename':'IGP','item_url': 'https://www.igp.com/gifts-for-mother', 'card_name': 'Gifts for Women', 'card_position': 4, 'item_name': 'Mother', 'item_selection': 'Secondary' })">
                                      <div class="icon-wrapper hover-icon-wrapper" data-href="/svgs/rro.svg#shape-mother">
                                      </div>

                                      <p>Mother</p>
                                  </a>

                              </div>
                              <div class="col s4">
                                      <div class="waves-effect hover-icon redirectItem" data-url="/gifts-for-women" data-position="4">
                                      <div class="icon-wrapper hover-icon-wrapper" data-href="/svgs/rro.svg#shape-view_all_relationships">
                                      </div>

                                      <p>View All Relationships</p>
                                  </div>

                              </div>
                    </div>
                    <a href="/gifts-for-women" onclick="onclickDataLayer('cards_click', {'micrositename':'IGP','item_url': 'https://www.igp.com/gifts-for-women', 'card_name': 'Gifts for Women', 'card_position': 4, 'item_name': '', 'item_selection': '' })"><div class="triangle-left-up"></div></a>
                    <a href="/gifts-for-women" onclick="onclickDataLayer('cards_click', {'micrositename':'IGP','item_url': 'https://www.igp.com/gifts-for-women', 'card_name': 'Gifts for Women', 'card_position': 4, 'item_name': '', 'item_selection': '' })"><div class="triangle-right-up"></div></a>
                </div>
        </div>

        <a href="/gifts-for-women" onclick="onclickDataLayer('cards_click', {'micrositename':'IGP','item_url': 'https://www.igp.com/gifts-for-women', 'card_name': 'Gifts for Women', 'card_position': 4, 'item_name': '', 'item_selection': '' })">

        
            <div class="card-name-w" ><p class="card-name">Gifts for Women</p></div>
        

        </a>

        <div class="hide int_titl"></div>
    </div>
</li>

                    <li class="col s4 redirectItem" >

    <div class="card z-depth-1 hoverable">

        <div class="card-image">

                <img alt="Gifts for Men" class="img-responsive card-image-p redirectItem" data-position="5" src="https://cdn.igp.com/f_auto,q_auto/cards/igp_homepagecards_giftforhim_20210710.jpg"
                    data-url="/gifts-for-men">


                <div class="overlay-shape text-center">
                    <div class="row overlay-content no-margin">
                              <div class="col s4">
                                  <a class="waves-effect hover-icon" href="/gifts-for-husband" onclick="onclickDataLayer('cards_click', {'micrositename':'IGP','item_url': 'https://www.igp.com/gifts-for-husband', 'card_name': 'Gifts for Men', 'card_position': 5, 'item_name': 'Husband', 'item_selection': 'Primary' })">
                                      <div class="icon-wrapper hover-icon-wrapper" data-href="/svgs/rro.svg#shape-husband">
                                      </div>

                                      <p>Husband</p>
                                  </a>

                              </div>
                              <div class="col s4">
                                  <a class="waves-effect hover-icon" href="/gifts-for-father" onclick="onclickDataLayer('cards_click', {'micrositename':'IGP','item_url': 'https://www.igp.com/gifts-for-father', 'card_name': 'Gifts for Men', 'card_position': 5, 'item_name': 'Father', 'item_selection': 'Secondary' })">
                                      <div class="icon-wrapper hover-icon-wrapper" data-href="/svgs/rro.svg#shape-father">
                                      </div>

                                      <p>Father</p>
                                  </a>

                              </div>
                              <div class="col s4">
                                      <div class="waves-effect hover-icon redirectItem" data-url="/gifts-for-men" data-position="5">
                                      <div class="icon-wrapper hover-icon-wrapper" data-href="/svgs/rro.svg#shape-view_all_relationships">
                                      </div>

                                      <p>View All Relationships</p>
                                  </div>

                              </div>
                    </div>
                    <a href="/gifts-for-men" onclick="onclickDataLayer('cards_click', {'micrositename':'IGP','item_url': 'https://www.igp.com/gifts-for-men', 'card_name': 'Gifts for Men', 'card_position': 5, 'item_name': '', 'item_selection': '' })"><div class="triangle-left-up"></div></a>
                    <a href="/gifts-for-men" onclick="onclickDataLayer('cards_click', {'micrositename':'IGP','item_url': 'https://www.igp.com/gifts-for-men', 'card_name': 'Gifts for Men', 'card_position': 5, 'item_name': '', 'item_selection': '' })"><div class="triangle-right-up"></div></a>
                </div>
        </div>

        <a href="/gifts-for-men" onclick="onclickDataLayer('cards_click', {'micrositename':'IGP','item_url': 'https://www.igp.com/gifts-for-men', 'card_name': 'Gifts for Men', 'card_position': 5, 'item_name': '', 'item_selection': '' })">

        
            <div class="card-name-w" ><p class="card-name">Gifts for Men</p></div>
        

        </a>

        <div class="hide int_titl"></div>
    </div>
</li>

                    <li class="col s4 redirectItem" data-url="/flowers">

    <div class="card z-depth-1 hoverable">

        <div class="card-image">

                <img alt="Flowers" class="img-responsive card-image-p redirectItem" data-position="6" src="https://cdn.igp.com/f_auto,q_auto/cards/igp_homepagecards_sdd_20210710.jpg"
                    data-url="/"data-url="/flowers">


        </div>

        <a href="/" onclick="onclickDataLayer('cards_click', {'micrositename':'IGP','item_url': 'https://www.igp.com/', 'card_name': 'Flowers', 'card_position': 6, 'item_name': '', 'item_selection': '' })">

        <a href="/flowers" onclick="onclickDataLayer('cards_click', {'micrositename':'IGP','item_url': 'https://www.igp.com/flowers', 'card_name': 'Flowers', 'card_position': 6, 'item_name': '', 'item_selection': '' })">
            <div class="card-name-w" ><p class="card-name">Flowers</p></div>
        </a>

        </a>

        <div class="hide int_titl"></div>
    </div>
</li>

                    <li class="col s4 redirectItem" data-url="/corporate-gifts">

    <div class="card z-depth-1 hoverable">

        <div class="card-image">

                <img alt="Bulk &amp; Corporate Gifts" class="img-responsive card-image-p redirectItem" data-position="7" src="https://cdn.igp.com/f_auto,q_auto/cards/desktopcards_corporate_20211229.jpg"
                    data-url="/"data-url="/corporate-gifts">


        </div>

        <a href="/" onclick="onclickDataLayer('cards_click', {'micrositename':'IGP','item_url': 'https://www.igp.com/', 'card_name': 'Bulk &amp; Corporate Gifts', 'card_position': 7, 'item_name': '', 'item_selection': '' })">

        <a href="/corporate-gifts" onclick="onclickDataLayer('cards_click', {'micrositename':'IGP','item_url': 'https://www.igp.com/corporate-gifts', 'card_name': 'Bulk &amp; Corporate Gifts', 'card_position': 7, 'item_name': '', 'item_selection': '' })">
            <div class="card-name-w" ><p class="card-name">Bulk &amp; Corporate Gifts</p></div>
        </a>

        </a>

        <div class="hide int_titl"></div>
    </div>
</li>

                    <li class="col s4 redirectItem" data-url="/chocolates">

    <div class="card z-depth-1 hoverable">

        <div class="card-image">

                <img alt="Chocolates" class="img-responsive card-image-p redirectItem" data-position="8" src="https://cdn.igp.com/f_auto,q_auto/cards/igp_homepagecards_chocolates_20210710.jpg"
                    data-url="/"data-url="/chocolates">


        </div>

        <a href="/" onclick="onclickDataLayer('cards_click', {'micrositename':'IGP','item_url': 'https://www.igp.com/', 'card_name': 'Chocolates', 'card_position': 8, 'item_name': '', 'item_selection': '' })">

        <a href="/chocolates" onclick="onclickDataLayer('cards_click', {'micrositename':'IGP','item_url': 'https://www.igp.com/chocolates', 'card_name': 'Chocolates', 'card_position': 8, 'item_name': '', 'item_selection': '' })">
            <div class="card-name-w" ><p class="card-name">Chocolates</p></div>
        </a>

        </a>

        <div class="hide int_titl"></div>
    </div>
</li>

                    <li class="col s4 redirectItem" data-url="/cakes">

    <div class="card z-depth-1 hoverable">

        <div class="card-image">

                <img alt="Cakes" class="img-responsive card-image-p redirectItem" data-position="9" src="https://cdn.igp.com/f_auto,q_auto/cards/desktopcards_cakes_20211222.jpg"
                    data-url="/"data-url="/cakes">


        </div>

        <a href="/" onclick="onclickDataLayer('cards_click', {'micrositename':'IGP','item_url': 'https://www.igp.com/', 'card_name': 'Cakes', 'card_position': 9, 'item_name': '', 'item_selection': '' })">

        <a href="/cakes" onclick="onclickDataLayer('cards_click', {'micrositename':'IGP','item_url': 'https://www.igp.com/cakes', 'card_name': 'Cakes', 'card_position': 9, 'item_name': '', 'item_selection': '' })">
            <div class="card-name-w" ><p class="card-name">Cakes</p></div>
        </a>

        </a>

        <div class="hide int_titl"></div>
    </div>
</li>

            </ul>

        </div>
        <!-- Selection Panel Card Suggestions ends-->

    </div>
    <!-- Selection Panel ends -->

    <!-- Editors Picks Begins -->
        <section id="edpWrapper" class="bg-dark fullscreen">
            <div class="section-title bg-light">
                <h2 class="grand-title p-t-allign">Best Selling Gifts</h2>
            </div>

            <div class="section-content carousel">
                <div class="edp-group-wrapper">
                    <div class="row no-margin" id="edp-loader">
                        <div class="col s3">
                            <div class="product-item z-depth-1 hoverable">
                                <div class="card-image animated-background">
                                </div>
                                <div class="product-name-w product-animated-container"><p class="product-name animated-background product-animated-large">&nbsp;</p></div>
                                <div class="product-name-w product-animated-container"><p class="product-name animated-background product-animated-medium">&nbsp;</p></div>
                                <div class="product-name-w product-animated-container"><p class="product-name animated-background product-animated-small">&nbsp;</p></div>
                            </div>
                        </div>

                        <div class="col s3">
                            <div class="product-item z-depth-1 hoverable">
                                <div class="card-image animated-background">
                                </div>
                                <div class="product-name-w product-animated-container"><p class="product-name animated-background product-animated-large">&nbsp;</p></div>
                                <div class="product-name-w product-animated-container"><p class="product-name animated-background product-animated-medium">&nbsp;</p></div>
                                <div class="product-name-w product-animated-container"><p class="product-name animated-background product-animated-small">&nbsp;</p></div>
                            </div>
                        </div>

                        <div class="col s3">
                            <div class="product-item z-depth-1 hoverable">
                                <div class="card-image animated-background">
                                </div>
                                <div class="product-name-w product-animated-container"><p class="product-name animated-background product-animated-large">&nbsp;</p></div>
                                <div class="product-name-w product-animated-container"><p class="product-name animated-background product-animated-medium">&nbsp;</p></div>
                                <div class="product-name-w product-animated-container"><p class="product-name animated-background product-animated-small">&nbsp;</p></div>
                            </div>
                        </div>

                        <div class="col s3">
                            <div class="product-item z-depth-1 hoverable">
                                <div class="card-image animated-background">
                                </div>
                                <div class="product-name-w product-animated-container"><p class="product-name animated-background product-animated-large">&nbsp;</p></div>
                                <div class="product-name-w product-animated-container"><p class="product-name animated-background product-animated-medium">&nbsp;</p></div>
                                <div class="product-name-w product-animated-container"><p class="product-name animated-background product-animated-small">&nbsp;</p></div>
                            </div>
                        </div>
                    </div>

                    <div class="editors-picks-carousel row no-margin hide" id="edp-default">
                                <!--Home Page-->
<div class="product-grid-item product-grid-item-revamp col s3" data-pid="572793" data-url="/p-personalized-adventure-ride-caricature-with-wooden-stand-122702.html"
    data-sku="J11122702" data-name="Personalized Adventure Ride Caricature with Wooden Stand" data-price="645" data-vid="318" data-personalise=true
    data-barcode="[{&quot;barcodeName&quot;:&quot;J1PZHD00133&quot;,&quot;quantity&quot;:1,&quot;ratio&quot;:77.78},{&quot;barcodeName&quot;:&quot;J1PZHD0117&quot;,&quot;quantity&quot;:1,&quot;ratio&quot;:22.22}]">
    <div class="product-item product-item-revamp z-depth-1 hoverable listing-igp">


        <div class="image-holder">
                <a class="productURL" href="/p-personalized-adventure-ride-caricature-with-wooden-stand-122702">
                    <img src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7"
                        data-original="https://cdn.igp.com/f_auto,q_auto,t_pnoptprodlp/products/p-personalized-adventure-ride-caricature-with-wooden-stand-122702-m.jpg"
                        class=" img-responsive product-image lazy " alt="Personalized Adventure Ride Caricature with Wooden Stand" title="Personalized Adventure Ride Caricature with Wooden Stand" data-url="/p-personalized-adventure-ride-caricature-with-wooden-stand-122702">
                    <div class="row no-margin ">
                        <div class="col s12 no-padding">
                            <div class="product-name-w product-name-w-revamp">
                                <p class="product-name product-name-revamp">Personalized Adventure Ride Caricature with Wooden Stand</p>
                            </div>
                        </div>
                    </div>
                </a>

                <!-- Shortlist CTA area begins -->
                <div class="sl-star-wrapper sl-star-wrapper-revamp">
                    <div class="sl-star sl-star-revamp" data-pid="572793" data-pname="Personalized Adventure Ride Caricature with Wooden Stand" data-sku="J11122702"
                        data-dprice="0" data-mprice="645" data-vid="318"
                        data-personalise=true data-in-slist="0" data-barcode="[{&quot;barcodeName&quot;:&quot;J1PZHD00133&quot;,&quot;quantity&quot;:1,&quot;ratio&quot;:77.78},{&quot;barcodeName&quot;:&quot;J1PZHD0117&quot;,&quot;quantity&quot;:1,&quot;ratio&quot;:22.22}]">
                        <div class="heart-icon" data-pid="572793" id="heart-icon-572793">
                        </div>
                    </div>
                </div>
                <!-- Shortlist CTA area ends -->

                  <div class="product-info" style="padding: 0px 8px; margin-top:8px;">
            <div class="row no-margin">
                <div class="col s8 no-padding">
                    <p class="product-price product-price-revamp" ><span
                            class="number">&#8377; 645</span> </p>
                </div>
                <div class="col s4 no-padding">
                    <p class="offer-p"></p>
                </div>
            </div>
        </div>

                <div class="product-info-revamp" style="margin:8px;">
                    <div class="revamp-list-rating" style="display: flex; height:14px; align-items:center;">
                        <div style="font-size: 12px; height:10px; color: #878787;">
                            <span style="margin-right: 2px;">4.1</span>
                        </div>
                        <img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img>
                        <div style="font-size: 12px; margin-left:4px; height:10px; color: #878787;">
                            (<span>523</span>)
                        </div>
                    </div>
                    <div class="pdp-lable-revamp pdp-lable-revamp-pers" style="height:16px; align-items:center; ">
                        <span style="height:14px;"><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" fill="none"
                                viewBox="0 0 14 14">
                                <path fill="#4F4F4F"
                                    d="M5.9 4.13c-.615.023-1.183.286-1.6.739-.638.694-.657 1.426-.673 2.072-.015.598-.03 1.163-.492 1.821l-.607.862h1.054c.083 0 .165-.001.244-.004h7.44V8.527H7.128c.205-.17.384-.348.547-.525.464-.505.66-1.163.597-1.798l3.14-4.395c.18-.21.274-.477.263-.756-.011-.292-.136-.562-.35-.76-.215-.2-.494-.302-.786-.291-.29.01-.557.133-.756.344L6.08 4.13c-.06-.002-.12-.003-.18 0zm.97 3.131c-.496.539-1.133 1.044-2.366 1.211.193-.56.205-1.066.216-1.503.015-.583.025-.968.385-1.36.219-.237.516-.374.836-.387.32-.012.627.102.863.321.49.456.519 1.226.066 1.718zm3.7-6.155l.007-.004-.019.02L7.788 5c-.072-.09-.152-.176-.239-.257-.095-.09-.198-.169-.305-.24l3.325-3.397zM14 3.605v6.562c0 .905-.736 1.64-1.64 1.64H7.546v1.095h2.844v1.093H3.609v-1.093h2.844v-1.094H1.641c-.905 0-1.641-.736-1.641-1.64V3.604c0-.905.736-1.64 1.64-1.64H6.67l-1.07 1.093H1.64c-.302 0-.547.245-.547.547v6.562c0 .302.245.547.547.547h10.718c.302 0 .547-.245.547-.547V3.605c0-.302-.245-.547-.547-.547h-.495l.413-.579c.126-.153.228-.321.307-.499.799.11 1.416.796 1.416 1.625z" />
                            </svg></span> <span style="padding:1px 0px 0px 4px;">Personalizable</span>
                    </div>
                    
                </div>




        </div>
        <div class="row no-margin variant-container shipping-text-revamp-hide" style="margin-top:10px; padding:0px 8px;">
            <div class="col s12 no-padding">
                <p class="shipping-text shipping-text-revamp">
                </p>

            </div>
        </div>
    </div>

</div>
                                <!--Home Page-->
<div class="product-grid-item product-grid-item-revamp col s3" data-pid="574278" data-url="/p-personalized-black-leather-wallet-for-men-125146.html"
    data-sku="L11125146" data-name="Personalized Black Leather Wallet for Men" data-price="525" data-vid="4" data-personalise=true
    data-barcode="[{&quot;barcodeName&quot;:&quot;L1FAPE0001&quot;,&quot;quantity&quot;:1,&quot;ratio&quot;:100}]">
    <div class="product-item product-item-revamp z-depth-1 hoverable listing-igp">


        <div class="image-holder">
                <a class="productURL" href="/p-personalized-black-leather-wallet-for-men-125146">
                    <img src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7"
                        data-original="https://cdn.igp.com/f_auto,q_auto,t_pnoptprodlp/products/p-personalized-black-leather-wallet-for-men-125146-m.jpg"
                        class=" img-responsive product-image lazy " alt="Personalized Black Leather Wallet for Men" title="Personalized Black Leather Wallet for Men" data-url="/p-personalized-black-leather-wallet-for-men-125146">
                    <div class="row no-margin ">
                        <div class="col s12 no-padding">
                            <div class="product-name-w product-name-w-revamp">
                                <p class="product-name product-name-revamp">Personalized Black Leather Wallet for Men</p>
                            </div>
                        </div>
                    </div>
                </a>

                <!-- Shortlist CTA area begins -->
                <div class="sl-star-wrapper sl-star-wrapper-revamp">
                    <div class="sl-star sl-star-revamp" data-pid="574278" data-pname="Personalized Black Leather Wallet for Men" data-sku="L11125146"
                        data-dprice="0" data-mprice="525" data-vid="4"
                        data-personalise=true data-in-slist="0" data-barcode="[{&quot;barcodeName&quot;:&quot;L1FAPE0001&quot;,&quot;quantity&quot;:1,&quot;ratio&quot;:100}]">
                        <div class="heart-icon" data-pid="574278" id="heart-icon-574278">
                        </div>
                    </div>
                </div>
                <!-- Shortlist CTA area ends -->

                  <div class="product-info" style="padding: 0px 8px; margin-top:8px;">
            <div class="row no-margin">
                <div class="col s8 no-padding">
                    <p class="product-price product-price-revamp" ><span
                            class="number">&#8377; 525</span> </p>
                </div>
                <div class="col s4 no-padding">
                    <p class="offer-p"></p>
                </div>
            </div>
        </div>

                <div class="product-info-revamp" style="margin:8px;">
                    <div class="revamp-list-rating" style="display: flex; height:14px; align-items:center;">
                        <div style="font-size: 12px; height:10px; color: #878787;">
                            <span style="margin-right: 2px;">4.4</span>
                        </div>
                        <img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img>
                        <div style="font-size: 12px; margin-left:4px; height:10px; color: #878787;">
                            (<span>115</span>)
                        </div>
                    </div>
                    <div class="pdp-lable-revamp pdp-lable-revamp-pers" style="height:16px; align-items:center; ">
                        <span style="height:14px;"><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" fill="none"
                                viewBox="0 0 14 14">
                                <path fill="#4F4F4F"
                                    d="M5.9 4.13c-.615.023-1.183.286-1.6.739-.638.694-.657 1.426-.673 2.072-.015.598-.03 1.163-.492 1.821l-.607.862h1.054c.083 0 .165-.001.244-.004h7.44V8.527H7.128c.205-.17.384-.348.547-.525.464-.505.66-1.163.597-1.798l3.14-4.395c.18-.21.274-.477.263-.756-.011-.292-.136-.562-.35-.76-.215-.2-.494-.302-.786-.291-.29.01-.557.133-.756.344L6.08 4.13c-.06-.002-.12-.003-.18 0zm.97 3.131c-.496.539-1.133 1.044-2.366 1.211.193-.56.205-1.066.216-1.503.015-.583.025-.968.385-1.36.219-.237.516-.374.836-.387.32-.012.627.102.863.321.49.456.519 1.226.066 1.718zm3.7-6.155l.007-.004-.019.02L7.788 5c-.072-.09-.152-.176-.239-.257-.095-.09-.198-.169-.305-.24l3.325-3.397zM14 3.605v6.562c0 .905-.736 1.64-1.64 1.64H7.546v1.095h2.844v1.093H3.609v-1.093h2.844v-1.094H1.641c-.905 0-1.641-.736-1.641-1.64V3.604c0-.905.736-1.64 1.64-1.64H6.67l-1.07 1.093H1.64c-.302 0-.547.245-.547.547v6.562c0 .302.245.547.547.547h10.718c.302 0 .547-.245.547-.547V3.605c0-.302-.245-.547-.547-.547h-.495l.413-.579c.126-.153.228-.321.307-.499.799.11 1.416.796 1.416 1.625z" />
                            </svg></span> <span style="padding:1px 0px 0px 4px;">Personalizable</span>
                    </div>
                    
                </div>




        </div>
        <div class="row no-margin variant-container shipping-text-revamp-hide" style="margin-top:10px; padding:0px 8px;">
            <div class="col s12 no-padding">
                <p class="shipping-text shipping-text-revamp">
                </p>

            </div>
        </div>
    </div>

</div>
                                <!--Home Page-->
<div class="product-grid-item product-grid-item-revamp col s3" data-pid="592535" data-url="/p-lilac-rhapsody-155095.html"
    data-sku="HD1155095" data-name="Lilac Rhapsody" data-price="1595" data-vid="72" data-personalise=false
    data-barcode="[{&quot;barcodeName&quot;:&quot;HDIGPF1745&quot;,&quot;quantity&quot;:1,&quot;ratio&quot;:100}]">
    <div class="product-item product-item-revamp z-depth-1 hoverable listing-igp">


        <div class="image-holder">
                <a class="productURL" href="/p-lilac-rhapsody-155095">
                    <img src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7"
                        data-original="https://cdn.igp.com/f_auto,q_auto,t_pnoptprodlp/products/p-lilac-rhapsody-155095-m.jpg"
                        class=" img-responsive product-image lazy " alt="Lilac Rhapsody" title="Lilac Rhapsody" data-url="/p-lilac-rhapsody-155095">
                    <div class="row no-margin ">
                        <div class="col s12 no-padding">
                            <div class="product-name-w product-name-w-revamp">
                                <p class="product-name product-name-revamp">Lilac Rhapsody</p>
                            </div>
                        </div>
                    </div>
                </a>

                <!-- Shortlist CTA area begins -->
                <div class="sl-star-wrapper sl-star-wrapper-revamp">
                    <div class="sl-star sl-star-revamp" data-pid="592535" data-pname="Lilac Rhapsody" data-sku="HD1155095"
                        data-dprice="0" data-mprice="1595" data-vid="72"
                        data-personalise=false data-in-slist="0" data-barcode="[{&quot;barcodeName&quot;:&quot;HDIGPF1745&quot;,&quot;quantity&quot;:1,&quot;ratio&quot;:100}]">
                        <div class="heart-icon" data-pid="592535" id="heart-icon-592535">
                        </div>
                    </div>
                </div>
                <!-- Shortlist CTA area ends -->

                  <div class="product-info" style="padding: 0px 8px; margin-top:8px;">
            <div class="row no-margin">
                <div class="col s8 no-padding">
                    <p class="product-price product-price-revamp" ><span
                            class="number">&#8377; 1595</span> </p>
                </div>
                <div class="col s4 no-padding">
                    <p class="offer-p"></p>
                </div>
            </div>
        </div>

                <div class="product-info-revamp" style="margin:8px;">
                    <div class="pdp-label pdp-lable-revamp pdp-lable-phone-revamp pdp-label-revamp-delivery-text top-right">Same Day Delivery</div>
                </div>




        </div>
        <div class="row no-margin variant-container shipping-text-revamp-hide" style="margin-top:10px; padding:0px 8px;">
            <div class="col s12 no-padding">
                <p class="shipping-text shipping-text-revamp">
                    Get it today! Order before 6pm IST
                </p>

            </div>
        </div>
    </div>

</div>
                                <!--Home Page-->
<div class="product-grid-item product-grid-item-revamp col s3" data-pid="580345" data-url="/p-mom-of-girl-personalized-caricature-stand-136130.html"
    data-sku="J11136130" data-name="Mom Of Girl Personalized Caricature Stand" data-price="595" data-vid="318" data-personalise=true
    data-barcode="[{&quot;barcodeName&quot;:&quot;J1PZHD00167&quot;,&quot;quantity&quot;:1,&quot;ratio&quot;:52.94},{&quot;barcodeName&quot;:&quot;J1PZHD0117&quot;,&quot;quantity&quot;:1,&quot;ratio&quot;:47.06}]">
    <div class="product-item product-item-revamp z-depth-1 hoverable listing-igp">


        <div class="image-holder">
                <a class="productURL" href="/p-mom-of-girl-personalized-caricature-stand-136130">
                    <img src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7"
                        data-original="https://cdn.igp.com/f_auto,q_auto,t_pnoptprodlp/products/p-mom-of-girl-personalized-caricature-stand-136130-m.jpg"
                        class=" img-responsive product-image lazy " alt="Mom Of Girl Personalized Caricature Stand" title="Mom Of Girl Personalized Caricature Stand" data-url="/p-mom-of-girl-personalized-caricature-stand-136130">
                    <div class="row no-margin ">
                        <div class="col s12 no-padding">
                            <div class="product-name-w product-name-w-revamp">
                                <p class="product-name product-name-revamp">Mom Of Girl Personalized Caricature Stand</p>
                            </div>
                        </div>
                    </div>
                </a>

                <!-- Shortlist CTA area begins -->
                <div class="sl-star-wrapper sl-star-wrapper-revamp">
                    <div class="sl-star sl-star-revamp" data-pid="580345" data-pname="Mom Of Girl Personalized Caricature Stand" data-sku="J11136130"
                        data-dprice="0" data-mprice="595" data-vid="318"
                        data-personalise=true data-in-slist="0" data-barcode="[{&quot;barcodeName&quot;:&quot;J1PZHD00167&quot;,&quot;quantity&quot;:1,&quot;ratio&quot;:52.94},{&quot;barcodeName&quot;:&quot;J1PZHD0117&quot;,&quot;quantity&quot;:1,&quot;ratio&quot;:47.06}]">
                        <div class="heart-icon" data-pid="580345" id="heart-icon-580345">
                        </div>
                    </div>
                </div>
                <!-- Shortlist CTA area ends -->

                  <div class="product-info" style="padding: 0px 8px; margin-top:8px;">
            <div class="row no-margin">
                <div class="col s8 no-padding">
                    <p class="product-price product-price-revamp" ><span
                            class="number">&#8377; 595</span> </p>
                </div>
                <div class="col s4 no-padding">
                    <p class="offer-p"></p>
                </div>
            </div>
        </div>

                <div class="product-info-revamp" style="margin:8px;">
                    <div class="revamp-list-rating" style="display: flex; height:14px; align-items:center;">
                        <div style="font-size: 12px; height:10px; color: #878787;">
                            <span style="margin-right: 2px;">4.6</span>
                        </div>
                        <img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img>
                        <div style="font-size: 12px; margin-left:4px; height:10px; color: #878787;">
                            (<span>17</span>)
                        </div>
                    </div>
                    <div class="pdp-lable-revamp pdp-lable-revamp-pers" style="height:16px; align-items:center; ">
                        <span style="height:14px;"><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" fill="none"
                                viewBox="0 0 14 14">
                                <path fill="#4F4F4F"
                                    d="M5.9 4.13c-.615.023-1.183.286-1.6.739-.638.694-.657 1.426-.673 2.072-.015.598-.03 1.163-.492 1.821l-.607.862h1.054c.083 0 .165-.001.244-.004h7.44V8.527H7.128c.205-.17.384-.348.547-.525.464-.505.66-1.163.597-1.798l3.14-4.395c.18-.21.274-.477.263-.756-.011-.292-.136-.562-.35-.76-.215-.2-.494-.302-.786-.291-.29.01-.557.133-.756.344L6.08 4.13c-.06-.002-.12-.003-.18 0zm.97 3.131c-.496.539-1.133 1.044-2.366 1.211.193-.56.205-1.066.216-1.503.015-.583.025-.968.385-1.36.219-.237.516-.374.836-.387.32-.012.627.102.863.321.49.456.519 1.226.066 1.718zm3.7-6.155l.007-.004-.019.02L7.788 5c-.072-.09-.152-.176-.239-.257-.095-.09-.198-.169-.305-.24l3.325-3.397zM14 3.605v6.562c0 .905-.736 1.64-1.64 1.64H7.546v1.095h2.844v1.093H3.609v-1.093h2.844v-1.094H1.641c-.905 0-1.641-.736-1.641-1.64V3.604c0-.905.736-1.64 1.64-1.64H6.67l-1.07 1.093H1.64c-.302 0-.547.245-.547.547v6.562c0 .302.245.547.547.547h10.718c.302 0 .547-.245.547-.547V3.605c0-.302-.245-.547-.547-.547h-.495l.413-.579c.126-.153.228-.321.307-.499.799.11 1.416.796 1.416 1.625z" />
                            </svg></span> <span style="padding:1px 0px 0px 4px;">Personalizable</span>
                    </div>
                    
                </div>




        </div>
        <div class="row no-margin variant-container shipping-text-revamp-hide" style="margin-top:10px; padding:0px 8px;">
            <div class="col s12 no-padding">
                <p class="shipping-text shipping-text-revamp">
                </p>

            </div>
        </div>
    </div>

</div>
                                <!--Home Page-->
<div class="product-grid-item product-grid-item-revamp col s3" data-pid="578475" data-url="/p-personalised-antique-gold-finish-notebook-and-pen-131839.html"
    data-sku="M11131839" data-name="Personalised Antique Gold Finish Notebook and Pen" data-price="575" data-vid="354" data-personalise=true
    data-barcode="[{&quot;barcodeName&quot;:&quot;M1SDPE1804&quot;,&quot;quantity&quot;:1,&quot;ratio&quot;:100}]">
    <div class="product-item product-item-revamp z-depth-1 hoverable listing-igp">


        <div class="image-holder">
                <a class="productURL" href="/p-personalised-antique-gold-finish-notebook-and-pen-131839">
                    <img src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7"
                        data-original="https://cdn.igp.com/f_auto,q_auto,t_pnoptprodlp/products/p-personalised-antique-gold-finish-notebook-and-pen-131839-m.jpg"
                        class=" img-responsive product-image lazy " alt="Personalised Antique Gold Finish Notebook and Pen" title="Personalised Antique Gold Finish Notebook and Pen" data-url="/p-personalised-antique-gold-finish-notebook-and-pen-131839">
                    <div class="row no-margin ">
                        <div class="col s12 no-padding">
                            <div class="product-name-w product-name-w-revamp">
                                <p class="product-name product-name-revamp">Personalised Antique Gold Finish Notebook and Pen</p>
                            </div>
                        </div>
                    </div>
                </a>

                <!-- Shortlist CTA area begins -->
                <div class="sl-star-wrapper sl-star-wrapper-revamp">
                    <div class="sl-star sl-star-revamp" data-pid="578475" data-pname="Personalised Antique Gold Finish Notebook and Pen" data-sku="M11131839"
                        data-dprice="0" data-mprice="575" data-vid="354"
                        data-personalise=true data-in-slist="0" data-barcode="[{&quot;barcodeName&quot;:&quot;M1SDPE1804&quot;,&quot;quantity&quot;:1,&quot;ratio&quot;:100}]">
                        <div class="heart-icon" data-pid="578475" id="heart-icon-578475">
                        </div>
                    </div>
                </div>
                <!-- Shortlist CTA area ends -->

                  <div class="product-info" style="padding: 0px 8px; margin-top:8px;">
            <div class="row no-margin">
                <div class="col s8 no-padding">
                    <p class="product-price product-price-revamp" ><span
                            class="number">&#8377; 575</span> </p>
                </div>
                <div class="col s4 no-padding">
                    <p class="offer-p"></p>
                </div>
            </div>
        </div>

                <div class="product-info-revamp" style="margin:8px;">
                    <div class="revamp-list-rating" style="display: flex; height:14px; align-items:center;">
                        <div style="font-size: 12px; height:10px; color: #878787;">
                            <span style="margin-right: 2px;">4.4</span>
                        </div>
                        <img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img>
                        <div style="font-size: 12px; margin-left:4px; height:10px; color: #878787;">
                            (<span>240</span>)
                        </div>
                    </div>
                    <div class="pdp-lable-revamp pdp-lable-revamp-pers" style="height:16px; align-items:center; ">
                        <span style="height:14px;"><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" fill="none"
                                viewBox="0 0 14 14">
                                <path fill="#4F4F4F"
                                    d="M5.9 4.13c-.615.023-1.183.286-1.6.739-.638.694-.657 1.426-.673 2.072-.015.598-.03 1.163-.492 1.821l-.607.862h1.054c.083 0 .165-.001.244-.004h7.44V8.527H7.128c.205-.17.384-.348.547-.525.464-.505.66-1.163.597-1.798l3.14-4.395c.18-.21.274-.477.263-.756-.011-.292-.136-.562-.35-.76-.215-.2-.494-.302-.786-.291-.29.01-.557.133-.756.344L6.08 4.13c-.06-.002-.12-.003-.18 0zm.97 3.131c-.496.539-1.133 1.044-2.366 1.211.193-.56.205-1.066.216-1.503.015-.583.025-.968.385-1.36.219-.237.516-.374.836-.387.32-.012.627.102.863.321.49.456.519 1.226.066 1.718zm3.7-6.155l.007-.004-.019.02L7.788 5c-.072-.09-.152-.176-.239-.257-.095-.09-.198-.169-.305-.24l3.325-3.397zM14 3.605v6.562c0 .905-.736 1.64-1.64 1.64H7.546v1.095h2.844v1.093H3.609v-1.093h2.844v-1.094H1.641c-.905 0-1.641-.736-1.641-1.64V3.604c0-.905.736-1.64 1.64-1.64H6.67l-1.07 1.093H1.64c-.302 0-.547.245-.547.547v6.562c0 .302.245.547.547.547h10.718c.302 0 .547-.245.547-.547V3.605c0-.302-.245-.547-.547-.547h-.495l.413-.579c.126-.153.228-.321.307-.499.799.11 1.416.796 1.416 1.625z" />
                            </svg></span> <span style="padding:1px 0px 0px 4px;">Personalizable</span>
                    </div>
                    
                </div>




        </div>
        <div class="row no-margin variant-container shipping-text-revamp-hide" style="margin-top:10px; padding:0px 8px;">
            <div class="col s12 no-padding">
                <p class="shipping-text shipping-text-revamp">
                </p>

            </div>
        </div>
    </div>

</div>
                                <!--Home Page-->
<div class="product-grid-item product-grid-item-revamp col s3" data-pid="564951" data-url="/p-special-butterscotch-cake-half-kg--109218.html"
    data-sku="HD1109218" data-name="Special Butterscotch Cake (Half Kg)" data-price="595" data-vid="72" data-personalise=false
    data-barcode="[{&quot;barcodeName&quot;:&quot;HDIGPC0712&quot;,&quot;quantity&quot;:1,&quot;ratio&quot;:100}]">
    <div class="product-item product-item-revamp z-depth-1 hoverable listing-igp">


        <div class="image-holder">
                <a class="productURL" href="/p-special-butterscotch-cake-half-kg--109218">
                    <img src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7"
                        data-original="https://cdn.igp.com/f_auto,q_auto,t_pnoptprodlp/products/p-special-butterscotch-cake-half-kg--109218-m.jpg"
                        class=" img-responsive product-image lazy " alt="Special Butterscotch Cake (Half Kg)" title="Special Butterscotch Cake (Half Kg)" data-url="/p-special-butterscotch-cake-half-kg--109218">
                    <div class="row no-margin ">
                        <div class="col s12 no-padding">
                            <div class="product-name-w product-name-w-revamp">
                                <p class="product-name product-name-revamp">Special Butterscotch Cake (Half Kg)</p>
                            </div>
                        </div>
                    </div>
                </a>

                <!-- Shortlist CTA area begins -->
                <div class="sl-star-wrapper sl-star-wrapper-revamp">
                    <div class="sl-star sl-star-revamp" data-pid="564951" data-pname="Special Butterscotch Cake (Half Kg)" data-sku="HD1109218"
                        data-dprice="695" data-mprice="595" data-vid="72"
                        data-personalise=false data-in-slist="0" data-barcode="[{&quot;barcodeName&quot;:&quot;HDIGPC0712&quot;,&quot;quantity&quot;:1,&quot;ratio&quot;:100}]">
                        <div class="heart-icon" data-pid="564951" id="heart-icon-564951">
                        </div>
                    </div>
                </div>
                <!-- Shortlist CTA area ends -->

                  <div class="product-info" style="padding: 0px 8px; margin-top:8px;">
            <div style="display: flex; align-items:center;">
                
                <div class="product-price product-price-revamp" >
                    <span class="number">&#8377; 595</span> 
                    <span class="number offer offer-revamp">&#8377; 695</span> 
                </div>

                <div class="offer-label-revamp number">14% OFF</div>
               
            </div>
        </div>

                <div class="product-info-revamp" style="margin:8px;">
                    <div class="revamp-list-rating" style="display: flex; height:14px; align-items:center;">
                        <div style="font-size: 12px; height:10px; color: #878787;">
                            <span style="margin-right: 2px;">4.4</span>
                        </div>
                        <img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img>
                        <div style="font-size: 12px; margin-left:4px; height:10px; color: #878787;">
                            (<span>428</span>)
                        </div>
                    </div>
                    <div class="pdp-label pdp-lable-revamp pdp-lable-phone-revamp pdp-label-revamp-delivery-text top-right">Same Day Delivery</div>
                </div>




        </div>
        <div class="row no-margin variant-container shipping-text-revamp-hide" style="margin-top:10px; padding:0px 8px;">
            <div class="col s12 no-padding">
                <p class="shipping-text shipping-text-revamp">
                </p>

            </div>
        </div>
    </div>

</div>
                                <!--Home Page-->
<div class="product-grid-item product-grid-item-revamp col s3" data-pid="588273" data-url="/p-quilt-finish-sling-bag-for-women-149419.html"
    data-sku="J11149419" data-name="Quilt Finish Sling Bag For Women" data-price="895" data-vid="318" data-personalise=false
    data-barcode="[{&quot;barcodeName&quot;:&quot;J1HBSB0001&quot;,&quot;quantity&quot;:1,&quot;ratio&quot;:100}]">
    <div class="product-item product-item-revamp z-depth-1 hoverable listing-igp">


        <div class="image-holder">
                <a class="productURL" href="/p-quilt-finish-sling-bag-for-women-149419">
                    <img src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7"
                        data-original="https://cdn.igp.com/f_auto,q_auto,t_pnoptprodlp/products/p-quilt-finish-sling-bag-for-women-149419-m.jpg"
                        class=" img-responsive product-image lazy " alt="Quilt Finish Sling Bag For Women" title="Quilt Finish Sling Bag For Women" data-url="/p-quilt-finish-sling-bag-for-women-149419">
                    <div class="row no-margin ">
                        <div class="col s12 no-padding">
                            <div class="product-name-w product-name-w-revamp">
                                <p class="product-name product-name-revamp">Quilt Finish Sling Bag For Women</p>
                            </div>
                        </div>
                    </div>
                </a>

                <!-- Shortlist CTA area begins -->
                <div class="sl-star-wrapper sl-star-wrapper-revamp">
                    <div class="sl-star sl-star-revamp" data-pid="588273" data-pname="Quilt Finish Sling Bag For Women" data-sku="J11149419"
                        data-dprice="0" data-mprice="895" data-vid="318"
                        data-personalise=false data-in-slist="0" data-barcode="[{&quot;barcodeName&quot;:&quot;J1HBSB0001&quot;,&quot;quantity&quot;:1,&quot;ratio&quot;:100}]">
                        <div class="heart-icon" data-pid="588273" id="heart-icon-588273">
                        </div>
                    </div>
                </div>
                <!-- Shortlist CTA area ends -->

                  <div class="product-info" style="padding: 0px 8px; margin-top:8px;">
            <div class="row no-margin">
                <div class="col s8 no-padding">
                    <p class="product-price product-price-revamp" ><span
                            class="number">&#8377; 895</span> </p>
                </div>
                <div class="col s4 no-padding">
                    <p class="offer-p"></p>
                </div>
            </div>
        </div>

                <div class="product-info-revamp" style="margin:8px;">
                    <div class="revamp-list-rating" style="display: flex; height:14px; align-items:center;">
                        <div style="font-size: 12px; height:10px; color: #878787;">
                            <span style="margin-right: 2px;">4.5</span>
                        </div>
                        <img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img>
                        <div style="font-size: 12px; margin-left:4px; height:10px; color: #878787;">
                            (<span>23</span>)
                        </div>
                    </div>
                    
                </div>




        </div>
        <div class="row no-margin variant-container shipping-text-revamp-hide" style="margin-top:10px; padding:0px 8px;">
            <div class="col s12 no-padding">
                <p class="shipping-text shipping-text-revamp">
                </p>

            </div>
        </div>
    </div>

</div>
                                <!--Home Page-->
<div class="product-grid-item product-grid-item-revamp col s3" data-pid="579741" data-url="/p-personalized-wooden-masala-box-with-metal-containers-for-mom-135190.html"
    data-sku="J11135190" data-name="Personalized Wooden Masala Box with Metal Containers for Mom" data-price="1275" data-vid="318" data-personalise=true
    data-barcode="[{&quot;barcodeName&quot;:&quot;J1PZKB0109&quot;,&quot;quantity&quot;:1,&quot;ratio&quot;:100}]">
    <div class="product-item product-item-revamp z-depth-1 hoverable listing-igp">


        <div class="image-holder">
                <a class="productURL" href="/p-personalized-wooden-masala-box-with-metal-containers-for-mom-135190">
                    <img src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7"
                        data-original="https://cdn.igp.com/f_auto,q_auto,t_pnoptprodlp/products/p-personalized-wooden-masala-box-with-metal-containers-for-mom-135190-m.jpg"
                        class=" img-responsive product-image lazy " alt="Personalized Wooden Masala Box with Metal Containers for Mom" title="Personalized Wooden Masala Box with Metal Containers for Mom" data-url="/p-personalized-wooden-masala-box-with-metal-containers-for-mom-135190">
                    <div class="row no-margin ">
                        <div class="col s12 no-padding">
                            <div class="product-name-w product-name-w-revamp">
                                <p class="product-name product-name-revamp">Personalized Wooden Masala Box with Metal Containers for Mom</p>
                            </div>
                        </div>
                    </div>
                </a>

                <!-- Shortlist CTA area begins -->
                <div class="sl-star-wrapper sl-star-wrapper-revamp">
                    <div class="sl-star sl-star-revamp" data-pid="579741" data-pname="Personalized Wooden Masala Box with Metal Containers for Mom" data-sku="J11135190"
                        data-dprice="0" data-mprice="1275" data-vid="318"
                        data-personalise=true data-in-slist="0" data-barcode="[{&quot;barcodeName&quot;:&quot;J1PZKB0109&quot;,&quot;quantity&quot;:1,&quot;ratio&quot;:100}]">
                        <div class="heart-icon" data-pid="579741" id="heart-icon-579741">
                        </div>
                    </div>
                </div>
                <!-- Shortlist CTA area ends -->

                  <div class="product-info" style="padding: 0px 8px; margin-top:8px;">
            <div class="row no-margin">
                <div class="col s8 no-padding">
                    <p class="product-price product-price-revamp" ><span
                            class="number">&#8377; 1275</span> </p>
                </div>
                <div class="col s4 no-padding">
                    <p class="offer-p"></p>
                </div>
            </div>
        </div>

                <div class="product-info-revamp" style="margin:8px;">
                    <div class="revamp-list-rating" style="display: flex; height:14px; align-items:center;">
                        <div style="font-size: 12px; height:10px; color: #878787;">
                            <span style="margin-right: 2px;">4.6</span>
                        </div>
                        <img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img>
                        <div style="font-size: 12px; margin-left:4px; height:10px; color: #878787;">
                            (<span>4</span>)
                        </div>
                    </div>
                    <div class="pdp-lable-revamp pdp-lable-revamp-pers" style="height:16px; align-items:center; ">
                        <span style="height:14px;"><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" fill="none"
                                viewBox="0 0 14 14">
                                <path fill="#4F4F4F"
                                    d="M5.9 4.13c-.615.023-1.183.286-1.6.739-.638.694-.657 1.426-.673 2.072-.015.598-.03 1.163-.492 1.821l-.607.862h1.054c.083 0 .165-.001.244-.004h7.44V8.527H7.128c.205-.17.384-.348.547-.525.464-.505.66-1.163.597-1.798l3.14-4.395c.18-.21.274-.477.263-.756-.011-.292-.136-.562-.35-.76-.215-.2-.494-.302-.786-.291-.29.01-.557.133-.756.344L6.08 4.13c-.06-.002-.12-.003-.18 0zm.97 3.131c-.496.539-1.133 1.044-2.366 1.211.193-.56.205-1.066.216-1.503.015-.583.025-.968.385-1.36.219-.237.516-.374.836-.387.32-.012.627.102.863.321.49.456.519 1.226.066 1.718zm3.7-6.155l.007-.004-.019.02L7.788 5c-.072-.09-.152-.176-.239-.257-.095-.09-.198-.169-.305-.24l3.325-3.397zM14 3.605v6.562c0 .905-.736 1.64-1.64 1.64H7.546v1.095h2.844v1.093H3.609v-1.093h2.844v-1.094H1.641c-.905 0-1.641-.736-1.641-1.64V3.604c0-.905.736-1.64 1.64-1.64H6.67l-1.07 1.093H1.64c-.302 0-.547.245-.547.547v6.562c0 .302.245.547.547.547h10.718c.302 0 .547-.245.547-.547V3.605c0-.302-.245-.547-.547-.547h-.495l.413-.579c.126-.153.228-.321.307-.499.799.11 1.416.796 1.416 1.625z" />
                            </svg></span> <span style="padding:1px 0px 0px 4px;">Personalizable</span>
                    </div>
                    
                </div>




        </div>
        <div class="row no-margin variant-container shipping-text-revamp-hide" style="margin-top:10px; padding:0px 8px;">
            <div class="col s12 no-padding">
                <p class="shipping-text shipping-text-revamp">
                </p>

            </div>
        </div>
    </div>

</div>
                                <!--Home Page-->
<div class="product-grid-item product-grid-item-revamp col s3" data-pid="592713" data-url="/p-successful-woman-personalized-decanter-with-led-light-frosted-pink-155430.html"
    data-sku="J11155430" data-name="Successful Woman Personalized Decanter With LED Light - Frosted Pink" data-price="795" data-vid="318" data-personalise=true
    data-barcode="[{&quot;barcodeName&quot;:&quot;J1PZHD000135&quot;,&quot;quantity&quot;:1,&quot;ratio&quot;:27.42},{&quot;barcodeName&quot;:&quot;J1PZHD0134&quot;,&quot;quantity&quot;:1,&quot;ratio&quot;:72.58}]">
    <div class="product-item product-item-revamp z-depth-1 hoverable listing-igp">


        <div class="image-holder">
                <a class="productURL" href="/p-successful-woman-personalized-decanter-with-led-light-frosted-pink-155430">
                    <img src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7"
                        data-original="https://cdn.igp.com/f_auto,q_auto,t_pnoptprodlp/products/p-successful-woman-personalized-decanter-with-led-light-frosted-pink-155430-m.jpg"
                        class=" img-responsive product-image lazy " alt="Successful Woman Personalized Decanter With LED Light - Frosted Pink" title="Successful Woman Personalized Decanter With LED Light - Frosted Pink" data-url="/p-successful-woman-personalized-decanter-with-led-light-frosted-pink-155430">
                    <div class="row no-margin ">
                        <div class="col s12 no-padding">
                            <div class="product-name-w product-name-w-revamp">
                                <p class="product-name product-name-revamp">Successful Woman Personalized Decanter With LED Light - Frosted Pink</p>
                            </div>
                        </div>
                    </div>
                </a>

                <!-- Shortlist CTA area begins -->
                <div class="sl-star-wrapper sl-star-wrapper-revamp">
                    <div class="sl-star sl-star-revamp" data-pid="592713" data-pname="Successful Woman Personalized Decanter With LED Light - Frosted Pink" data-sku="J11155430"
                        data-dprice="0" data-mprice="795" data-vid="318"
                        data-personalise=true data-in-slist="0" data-barcode="[{&quot;barcodeName&quot;:&quot;J1PZHD000135&quot;,&quot;quantity&quot;:1,&quot;ratio&quot;:27.42},{&quot;barcodeName&quot;:&quot;J1PZHD0134&quot;,&quot;quantity&quot;:1,&quot;ratio&quot;:72.58}]">
                        <div class="heart-icon" data-pid="592713" id="heart-icon-592713">
                        </div>
                    </div>
                </div>
                <!-- Shortlist CTA area ends -->

                  <div class="product-info" style="padding: 0px 8px; margin-top:8px;">
            <div class="row no-margin">
                <div class="col s8 no-padding">
                    <p class="product-price product-price-revamp" ><span
                            class="number">&#8377; 795</span> </p>
                </div>
                <div class="col s4 no-padding">
                    <p class="offer-p"></p>
                </div>
            </div>
        </div>

                <div class="product-info-revamp" style="margin:8px;">
                    <div class="revamp-list-rating" style="display: flex; height:14px; align-items:center;">
                        <div style="font-size: 12px; height:10px; color: #878787;">
                            <span style="margin-right: 2px;">3.8</span>
                        </div>
                        <img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img>
                        <div style="font-size: 12px; margin-left:4px; height:10px; color: #878787;">
                            (<span>2</span>)
                        </div>
                    </div>
                    <div class="pdp-lable-revamp pdp-lable-revamp-pers" style="height:16px; align-items:center; ">
                        <span style="height:14px;"><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" fill="none"
                                viewBox="0 0 14 14">
                                <path fill="#4F4F4F"
                                    d="M5.9 4.13c-.615.023-1.183.286-1.6.739-.638.694-.657 1.426-.673 2.072-.015.598-.03 1.163-.492 1.821l-.607.862h1.054c.083 0 .165-.001.244-.004h7.44V8.527H7.128c.205-.17.384-.348.547-.525.464-.505.66-1.163.597-1.798l3.14-4.395c.18-.21.274-.477.263-.756-.011-.292-.136-.562-.35-.76-.215-.2-.494-.302-.786-.291-.29.01-.557.133-.756.344L6.08 4.13c-.06-.002-.12-.003-.18 0zm.97 3.131c-.496.539-1.133 1.044-2.366 1.211.193-.56.205-1.066.216-1.503.015-.583.025-.968.385-1.36.219-.237.516-.374.836-.387.32-.012.627.102.863.321.49.456.519 1.226.066 1.718zm3.7-6.155l.007-.004-.019.02L7.788 5c-.072-.09-.152-.176-.239-.257-.095-.09-.198-.169-.305-.24l3.325-3.397zM14 3.605v6.562c0 .905-.736 1.64-1.64 1.64H7.546v1.095h2.844v1.093H3.609v-1.093h2.844v-1.094H1.641c-.905 0-1.641-.736-1.641-1.64V3.604c0-.905.736-1.64 1.64-1.64H6.67l-1.07 1.093H1.64c-.302 0-.547.245-.547.547v6.562c0 .302.245.547.547.547h10.718c.302 0 .547-.245.547-.547V3.605c0-.302-.245-.547-.547-.547h-.495l.413-.579c.126-.153.228-.321.307-.499.799.11 1.416.796 1.416 1.625z" />
                            </svg></span> <span style="padding:1px 0px 0px 4px;">Personalizable</span>
                    </div>
                    
                </div>




        </div>
        <div class="row no-margin variant-container shipping-text-revamp-hide" style="margin-top:10px; padding:0px 8px;">
            <div class="col s12 no-padding">
                <p class="shipping-text shipping-text-revamp">
                </p>

            </div>
        </div>
    </div>

</div>
                                <!--Home Page-->
<div class="product-grid-item product-grid-item-revamp col s3" data-pid="588131" data-url="/p-couple-gift-tray-with-shakers-and-personalized-mugs-149272.html"
    data-sku="J11149272" data-name="Couple Gift Tray With Shakers and Personalized Mugs" data-price="925" data-vid="318" data-personalise=true
    data-barcode="[{&quot;barcodeName&quot;:&quot;J1BXSY0006&quot;,&quot;quantity&quot;:1,&quot;ratio&quot;:25.84},{&quot;barcodeName&quot;:&quot;J1KBMC0007&quot;,&quot;quantity&quot;:1,&quot;ratio&quot;:41.34},{&quot;barcodeName&quot;:&quot;J1PZKB0001&quot;,&quot;quantity&quot;:1,&quot;ratio&quot;:10.85},{&quot;barcodeName&quot;:&quot;J1PZKB0002&quot;,&quot;quantity&quot;:1,&quot;ratio&quot;:21.96}]">
    <div class="product-item product-item-revamp z-depth-1 hoverable listing-igp">


        <div class="image-holder">
                <a class="productURL" href="/p-couple-gift-tray-with-shakers-and-personalized-mugs-149272">
                    <img src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7"
                        data-original="https://cdn.igp.com/f_auto,q_auto,t_pnoptprodlp/products/p-couple-gift-tray-with-shakers-and-personalized-mugs-149272-m.jpg"
                        class=" img-responsive product-image lazy " alt="Couple Gift Tray With Shakers and Personalized Mugs" title="Couple Gift Tray With Shakers and Personalized Mugs" data-url="/p-couple-gift-tray-with-shakers-and-personalized-mugs-149272">
                    <div class="row no-margin ">
                        <div class="col s12 no-padding">
                            <div class="product-name-w product-name-w-revamp">
                                <p class="product-name product-name-revamp">Couple Gift Tray With Shakers and Personalized Mugs</p>
                            </div>
                        </div>
                    </div>
                </a>

                <!-- Shortlist CTA area begins -->
                <div class="sl-star-wrapper sl-star-wrapper-revamp">
                    <div class="sl-star sl-star-revamp" data-pid="588131" data-pname="Couple Gift Tray With Shakers and Personalized Mugs" data-sku="J11149272"
                        data-dprice="1195" data-mprice="925" data-vid="318"
                        data-personalise=true data-in-slist="0" data-barcode="[{&quot;barcodeName&quot;:&quot;J1BXSY0006&quot;,&quot;quantity&quot;:1,&quot;ratio&quot;:25.84},{&quot;barcodeName&quot;:&quot;J1KBMC0007&quot;,&quot;quantity&quot;:1,&quot;ratio&quot;:41.34},{&quot;barcodeName&quot;:&quot;J1PZKB0001&quot;,&quot;quantity&quot;:1,&quot;ratio&quot;:10.85},{&quot;barcodeName&quot;:&quot;J1PZKB0002&quot;,&quot;quantity&quot;:1,&quot;ratio&quot;:21.96}]">
                        <div class="heart-icon" data-pid="588131" id="heart-icon-588131">
                        </div>
                    </div>
                </div>
                <!-- Shortlist CTA area ends -->

                  <div class="product-info" style="padding: 0px 8px; margin-top:8px;">
            <div style="display: flex; align-items:center;">
                
                <div class="product-price product-price-revamp" >
                    <span class="number">&#8377; 925</span> 
                    <span class="number offer offer-revamp">&#8377; 1195</span> 
                </div>

                <div class="offer-label-revamp number">23% OFF</div>
               
            </div>
        </div>

                <div class="product-info-revamp" style="margin:8px;">
                    <div class="revamp-list-rating" style="display: flex; height:14px; align-items:center;">
                        <div style="font-size: 12px; height:10px; color: #878787;">
                            <span style="margin-right: 2px;">4.5</span>
                        </div>
                        <img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img>
                        <div style="font-size: 12px; margin-left:4px; height:10px; color: #878787;">
                            (<span>124</span>)
                        </div>
                    </div>
                         <div class="pdp-lable-revamp pdp-label-best-seller">
                       Value Pack
                    </div>
                    <div class="pdp-lable-revamp pdp-lable-revamp-pers" style="height:16px; align-items:center; ">
                        <span style="height:14px;"><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" fill="none"
                                viewBox="0 0 14 14">
                                <path fill="#4F4F4F"
                                    d="M5.9 4.13c-.615.023-1.183.286-1.6.739-.638.694-.657 1.426-.673 2.072-.015.598-.03 1.163-.492 1.821l-.607.862h1.054c.083 0 .165-.001.244-.004h7.44V8.527H7.128c.205-.17.384-.348.547-.525.464-.505.66-1.163.597-1.798l3.14-4.395c.18-.21.274-.477.263-.756-.011-.292-.136-.562-.35-.76-.215-.2-.494-.302-.786-.291-.29.01-.557.133-.756.344L6.08 4.13c-.06-.002-.12-.003-.18 0zm.97 3.131c-.496.539-1.133 1.044-2.366 1.211.193-.56.205-1.066.216-1.503.015-.583.025-.968.385-1.36.219-.237.516-.374.836-.387.32-.012.627.102.863.321.49.456.519 1.226.066 1.718zm3.7-6.155l.007-.004-.019.02L7.788 5c-.072-.09-.152-.176-.239-.257-.095-.09-.198-.169-.305-.24l3.325-3.397zM14 3.605v6.562c0 .905-.736 1.64-1.64 1.64H7.546v1.095h2.844v1.093H3.609v-1.093h2.844v-1.094H1.641c-.905 0-1.641-.736-1.641-1.64V3.604c0-.905.736-1.64 1.64-1.64H6.67l-1.07 1.093H1.64c-.302 0-.547.245-.547.547v6.562c0 .302.245.547.547.547h10.718c.302 0 .547-.245.547-.547V3.605c0-.302-.245-.547-.547-.547h-.495l.413-.579c.126-.153.228-.321.307-.499.799.11 1.416.796 1.416 1.625z" />
                            </svg></span> <span style="padding:1px 0px 0px 4px;">Personalizable</span>
                    </div>
                    
                </div>




        </div>
        <div class="row no-margin variant-container shipping-text-revamp-hide" style="margin-top:10px; padding:0px 8px;">
            <div class="col s12 no-padding">
                <p class="shipping-text shipping-text-revamp">
                </p>

            </div>
        </div>
    </div>

</div>
                                <!--Home Page-->
<div class="product-grid-item product-grid-item-revamp col s3" data-pid="591092" data-url="/p-personalized-rectangle-pendant-rose-gold-153058.html"
    data-sku="M11153058" data-name="Personalized Rectangle Pendant - Rose Gold" data-price="545" data-vid="354" data-personalise=true
    data-barcode="[{&quot;barcodeName&quot;:&quot;M1PNDD2015&quot;,&quot;quantity&quot;:1,&quot;ratio&quot;:100}]">
    <div class="product-item product-item-revamp z-depth-1 hoverable listing-igp">


        <div class="image-holder">
                <a class="productURL" href="/p-personalized-rectangle-pendant-rose-gold-153058">
                    <img src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7"
                        data-original="https://cdn.igp.com/f_auto,q_auto,t_pnoptprodlp/products/p-personalized-rectangle-pendant-rose-gold-153058-m.jpg"
                        class=" img-responsive product-image lazy " alt="Personalized Rectangle Pendant - Rose Gold" title="Personalized Rectangle Pendant - Rose Gold" data-url="/p-personalized-rectangle-pendant-rose-gold-153058">
                    <div class="row no-margin ">
                        <div class="col s12 no-padding">
                            <div class="product-name-w product-name-w-revamp">
                                <p class="product-name product-name-revamp">Personalized Rectangle Pendant - Rose Gold</p>
                            </div>
                        </div>
                    </div>
                </a>

                <!-- Shortlist CTA area begins -->
                <div class="sl-star-wrapper sl-star-wrapper-revamp">
                    <div class="sl-star sl-star-revamp" data-pid="591092" data-pname="Personalized Rectangle Pendant - Rose Gold" data-sku="M11153058"
                        data-dprice="0" data-mprice="545" data-vid="354"
                        data-personalise=true data-in-slist="0" data-barcode="[{&quot;barcodeName&quot;:&quot;M1PNDD2015&quot;,&quot;quantity&quot;:1,&quot;ratio&quot;:100}]">
                        <div class="heart-icon" data-pid="591092" id="heart-icon-591092">
                        </div>
                    </div>
                </div>
                <!-- Shortlist CTA area ends -->

                  <div class="product-info" style="padding: 0px 8px; margin-top:8px;">
            <div class="row no-margin">
                <div class="col s8 no-padding">
                    <p class="product-price product-price-revamp" ><span
                            class="number">&#8377; 545</span> </p>
                </div>
                <div class="col s4 no-padding">
                    <p class="offer-p"></p>
                </div>
            </div>
        </div>

                <div class="product-info-revamp" style="margin:8px;">
                    <div class="revamp-list-rating" style="display: flex; height:14px; align-items:center;">
                        <div style="font-size: 12px; height:10px; color: #878787;">
                            <span style="margin-right: 2px;">4</span>
                        </div>
                        <img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img>
                        <div style="font-size: 12px; margin-left:4px; height:10px; color: #878787;">
                            (<span>7</span>)
                        </div>
                    </div>
                    <div class="pdp-lable-revamp pdp-lable-revamp-pers" style="height:16px; align-items:center; ">
                        <span style="height:14px;"><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" fill="none"
                                viewBox="0 0 14 14">
                                <path fill="#4F4F4F"
                                    d="M5.9 4.13c-.615.023-1.183.286-1.6.739-.638.694-.657 1.426-.673 2.072-.015.598-.03 1.163-.492 1.821l-.607.862h1.054c.083 0 .165-.001.244-.004h7.44V8.527H7.128c.205-.17.384-.348.547-.525.464-.505.66-1.163.597-1.798l3.14-4.395c.18-.21.274-.477.263-.756-.011-.292-.136-.562-.35-.76-.215-.2-.494-.302-.786-.291-.29.01-.557.133-.756.344L6.08 4.13c-.06-.002-.12-.003-.18 0zm.97 3.131c-.496.539-1.133 1.044-2.366 1.211.193-.56.205-1.066.216-1.503.015-.583.025-.968.385-1.36.219-.237.516-.374.836-.387.32-.012.627.102.863.321.49.456.519 1.226.066 1.718zm3.7-6.155l.007-.004-.019.02L7.788 5c-.072-.09-.152-.176-.239-.257-.095-.09-.198-.169-.305-.24l3.325-3.397zM14 3.605v6.562c0 .905-.736 1.64-1.64 1.64H7.546v1.095h2.844v1.093H3.609v-1.093h2.844v-1.094H1.641c-.905 0-1.641-.736-1.641-1.64V3.604c0-.905.736-1.64 1.64-1.64H6.67l-1.07 1.093H1.64c-.302 0-.547.245-.547.547v6.562c0 .302.245.547.547.547h10.718c.302 0 .547-.245.547-.547V3.605c0-.302-.245-.547-.547-.547h-.495l.413-.579c.126-.153.228-.321.307-.499.799.11 1.416.796 1.416 1.625z" />
                            </svg></span> <span style="padding:1px 0px 0px 4px;">Personalizable</span>
                    </div>
                    
                </div>




        </div>
        <div class="row no-margin variant-container shipping-text-revamp-hide" style="margin-top:10px; padding:0px 8px;">
            <div class="col s12 no-padding">
                <p class="shipping-text shipping-text-revamp">
                </p>

            </div>
        </div>
    </div>

</div>
                                <!--Home Page-->
<div class="product-grid-item product-grid-item-revamp col s3" data-pid="566931" data-url="/p-bouquet-of-10-enchanting-roses-112352.html"
    data-sku="HD1112352" data-name="Bouquet of 10 Enchanting Roses" data-price="795" data-vid="72" data-personalise=false
    data-barcode="[{&quot;barcodeName&quot;:&quot;HDIGPF1247&quot;,&quot;quantity&quot;:1,&quot;ratio&quot;:100}]">
    <div class="product-item product-item-revamp z-depth-1 hoverable listing-igp">


        <div class="image-holder">
                <a class="productURL" href="/p-bouquet-of-10-enchanting-roses-112352">
                    <img src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7"
                        data-original="https://cdn.igp.com/f_auto,q_auto,t_pnoptprodlp/products/p-bouquet-of-10-enchanting-roses-112352-m.jpg"
                        class=" img-responsive product-image lazy " alt="Bouquet of 10 Enchanting Roses" title="Bouquet of 10 Enchanting Roses" data-url="/p-bouquet-of-10-enchanting-roses-112352">
                    <div class="row no-margin ">
                        <div class="col s12 no-padding">
                            <div class="product-name-w product-name-w-revamp">
                                <p class="product-name product-name-revamp">Bouquet of 10 Enchanting Roses</p>
                            </div>
                        </div>
                    </div>
                </a>

                <!-- Shortlist CTA area begins -->
                <div class="sl-star-wrapper sl-star-wrapper-revamp">
                    <div class="sl-star sl-star-revamp" data-pid="566931" data-pname="Bouquet of 10 Enchanting Roses" data-sku="HD1112352"
                        data-dprice="0" data-mprice="795" data-vid="72"
                        data-personalise=false data-in-slist="0" data-barcode="[{&quot;barcodeName&quot;:&quot;HDIGPF1247&quot;,&quot;quantity&quot;:1,&quot;ratio&quot;:100}]">
                        <div class="heart-icon" data-pid="566931" id="heart-icon-566931">
                        </div>
                    </div>
                </div>
                <!-- Shortlist CTA area ends -->

                  <div class="product-info" style="padding: 0px 8px; margin-top:8px;">
            <div class="row no-margin">
                <div class="col s8 no-padding">
                    <p class="product-price product-price-revamp" ><span
                            class="number">&#8377; 795</span> </p>
                </div>
                <div class="col s4 no-padding">
                    <p class="offer-p"></p>
                </div>
            </div>
        </div>

                <div class="product-info-revamp" style="margin:8px;">
                    <div class="revamp-list-rating" style="display: flex; height:14px; align-items:center;">
                        <div style="font-size: 12px; height:10px; color: #878787;">
                            <span style="margin-right: 2px;">4.2</span>
                        </div>
                        <img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img>
                        <div style="font-size: 12px; margin-left:4px; height:10px; color: #878787;">
                            (<span>255</span>)
                        </div>
                    </div>
                    <div class="pdp-label pdp-lable-revamp pdp-lable-phone-revamp pdp-label-revamp-delivery-text top-right">Same Day Delivery</div>
                </div>




        </div>
        <div class="row no-margin variant-container shipping-text-revamp-hide" style="margin-top:10px; padding:0px 8px;">
            <div class="col s12 no-padding">
                <p class="shipping-text shipping-text-revamp">
                </p>

            </div>
        </div>
    </div>

</div>
                                <!--Home Page-->
<div class="product-grid-item product-grid-item-revamp col s3" data-pid="588195" data-url="/p-amethyst-gemstone-calming-tree-500-chips-149362.html"
    data-sku="J11149362" data-name="Amethyst Gemstone Calming Tree - 500 Chips" data-price="2125" data-vid="318" data-personalise=false
    data-barcode="[{&quot;barcodeName&quot;:&quot;J1BXAP0007&quot;,&quot;quantity&quot;:1,&quot;ratio&quot;:21.05},{&quot;barcodeName&quot;:&quot;J1HDBG0002&quot;,&quot;quantity&quot;:1,&quot;ratio&quot;:78.95}]">
    <div class="product-item product-item-revamp z-depth-1 hoverable listing-igp">


        <div class="image-holder">
                <a class="productURL" href="/p-amethyst-gemstone-calming-tree-500-chips-149362">
                    <img src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7"
                        data-original="https://cdn.igp.com/f_auto,q_auto,t_pnoptprodlp/products/p-amethyst-gemstone-calming-tree-500-chips-149362-m.jpg"
                        class=" img-responsive product-image lazy " alt="Amethyst Gemstone Calming Tree - 500 Chips" title="Amethyst Gemstone Calming Tree - 500 Chips" data-url="/p-amethyst-gemstone-calming-tree-500-chips-149362">
                    <div class="row no-margin ">
                        <div class="col s12 no-padding">
                            <div class="product-name-w product-name-w-revamp">
                                <p class="product-name product-name-revamp">Amethyst Gemstone Calming Tree - 500 Chips</p>
                            </div>
                        </div>
                    </div>
                </a>

                <!-- Shortlist CTA area begins -->
                <div class="sl-star-wrapper sl-star-wrapper-revamp">
                    <div class="sl-star sl-star-revamp" data-pid="588195" data-pname="Amethyst Gemstone Calming Tree - 500 Chips" data-sku="J11149362"
                        data-dprice="0" data-mprice="2125" data-vid="318"
                        data-personalise=false data-in-slist="0" data-barcode="[{&quot;barcodeName&quot;:&quot;J1BXAP0007&quot;,&quot;quantity&quot;:1,&quot;ratio&quot;:21.05},{&quot;barcodeName&quot;:&quot;J1HDBG0002&quot;,&quot;quantity&quot;:1,&quot;ratio&quot;:78.95}]">
                        <div class="heart-icon" data-pid="588195" id="heart-icon-588195">
                        </div>
                    </div>
                </div>
                <!-- Shortlist CTA area ends -->

                  <div class="product-info" style="padding: 0px 8px; margin-top:8px;">
            <div class="row no-margin">
                <div class="col s8 no-padding">
                    <p class="product-price product-price-revamp" ><span
                            class="number">&#8377; 2125</span> </p>
                </div>
                <div class="col s4 no-padding">
                    <p class="offer-p"></p>
                </div>
            </div>
        </div>

                <div class="product-info-revamp" style="margin:8px;">
                    <div class="revamp-list-rating" style="display: flex; height:14px; align-items:center;">
                        <div style="font-size: 12px; height:10px; color: #878787;">
                            <span style="margin-right: 2px;">4.3</span>
                        </div>
                        <img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img>
                        <div style="font-size: 12px; margin-left:4px; height:10px; color: #878787;">
                            (<span>7</span>)
                        </div>
                    </div>
                    
                </div>




        </div>
        <div class="row no-margin variant-container shipping-text-revamp-hide" style="margin-top:10px; padding:0px 8px;">
            <div class="col s12 no-padding">
                <p class="shipping-text shipping-text-revamp">
                </p>

            </div>
        </div>
    </div>

</div>
                                <!--Home Page-->
<div class="product-grid-item product-grid-item-revamp col s3" data-pid="583103" data-url="/p-gourmet-treats-in-gift-basket-hamper-141360.html"
    data-sku="HD1141360" data-name="Gourmet Treats in Gift Basket Hamper" data-price="1595" data-vid="72" data-personalise=false
    data-barcode="[{&quot;barcodeName&quot;:&quot;HDIGPF1524&quot;,&quot;quantity&quot;:1,&quot;ratio&quot;:100}]">
    <div class="product-item product-item-revamp z-depth-1 hoverable listing-igp">


        <div class="image-holder">
                <a class="productURL" href="/p-gourmet-treats-in-gift-basket-hamper-141360">
                    <img src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7"
                        data-original="https://cdn.igp.com/f_auto,q_auto,t_pnoptprodlp/products/p-gourmet-treats-in-gift-basket-hamper-141360-m.jpg"
                        class=" img-responsive product-image lazy " alt="Gourmet Treats in Gift Basket Hamper" title="Gourmet Treats in Gift Basket Hamper" data-url="/p-gourmet-treats-in-gift-basket-hamper-141360">
                    <div class="row no-margin ">
                        <div class="col s12 no-padding">
                            <div class="product-name-w product-name-w-revamp">
                                <p class="product-name product-name-revamp">Gourmet Treats in Gift Basket Hamper</p>
                            </div>
                        </div>
                    </div>
                </a>

                <!-- Shortlist CTA area begins -->
                <div class="sl-star-wrapper sl-star-wrapper-revamp">
                    <div class="sl-star sl-star-revamp" data-pid="583103" data-pname="Gourmet Treats in Gift Basket Hamper" data-sku="HD1141360"
                        data-dprice="0" data-mprice="1595" data-vid="72"
                        data-personalise=false data-in-slist="0" data-barcode="[{&quot;barcodeName&quot;:&quot;HDIGPF1524&quot;,&quot;quantity&quot;:1,&quot;ratio&quot;:100}]">
                        <div class="heart-icon" data-pid="583103" id="heart-icon-583103">
                        </div>
                    </div>
                </div>
                <!-- Shortlist CTA area ends -->

                  <div class="product-info" style="padding: 0px 8px; margin-top:8px;">
            <div class="row no-margin">
                <div class="col s8 no-padding">
                    <p class="product-price product-price-revamp" ><span
                            class="number">&#8377; 1595</span> </p>
                </div>
                <div class="col s4 no-padding">
                    <p class="offer-p"></p>
                </div>
            </div>
        </div>

                <div class="product-info-revamp" style="margin:8px;">
                    <div class="revamp-list-rating" style="display: flex; height:14px; align-items:center;">
                        <div style="font-size: 12px; height:10px; color: #878787;">
                            <span style="margin-right: 2px;">4.5</span>
                        </div>
                        <img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img>
                        <div style="font-size: 12px; margin-left:4px; height:10px; color: #878787;">
                            (<span>194</span>)
                        </div>
                    </div>
                    <div class="pdp-label pdp-lable-revamp pdp-lable-phone-revamp pdp-label-revamp-delivery-text top-right">Same Day Delivery</div>
                </div>




        </div>
        <div class="row no-margin variant-container shipping-text-revamp-hide" style="margin-top:10px; padding:0px 8px;">
            <div class="col s12 no-padding">
                <p class="shipping-text shipping-text-revamp">
                </p>

            </div>
        </div>
    </div>

</div>
                                <!--Home Page-->
<div class="product-grid-item product-grid-item-revamp col s3" data-pid="582358" data-url="/p-personalized-photo-canvas-140014.html"
    data-sku="L11140014" data-name="Personalized Anniversary Photo Canvas" data-price="550" data-vid="4" data-personalise=true
    data-barcode="[{&quot;barcodeName&quot;:&quot;L1HDLV0002&quot;,&quot;quantity&quot;:1,&quot;ratio&quot;:100}]">
    <div class="product-item product-item-revamp z-depth-1 hoverable listing-igp">


        <div class="image-holder">
                <a class="productURL" href="/p-personalized-photo-canvas-140014">
                    <img src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7"
                        data-original="https://cdn.igp.com/f_auto,q_auto,t_pnoptprodlp/products/p-personalized-anniversary-photo-canvas-140014-m.jpg"
                        class=" img-responsive product-image lazy " alt="Personalized Anniversary Photo Canvas" title="Personalized Anniversary Photo Canvas" data-url="/p-personalized-photo-canvas-140014">
                    <div class="row no-margin ">
                        <div class="col s12 no-padding">
                            <div class="product-name-w product-name-w-revamp">
                                <p class="product-name product-name-revamp">Personalized Anniversary Photo Canvas</p>
                            </div>
                        </div>
                    </div>
                </a>

                <!-- Shortlist CTA area begins -->
                <div class="sl-star-wrapper sl-star-wrapper-revamp">
                    <div class="sl-star sl-star-revamp" data-pid="582358" data-pname="Personalized Anniversary Photo Canvas" data-sku="L11140014"
                        data-dprice="0" data-mprice="550" data-vid="4"
                        data-personalise=true data-in-slist="0" data-barcode="[{&quot;barcodeName&quot;:&quot;L1HDLV0002&quot;,&quot;quantity&quot;:1,&quot;ratio&quot;:100}]">
                        <div class="heart-icon" data-pid="582358" id="heart-icon-582358">
                        </div>
                    </div>
                </div>
                <!-- Shortlist CTA area ends -->

                  <div class="product-info" style="padding: 0px 8px; margin-top:8px;">
            <div class="row no-margin">
                <div class="col s8 no-padding">
                    <p class="product-price product-price-revamp" ><span
                            class="number">&#8377; 550</span> </p>
                </div>
                <div class="col s4 no-padding">
                    <p class="offer-p"></p>
                </div>
            </div>
        </div>

                <div class="product-info-revamp" style="margin:8px;">
                    <div class="revamp-list-rating" style="display: flex; height:14px; align-items:center;">
                        <div style="font-size: 12px; height:10px; color: #878787;">
                            <span style="margin-right: 2px;">4.1</span>
                        </div>
                        <img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img>
                        <div style="font-size: 12px; margin-left:4px; height:10px; color: #878787;">
                            (<span>67</span>)
                        </div>
                    </div>
                    <div class="pdp-lable-revamp pdp-lable-revamp-pers" style="height:16px; align-items:center; ">
                        <span style="height:14px;"><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" fill="none"
                                viewBox="0 0 14 14">
                                <path fill="#4F4F4F"
                                    d="M5.9 4.13c-.615.023-1.183.286-1.6.739-.638.694-.657 1.426-.673 2.072-.015.598-.03 1.163-.492 1.821l-.607.862h1.054c.083 0 .165-.001.244-.004h7.44V8.527H7.128c.205-.17.384-.348.547-.525.464-.505.66-1.163.597-1.798l3.14-4.395c.18-.21.274-.477.263-.756-.011-.292-.136-.562-.35-.76-.215-.2-.494-.302-.786-.291-.29.01-.557.133-.756.344L6.08 4.13c-.06-.002-.12-.003-.18 0zm.97 3.131c-.496.539-1.133 1.044-2.366 1.211.193-.56.205-1.066.216-1.503.015-.583.025-.968.385-1.36.219-.237.516-.374.836-.387.32-.012.627.102.863.321.49.456.519 1.226.066 1.718zm3.7-6.155l.007-.004-.019.02L7.788 5c-.072-.09-.152-.176-.239-.257-.095-.09-.198-.169-.305-.24l3.325-3.397zM14 3.605v6.562c0 .905-.736 1.64-1.64 1.64H7.546v1.095h2.844v1.093H3.609v-1.093h2.844v-1.094H1.641c-.905 0-1.641-.736-1.641-1.64V3.604c0-.905.736-1.64 1.64-1.64H6.67l-1.07 1.093H1.64c-.302 0-.547.245-.547.547v6.562c0 .302.245.547.547.547h10.718c.302 0 .547-.245.547-.547V3.605c0-.302-.245-.547-.547-.547h-.495l.413-.579c.126-.153.228-.321.307-.499.799.11 1.416.796 1.416 1.625z" />
                            </svg></span> <span style="padding:1px 0px 0px 4px;">Personalizable</span>
                    </div>
                    
                </div>




        </div>
        <div class="row no-margin variant-container shipping-text-revamp-hide" style="margin-top:10px; padding:0px 8px;">
            <div class="col s12 no-padding">
                <p class="shipping-text shipping-text-revamp">
                </p>

            </div>
        </div>
    </div>

</div>
                                <!--Home Page-->
<div class="product-grid-item product-grid-item-revamp col s3" data-pid="574157" data-url="/p-shot-glasses-in-personalized-bottle-shaped-wooden-holder-124978.html"
    data-sku="M11124978" data-name="Shot Glasses in Personalized Bottle Shaped Wooden Holder" data-price="1345" data-vid="354" data-personalise=true
    data-barcode="[{&quot;barcodeName&quot;:&quot;M1PZKB0042&quot;,&quot;quantity&quot;:1,&quot;ratio&quot;:76.39},{&quot;barcodeName&quot;:&quot;M1PZKB0043&quot;,&quot;quantity&quot;:3,&quot;ratio&quot;:23.61}]">
    <div class="product-item product-item-revamp z-depth-1 hoverable listing-igp">


        <div class="image-holder">
                <a class="productURL" href="/p-shot-glasses-in-personalized-bottle-shaped-wooden-holder-124978">
                    <img src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7"
                        data-original="https://cdn.igp.com/f_auto,q_auto,t_pnoptprodlp/products/p-shot-glasses-in-personalized-bottle-shaped-wooden-holder-124978-m.jpg"
                        class=" img-responsive product-image lazy " alt="Shot Glasses in Personalized Bottle Shaped Wooden Holder" title="Shot Glasses in Personalized Bottle Shaped Wooden Holder" data-url="/p-shot-glasses-in-personalized-bottle-shaped-wooden-holder-124978">
                    <div class="row no-margin ">
                        <div class="col s12 no-padding">
                            <div class="product-name-w product-name-w-revamp">
                                <p class="product-name product-name-revamp">Shot Glasses in Personalized Bottle Shaped Wooden Holder</p>
                            </div>
                        </div>
                    </div>
                </a>

                <!-- Shortlist CTA area begins -->
                <div class="sl-star-wrapper sl-star-wrapper-revamp">
                    <div class="sl-star sl-star-revamp" data-pid="574157" data-pname="Shot Glasses in Personalized Bottle Shaped Wooden Holder" data-sku="M11124978"
                        data-dprice="0" data-mprice="1345" data-vid="354"
                        data-personalise=true data-in-slist="0" data-barcode="[{&quot;barcodeName&quot;:&quot;M1PZKB0042&quot;,&quot;quantity&quot;:1,&quot;ratio&quot;:76.39},{&quot;barcodeName&quot;:&quot;M1PZKB0043&quot;,&quot;quantity&quot;:3,&quot;ratio&quot;:23.61}]">
                        <div class="heart-icon" data-pid="574157" id="heart-icon-574157">
                        </div>
                    </div>
                </div>
                <!-- Shortlist CTA area ends -->

                  <div class="product-info" style="padding: 0px 8px; margin-top:8px;">
            <div class="row no-margin">
                <div class="col s8 no-padding">
                    <p class="product-price product-price-revamp" ><span
                            class="number">&#8377; 1345</span> </p>
                </div>
                <div class="col s4 no-padding">
                    <p class="offer-p"></p>
                </div>
            </div>
        </div>

                <div class="product-info-revamp" style="margin:8px;">
                    <div class="revamp-list-rating" style="display: flex; height:14px; align-items:center;">
                        <div style="font-size: 12px; height:10px; color: #878787;">
                            <span style="margin-right: 2px;">4.4</span>
                        </div>
                        <img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img>
                        <div style="font-size: 12px; margin-left:4px; height:10px; color: #878787;">
                            (<span>98</span>)
                        </div>
                    </div>
                    <div class="pdp-lable-revamp pdp-lable-revamp-pers" style="height:16px; align-items:center; ">
                        <span style="height:14px;"><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" fill="none"
                                viewBox="0 0 14 14">
                                <path fill="#4F4F4F"
                                    d="M5.9 4.13c-.615.023-1.183.286-1.6.739-.638.694-.657 1.426-.673 2.072-.015.598-.03 1.163-.492 1.821l-.607.862h1.054c.083 0 .165-.001.244-.004h7.44V8.527H7.128c.205-.17.384-.348.547-.525.464-.505.66-1.163.597-1.798l3.14-4.395c.18-.21.274-.477.263-.756-.011-.292-.136-.562-.35-.76-.215-.2-.494-.302-.786-.291-.29.01-.557.133-.756.344L6.08 4.13c-.06-.002-.12-.003-.18 0zm.97 3.131c-.496.539-1.133 1.044-2.366 1.211.193-.56.205-1.066.216-1.503.015-.583.025-.968.385-1.36.219-.237.516-.374.836-.387.32-.012.627.102.863.321.49.456.519 1.226.066 1.718zm3.7-6.155l.007-.004-.019.02L7.788 5c-.072-.09-.152-.176-.239-.257-.095-.09-.198-.169-.305-.24l3.325-3.397zM14 3.605v6.562c0 .905-.736 1.64-1.64 1.64H7.546v1.095h2.844v1.093H3.609v-1.093h2.844v-1.094H1.641c-.905 0-1.641-.736-1.641-1.64V3.604c0-.905.736-1.64 1.64-1.64H6.67l-1.07 1.093H1.64c-.302 0-.547.245-.547.547v6.562c0 .302.245.547.547.547h10.718c.302 0 .547-.245.547-.547V3.605c0-.302-.245-.547-.547-.547h-.495l.413-.579c.126-.153.228-.321.307-.499.799.11 1.416.796 1.416 1.625z" />
                            </svg></span> <span style="padding:1px 0px 0px 4px;">Personalizable</span>
                    </div>
                    
                </div>




        </div>
        <div class="row no-margin variant-container shipping-text-revamp-hide" style="margin-top:10px; padding:0px 8px;">
            <div class="col s12 no-padding">
                <p class="shipping-text shipping-text-revamp">
                </p>

            </div>
        </div>
    </div>

</div>
                    </div>
                </div>

            </div>

        </section>
    <!-- Editors Picks Ends -->
    <!-- Browse by categories starts -->
    <section class="bg-dark fullscreen">

        <div class="section-title bg-dark bg-light">
            <h2 class="grand-title browse-cat p-t-allign">Browse by categories</h2>
        </div>

        <div class="section-content category-c home-category-padding">
            <div class="category-grid row no-margin no-padding">
            
                <div id="homepage-categories" class="flex-column">

        <div class="grid-category">

            <div class="grid-1">
                <div class="flex-row" style="height:100%;">
                    <a style="flex:7;" href="/personalized-gifts" onclick="onclickDataLayer('category_click', {item_name:'Personalized',item_position:1,'item_url': 'https://www.igp.com/personalized-gifts' })">
                        <img class="img-responsive" id="grid-img-1" src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" data-original='https://cdn.igp.com/f_auto,q_auto,t_pnoptprodlp/banners/personalized_igp_sq_20210702' alt="Personalized"/>
                    </a>
                    <div class="flex-column" id="grid-content-1" style="padding:16px 16px 16px 16px; background: #fff; flex:3;">
                        <a class="cat-hdr" href="/personalized-gifts" onclick="onclickDataLayer('category_click', {item_name:'Personalized',item_position:1,'item_url': 'https://www.igp.com/personalized-gifts' })">Personalized</a>
                        <div class="flex-column" style="margin-top:12px;">
                                <a class="cat-nm-re" href='/personalized-home-living-gifts' onclick="onclickDataLayer('category_click', {item_name:'Personalized',item_position:1,'subitem_name': 'Home &amp; Living', 'subitem_position': 1, 'item_url': 'https://www.igp.com/personalized-home-living-gifts' })">Home &amp; Living</a>
                                <a class="cat-nm-re" href='/personalized-collectibles' onclick="onclickDataLayer('category_click', {item_name:'Personalized',item_position:1,'subitem_name': 'Collectibles', 'subitem_position': 2, 'item_url': 'https://www.igp.com/personalized-collectibles' })">Collectibles</a>
                                <a class="cat-nm-re" href='/personalized-caricatures' onclick="onclickDataLayer('category_click', {item_name:'Personalized',item_position:1,'subitem_name': 'Caricatures', 'subitem_position': 3, 'item_url': 'https://www.igp.com/personalized-caricatures' })">Caricatures</a>
                                <a class="cat-nm-re" href='/personalized-mugs-sippers' onclick="onclickDataLayer('category_click', {item_name:'Personalized',item_position:1,'subitem_name': 'Mugs', 'subitem_position': 4, 'item_url': 'https://www.igp.com/personalized-mugs-sippers' })">Mugs</a>
                                <a class="cat-nm-re" href='/personalized-cushions-pillows' onclick="onclickDataLayer('category_click', {item_name:'Personalized',item_position:1,'subitem_name': 'Cushions', 'subitem_position': 5, 'item_url': 'https://www.igp.com/personalized-cushions-pillows' })">Cushions</a>
                                <a class="cat-nm-re" href='/personalized-engraved-pen-diaries-name-gifts' onclick="onclickDataLayer('category_click', {item_name:'Personalized',item_position:1,'subitem_name': 'Pens &amp; Diaries', 'subitem_position': 6, 'item_url': 'https://www.igp.com/personalized-engraved-pen-diaries-name-gifts' })">Pens &amp; Diaries</a>
                                <a class="cat-nm-re" href='/personalized-men-accessories' onclick="onclickDataLayer('category_click', {item_name:'Personalized',item_position:1,'subitem_name': 'Mens Accessories', 'subitem_position': 7, 'item_url': 'https://www.igp.com/personalized-men-accessories' })">Mens Accessories</a>
                                <a class="cat-nm-re" href='/personalized-bar-glasses' onclick="onclickDataLayer('category_click', {item_name:'Personalized',item_position:1,'subitem_name': 'Bar Glasses', 'subitem_position': 8, 'item_url': 'https://www.igp.com/personalized-bar-glasses' })">Bar Glasses</a>
                                <a class="cat-nm-re" href='/personalized-birthday-gifts' onclick="onclickDataLayer('category_click', {item_name:'Personalized',item_position:1,'subitem_name': 'Birthday Gifts', 'subitem_position': 9, 'item_url': 'https://www.igp.com/personalized-birthday-gifts' })">Birthday Gifts</a>
                        </div>
                    </div>
                </div>
            </div>

            <div class="grid-2" style="margin-left:10px;">
                <div class="flex-column" style="height:100%;">
                    <a style="flex:1;" href="/gourmets" onclick="onclickDataLayer('category_click', {item_name:'Gourmet',item_position:2,'item_url': 'https://www.igp.com/gourmets' })">
                        <img class="img-responsive" id="grid-img-2" src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" data-original='https://cdn.igp.com/f_auto,q_auto,t_pnoptprodlp/banners/gourmet_igp_sq_20210702' alt="Gourmet"/>
                    </a>
                    <div class="flex-column" id="grid-content-2" style="padding:16px 16px 16px 16px; background: #fff; flex:1;">
                        <a class="cat-hdr" href="/gourmets" onclick="onclickDataLayer('category_click', {item_name:'Gourmet',item_position:2,'item_url': 'https://www.igp.com/gourmets' })">Gourmet</a>
                        <div class="flex-column" style="margin-top:12px;">
                                <a class="cat-nm-re" href='/sweets' onclick="onclickDataLayer('category_click', {item_name:'Gourmet',item_position:2,'subitem_name': 'Sweets', 'subitem_position': 1, 'item_url': 'https://www.igp.com/sweets' })">Sweets</a>
                                <a class="cat-nm-re" href='/dry-fruits' onclick="onclickDataLayer('category_click', {item_name:'Gourmet',item_position:2,'subitem_name': 'Dry Fruits', 'subitem_position': 2, 'item_url': 'https://www.igp.com/dry-fruits' })">Dry Fruits</a>
                                <a class="cat-nm-re" href='/chocolates' onclick="onclickDataLayer('category_click', {item_name:'Gourmet',item_position:2,'subitem_name': 'Chocolates', 'subitem_position': 3, 'item_url': 'https://www.igp.com/chocolates' })">Chocolates</a>
                                <a class="cat-nm-re" href='/sugar-free-sweets-health-hampers' onclick="onclickDataLayer('category_click', {item_name:'Gourmet',item_position:2,'subitem_name': 'Health Hampers', 'subitem_position': 4, 'item_url': 'https://www.igp.com/sugar-free-sweets-health-hampers' })">Health Hampers</a>
                                <a class="cat-nm-re" href='/snacks-gourmet-baskets' onclick="onclickDataLayer('category_click', {item_name:'Gourmet',item_position:2,'subitem_name': 'Snacks &amp; Cookies', 'subitem_position': 5, 'item_url': 'https://www.igp.com/snacks-gourmet-baskets' })">Snacks &amp; Cookies</a>
                        </div>
                    </div>
                </div>
            </div>

            <div class="grid-3" style="margin-left:10px;">
                <div class="flex-column" style="height:100%;">
                    <a style="flex:1;" href="/flowers" onclick="onclickDataLayer('category_click', {item_name:'Flowers',item_position:3,'item_url': 'https://www.igp.com/flowers' })">
                        <img class="img-responsive" id="grid-img-3" src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" data-original='https://cdn.igp.com/f_auto,q_auto,t_pnoptprodlp/banners/flowers_igp_sq_20210702' alt="Flowers"/>
                    </a>
                    <div class="flex-column" id="grid-content-3" style="padding:16px 16px 16px 16px; background: #fff; flex:1;">
                        <a class="cat-hdr" href="/flowers" onclick="onclickDataLayer('category_click', {item_name:'Flowers',item_position:3,'item_url': 'https://www.igp.com/flowers' })">Flowers</a>
                        <div class="flex-column" style="margin-top:12px;">
                                <a class="cat-nm-re" href='/roses' onclick="onclickDataLayer('category_click', {item_name:'Flowers',item_position:3,'subitem_name': 'Roses', 'subitem_position': 1, 'item_url': 'https://www.igp.com/roses' })">Roses</a>
                                <a class="cat-nm-re" href='/flowers?product_type_ef=basket-arrangements' onclick="onclickDataLayer('category_click', {item_name:'Flowers',item_position:3,'subitem_name': 'Flower Arrangements', 'subitem_position': 2, 'item_url': 'https://www.igp.com/flowers?product_type_ef=basket-arrangements' })">Flower Arrangements</a>
                                <a class="cat-nm-re" href='/exotic-flowers' onclick="onclickDataLayer('category_click', {item_name:'Flowers',item_position:3,'subitem_name': 'Exotic Flowers', 'subitem_position': 3, 'item_url': 'https://www.igp.com/exotic-flowers' })">Exotic Flowers</a>
                                <a class="cat-nm-re" href='/flowers?product_type_ef=combos' onclick="onclickDataLayer('category_click', {item_name:'Flowers',item_position:3,'subitem_name': 'Flower Combos', 'subitem_position': 4, 'item_url': 'https://www.igp.com/flowers?product_type_ef=combos' })">Flower Combos</a>
                                <a class="cat-nm-re" href='/same-day-delivery-gifts?filter_ef=gift-hamper' onclick="onclickDataLayer('category_click', {item_name:'Flowers',item_position:3,'subitem_name': 'Flower Hampers', 'subitem_position': 5, 'item_url': 'https://www.igp.com/same-day-delivery-gifts?filter_ef=gift-hamper' })">Flower Hampers</a>
                        </div>
                    </div>
                </div>
            </div>

            <div class="grid-4" style="margin-top:10px;">
                <div class="flex-row" style="height:100%;">
                    <div class="flex-column" id="grid-content-4" style="padding:16px 16px 16px 16px; background: #fff; flex:3;">
                        <a class="cat-hdr" href="/cakes" onclick="onclickDataLayer('category_click', {item_name:'Cakes',item_position:4,'item_url': 'https://www.igp.com/cakes' })">Cakes</a>
                        <div class="flex-column" style="margin-top:12px;">
                                <a class="cat-nm-re" href='/chocolate-cakes' onclick="onclickDataLayer('category_click', {item_name:'Cakes',item_position:4,'subitem_name': 'Chocolate Cakes', 'subitem_position': 1, 'item_url': 'https://www.igp.com/chocolate-cakes' })">Chocolate Cakes</a>
                                <a class="cat-nm-re" href='/black-forest-cakes' onclick="onclickDataLayer('category_click', {item_name:'Cakes',item_position:4,'subitem_name': 'Blackforest Cakes', 'subitem_position': 2, 'item_url': 'https://www.igp.com/black-forest-cakes' })">Blackforest Cakes</a>
                                <a class="cat-nm-re" href='/butterscotch-cakes' onclick="onclickDataLayer('category_click', {item_name:'Cakes',item_position:4,'subitem_name': 'Butterscotch Cakes', 'subitem_position': 3, 'item_url': 'https://www.igp.com/butterscotch-cakes' })">Butterscotch Cakes</a>
                                <a class="cat-nm-re" href='/photo-cakes' onclick="onclickDataLayer('category_click', {item_name:'Cakes',item_position:4,'subitem_name': 'Photo Cakes', 'subitem_position': 4, 'item_url': 'https://www.igp.com/photo-cakes' })">Photo Cakes</a>
                                <a class="cat-nm-re" href='/designer-cakes' onclick="onclickDataLayer('category_click', {item_name:'Cakes',item_position:4,'subitem_name': 'Designer Cakes', 'subitem_position': 5, 'item_url': 'https://www.igp.com/designer-cakes' })">Designer Cakes</a>
                                <a class="cat-nm-re" href='/pinata-cakes' onclick="onclickDataLayer('category_click', {item_name:'Cakes',item_position:4,'subitem_name': 'Pinata Cakes', 'subitem_position': 6, 'item_url': 'https://www.igp.com/pinata-cakes' })">Pinata Cakes</a>
                                <a class="cat-nm-re" href='/red-velvet-cakes' onclick="onclickDataLayer('category_click', {item_name:'Cakes',item_position:4,'subitem_name': 'Red Velvet Cakes', 'subitem_position': 7, 'item_url': 'https://www.igp.com/red-velvet-cakes' })">Red Velvet Cakes</a>
                                <a class="cat-nm-re" href='/cartoon-cakes' onclick="onclickDataLayer('category_click', {item_name:'Cakes',item_position:4,'subitem_name': 'Cartoon Cakes', 'subitem_position': 8, 'item_url': 'https://www.igp.com/cartoon-cakes' })">Cartoon Cakes</a>
                                <a class="cat-nm-re" href='/q-eggless-cake' onclick="onclickDataLayer('category_click', {item_name:'Cakes',item_position:4,'subitem_name': 'Eggless Cakes', 'subitem_position': 9, 'item_url': 'https://www.igp.com/q-eggless-cake' })">Eggless Cakes</a>
                        </div>
                    </div>
                    <a style="flex:7;" href="/cakes" onclick="onclickDataLayer('category_click', {item_name:'Cakes',item_position:4,'item_url': 'https://www.igp.com/cakes' })">
                        <img class="img-responsive" id="grid-img-4" src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" data-original='https://cdn.igp.com/f_auto,q_auto,t_pnoptprodlp/banners/cakes_igp_sq_20210708' alt="Cakes"/>
                    </a>
                </div>
            </div>

            <div class="grid-5" style="margin-left:10px; margin-top:10px;">
                <div class="flex-row" style="height:100%;">
                    <a style="flex:7; height:fit-content;" href="/home-living-gifts" onclick="onclickDataLayer('category_click', {item_name:'Home &amp; Living',item_position:5,'item_url': 'https://www.igp.com/home-living-gifts' })">
                        <img class="img-responsive" id="grid-img-5" src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" data-original='https://cdn.igp.com/f_auto,q_auto,t_cathprect/banners/home_igp_re_20210702' alt="Home &amp; Living"/>
                    </a>
                    <div class="flex-column" id="grid-content-5" style="padding:16px 16px 16px 16px; background: #fff; flex:3;">
                        <div class="flex-column" style="overflow-y:hidden;">
                            <a class="cat-hdr" href="/home-living-gifts" onclick="onclickDataLayer('category_click', {item_name:'Home &amp; Living',item_position:5,'item_url': 'https://www.igp.com/home-living-gifts' })">Home &amp; Living</a>
                            <div class="flex-column" style="margin-top:12px;">
                                    <a class="cat-nm-re" href='/home-decor-gifts' onclick="onclickDataLayer('category_click', {item_name:'Home &amp; Living',item_position:5,'subitem_name': 'Home Decor', 'subitem_position': 1, 'item_url': 'https://www.igp.com/home-decor-gifts' })">Home Decor</a>
                                    <a class="cat-nm-re" href='/kitchen-barware-gifts' onclick="onclickDataLayer('category_click', {item_name:'Home &amp; Living',item_position:5,'subitem_name': 'Kitchen &amp; Barware', 'subitem_position': 2, 'item_url': 'https://www.igp.com/kitchen-barware-gifts' })">Kitchen &amp; Barware</a>
                                    <a class="cat-nm-re" href='/furnishings' onclick="onclickDataLayer('category_click', {item_name:'Home &amp; Living',item_position:5,'subitem_name': 'Furnishings', 'subitem_position': 3, 'item_url': 'https://www.igp.com/furnishings' })">Furnishings</a>
                                    <a class="cat-nm-re" href='/photo-frames' onclick="onclickDataLayer('category_click', {item_name:'Home &amp; Living',item_position:5,'subitem_name': 'Photo Frames', 'subitem_position': 4, 'item_url': 'https://www.igp.com/photo-frames' })">Photo Frames</a>
                                    <a class="cat-nm-re" href='/stationery-desk-accessories' onclick="onclickDataLayer('category_click', {item_name:'Home &amp; Living',item_position:5,'subitem_name': 'Stationery &amp; Desk Accessories', 'subitem_position': 5, 'item_url': 'https://www.igp.com/stationery-desk-accessories' })">Stationery &amp; Desk Accessories</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>

        <div class="flex-row" style="margin-top: 10px;">

            <div style="flex:1;" class="flex-row">
                
                    <div style="width:65%;">
                        <a href="/plants" onclick="onclickDataLayer('category_click', {item_name:'Plants',item_position:6,'item_url': 'https://www.igp.com/plants' })">
                            <img class="img-responsive" id="grid-img-6" src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" data-original='https://cdn.igp.com/f_auto,q_auto,t_pnoptprodlp/banners/plants_igp_sq_20210708' alt="Plants"/>
                        </a>
                    </div>
                    <div class="flex-column cat-con" id="grid-content-6" style="padding:16px 16px 16px 16px; background: #fff; width:35%;">
                        <div class="flex-column" style="overflow: hidden;">
                            <a class="cat-hdr" href="/plants" onclick="onclickDataLayer('category_click', {item_name:'Plants',item_position:6,'item_url': 'https://www.igp.com/plants' })">Plants</a>
                            <div class="flex-column" style="margin-top:12px;">
                                    <a class="cat-nm-re-16" href='/bamboo-plants' onclick="onclickDataLayer('category_click', {item_name:'Plants',item_position:6,'subitem_name': 'Bamboo Plants', 'subitem_position': 1, 'item_url': 'https://www.igp.com/bamboo-plants' })">Bamboo Plants</a>
                                    <a class="cat-nm-re-16" href='/air-purifying-plants' onclick="onclickDataLayer('category_click', {item_name:'Plants',item_position:6,'subitem_name': 'Air Purifying Plants', 'subitem_position': 2, 'item_url': 'https://www.igp.com/air-purifying-plants' })">Air Purifying Plants</a>
                                    <a class="cat-nm-re-16" href='/personalized-plants' onclick="onclickDataLayer('category_click', {item_name:'Plants',item_position:6,'subitem_name': 'Personalized Plants', 'subitem_position': 3, 'item_url': 'https://www.igp.com/personalized-plants' })">Personalized Plants</a>
                                    <a class="cat-nm-re-16" href='/flowering-plants' onclick="onclickDataLayer('category_click', {item_name:'Plants',item_position:6,'subitem_name': 'Flowering Plants', 'subitem_position': 4, 'item_url': 'https://www.igp.com/flowering-plants' })">Flowering Plants</a>
                            </div>
                        </div>
                    </div>
                
            </div>

            <div style="flex:1; margin-left:10px;" class="flex-row">
                
                    <div style="width:65%;">
                        <a href="/fashion-lifestyle-gifts" onclick="onclickDataLayer('category_click', {item_name:'Fashion',item_position:7,'item_url': 'https://www.igp.com/fashion-lifestyle-gifts' })">
                            <img class="img-responsive" id="grid-img-7" src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" data-original='https://cdn.igp.com/f_auto,q_auto,t_pnoptprodlp/banners/fashion_igp_sq_20210702' alt="Fashion"/>
                        </a>
                    </div>
                    <div class="flex-column cat-con" id="grid-content-7" style="padding:16px 16px 16px 16px; background: #fff; width:35%;">
                        <div class="flex-column" style="overflow: hidden;">
                            <a class="cat-hdr" href="/fashion-lifestyle-gifts" onclick="onclickDataLayer('category_click', {item_name:'Fashion',item_position:7,'item_url': 'https://www.igp.com/fashion-lifestyle-gifts' })">Fashion</a>
                            <div class="flex-column" style="margin-top:12px;">
                                    <a class="cat-nm-re-16" href='/fashion-accessories' onclick="onclickDataLayer('category_click', {item_name:'Fashion',item_position:7,'subitem_name': 'Accessories', 'subitem_position': 1, 'item_url': 'https://www.igp.com/fashion-accessories' })">Accessories</a>
                                    <a class="cat-nm-re-16" href='/bags-clutches' onclick="onclickDataLayer('category_click', {item_name:'Fashion',item_position:7,'subitem_name': 'Bags &amp; Clutches', 'subitem_position': 2, 'item_url': 'https://www.igp.com/bags-clutches' })">Bags &amp; Clutches</a>
                                    <a class="cat-nm-re-16" href='/beauty-personal-care-gifts' onclick="onclickDataLayer('category_click', {item_name:'Fashion',item_position:7,'subitem_name': 'Personal Care', 'subitem_position': 3, 'item_url': 'https://www.igp.com/beauty-personal-care-gifts' })">Personal Care</a>
                                    <a class="cat-nm-re-16" href='/men-western-wear' onclick="onclickDataLayer('category_click', {item_name:'Fashion',item_position:7,'subitem_name': 'Mens Apparel', 'subitem_position': 4, 'item_url': 'https://www.igp.com/men-western-wear' })">Mens Apparel</a>
                            </div>
                        </div>
                    </div>
                
            </div>

            <div style="flex:1; margin-left:10px;" class="flex-row">
                
                    <div style="width:65%;">
                        <a href="/jewellery" onclick="onclickDataLayer('category_click', {item_name:'Jewellery',item_position:8,'item_url': 'https://www.igp.com/jewellery' })">
                            <img class="img-responsive" id="grid-img-8" src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" data-original='https://cdn.igp.com/f_auto,q_auto,t_pnoptprodlp/banners/jewllery_igp_sq_20210702' alt="Jewellery"/>
                        </a>
                    </div>
                    <div class="flex-column cat-con" id="grid-content-8" style="padding:16px 16px 16px 16px; background: #fff; width:35%;">
                        <div class="flex-column" style="overflow: hidden;">
                            <a class="cat-hdr" href="/jewellery" onclick="onclickDataLayer('category_click', {item_name:'Jewellery',item_position:8,'item_url': 'https://www.igp.com/jewellery' })">Jewellery</a>
                            <div class="flex-column" style="margin-top:12px;">
                                    <a class="cat-nm-re-16" href='/earrings-jhumkas' onclick="onclickDataLayer('category_click', {item_name:'Jewellery',item_position:8,'subitem_name': 'Earrings', 'subitem_position': 1, 'item_url': 'https://www.igp.com/earrings-jhumkas' })">Earrings</a>
                                    <a class="cat-nm-re-16" href='/pendants-necklaces' onclick="onclickDataLayer('category_click', {item_name:'Jewellery',item_position:8,'subitem_name': 'Pendants', 'subitem_position': 2, 'item_url': 'https://www.igp.com/pendants-necklaces' })">Pendants</a>
                                    <a class="cat-nm-re-16" href='/bangles-bracelets' onclick="onclickDataLayer('category_click', {item_name:'Jewellery',item_position:8,'subitem_name': 'Bracelets &amp; Bangles', 'subitem_position': 3, 'item_url': 'https://www.igp.com/bangles-bracelets' })">Bracelets &amp; Bangles</a>
                                    <a class="cat-nm-re-16" href='/accessories' onclick="onclickDataLayer('category_click', {item_name:'Jewellery',item_position:8,'subitem_name': 'Accessories', 'subitem_position': 4, 'item_url': 'https://www.igp.com/accessories' })">Accessories</a>
                                    <a class="cat-nm-re-16" href='/mens-jewellery' onclick="onclickDataLayer('category_click', {item_name:'Jewellery',item_position:8,'subitem_name': 'Mens Jewellery', 'subitem_position': 5, 'item_url': 'https://www.igp.com/mens-jewellery' })">Mens Jewellery</a>
                            </div>
                        </div>
                    </div>
                
            </div>

        </div>

</div>

            </div>
        </div>
    </section>

    <!-- Browse by categories ends -->    
    <div id="home-doc-load">
        <!-- Best999 Products Carousel start -->
        <section id="tpWrapper" class="bg-dark fullscreen">
            <div class="section-title bg-light">
                <div class="grand-title p-t-allign">Best under Rs 999</div>
            </div>
            <div class="section-content carousel">
                <div class="tp-group-wrapper">
                    <div class="row no-margin" id="tp-loader">
                        <div class="col s3">
                            <div class="product-item z-depth-1 hoverable">
                                <div class="card-image animated-background">
                                </div>
                                <div class="product-name-w product-animated-container"><p class="product-name animated-background product-animated-large">&nbsp;</p></div>
                                <div class="product-name-w product-animated-container"><p class="product-name animated-background product-animated-medium">&nbsp;</p></div>
                                <div class="product-name-w product-animated-container"><p class="product-name animated-background product-animated-small">&nbsp;</p></div>
                            </div>
                        </div>

                        <div class="col s3">
                            <div class="product-item z-depth-1 hoverable">
                                <div class="card-image animated-background">
                                </div>
                                <div class="product-name-w product-animated-container"><p class="product-name animated-background product-animated-large">&nbsp;</p></div>
                                <div class="product-name-w product-animated-container"><p class="product-name animated-background product-animated-medium">&nbsp;</p></div>
                                <div class="product-name-w product-animated-container"><p class="product-name animated-background product-animated-small">&nbsp;</p></div>
                            </div>
                        </div>

                        <div class="col s3">
                            <div class="product-item z-depth-1 hoverable">
                                <div class="card-image animated-background">
                                </div>
                                <div class="product-name-w product-animated-container"><p class="product-name animated-background product-animated-large">&nbsp;</p></div>
                                <div class="product-name-w product-animated-container"><p class="product-name animated-background product-animated-medium">&nbsp;</p></div>
                                <div class="product-name-w product-animated-container"><p class="product-name animated-background product-animated-small">&nbsp;</p></div>
                            </div>
                        </div>

                        <div class="col s3">
                            <div class="product-item z-depth-1 hoverable">
                                <div class="card-image animated-background">
                                </div>
                                <div class="product-name-w product-animated-container"><p class="product-name animated-background product-animated-large">&nbsp;</p></div>
                                <div class="product-name-w product-animated-container"><p class="product-name animated-background product-animated-medium">&nbsp;</p></div>
                                <div class="product-name-w product-animated-container"><p class="product-name animated-background product-animated-small">&nbsp;</p></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Best999 Products Carousel Ends -->
       
        <!-- Personality Cards Suggestions Starts-->
        <section class="bg-dark fullscreen pcards-cont">

            <div class="section-title bg-light">
                <h2 class="grand-title p-t-allign">Send Gifts Worldwide</h2>
            </div>

            <div class="section-content">
                <div class="pcard-group-wrapper">
                    <ul class="card-group row" id="perscards-loader">
                        <li class="col s4">
                            <div class="card z-depth-1 hoverable">
                                <div class="card-image animated-background">
                                </div>
                                <div class="card-name-w"><p class="card-name animated-background">&nbsp;</p></div>
                            </div>
                        </li>
                        <li class="col s4">
                            <div class="card z-depth-1 hoverable">
                                <div class="card-image animated-background">
                                </div>
                                <div class="card-name-w"><p class="card-name animated-background">&nbsp;</p></div>
                            </div>
                        </li>
                        <li class="col s4">
                            <div class="card z-depth-1 hoverable">
                                <div class="card-image animated-background">
                                </div>
                                <div class="card-name-w"><p class="card-name animated-background">&nbsp;</p></div>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </section>
        <!-- Personality Cards Suggestions Ends-->
    </div>
        <!-- Customer Stories Section begins -->
            <section class="bg-dark relative" id="testimonials" style="margin-top:1em;">
                <div class="section-title bg-light">
                    <h2 class="grand-title review-title">Customer Stories and Reviews</h2>
                    <div itemprop="aggregateRating" itemscope="" itemtype="http://schema.org/AggregateRating">(Rated <span itemprop="ratingValue" content="4.7">4.7</span>/5 based on <span itemprop="ratingCount" content="54856">54856</span> ratings)</div>
                </div>
                <div class="section-content carousel">
                    <div class="tp-group-wrapper">
                            <div class="trending-products-carousel1 row no-margin" id="tp-default1">
                                    <div class="col s4">
    <div class="review-card  z-depth-1" style="position:relative">
       <div class="generate-star">
              <img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img><img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img><img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img><img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img><img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img>
       </div>
            <div class="c-story-review-w">
                <div class="image-holder">
                    <a href="/p-bunch-of-pretty-15-red-roses-60552">
                        <img alt="Bouquet of 15 Red Roses" style="width:30%;" data-original="https://cdn.igp.com/f_auto,q_auto,t_prodth/products/p-bouquet-of-15-red-roses-60552-m.jpg" src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" class="img-responsive customer-story-avatar lazy" />
                    </a>
                </div>
            </div>

        <div class="feedback">
            <div class="review-name">
                <p>"Kudos to IGP for delivering at such a short notice! Thank you. The flowers were fresh and the cake was yum! "</p>
                <div class="custname">Anup Kumar Dutta</div><br>
            </div>
            <div class="review-footer">
            <div>Date: 09-03-2022</div>
            <div>Location: Kolkata</div>
            <div>Occasion: General Gifting</div>
            </div>
        </div>

    </div>
</div>

                                    <div class="col s4">
    <div class="review-card  z-depth-1" style="position:relative">
       <div class="generate-star">
              <img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img><img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img><img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img><img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img><img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img>
       </div>
            <div class="c-story-review-w">
                <div class="image-holder">
                    <a href="/p-peace-and-pride-floral-bunch-146815">
                        <img alt="Peace And Pride Floral Bunch" style="width:30%;" data-original="https://cdn.igp.com/f_auto,q_auto,t_prodth/products/p-peace-and-pride-floral-bunch-146815-m.jpg" src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" class="img-responsive customer-story-avatar lazy" />
                    </a>
                </div>
            </div>

        <div class="feedback">
            <div class="review-name">
                <p>"Flowers are very fresh and beautiful also was diliver on time, very happy "</p>
                <div class="custname">Ronak Dikav</div><br>
            </div>
            <div class="review-footer">
            <div>Date: 08-03-2022</div>
            <div>Location: New Delhi</div>
            <div>Occasion: General Gifting</div>
            </div>
        </div>

    </div>
</div>

                                    <div class="col s4">
    <div class="review-card  z-depth-1" style="position:relative">
       <div class="generate-star">
              <img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img><img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img><img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img><img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img><img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img>
       </div>
            <div class="c-story-review-w">
                <div class="image-holder">
                    <a href="/p-be-own-kind-personalized-round-crystal-132570">
                        <img alt="Be Own Kind Personalized Round Crystal" style="width:30%;" data-original="https://cdn.igp.com/f_auto,q_auto,t_prodth/products/p-be-own-kind-personalized-round-crystal-132570-m.jpg" src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" class="img-responsive customer-story-avatar lazy" />
                    </a>
                </div>
            </div>

        <div class="feedback">
            <div class="review-name">
                <p>"It&#x27;s an amazing product. Promptness in delivery and packing of the product is appreciable"</p>
                <div class="custname">Namrata Noelle</div><br>
            </div>
            <div class="review-footer">
            <div>Date: 08-03-2022</div>
            <div>Location: Navi Mumbai</div>
            <div>Occasion: General Gifting</div>
            </div>
        </div>

    </div>
</div>

                                    <div class="col s4">
    <div class="review-card  z-depth-1" style="position:relative">
       <div class="generate-star">
              <img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img><img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img><img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img><img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img><img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img>
       </div>
            <div class="c-story-review-w">
                <div class="image-holder">
                    <a href="/p-valentine-8-roses-flower-bouquet-110406">
                        <img alt="Red Rose Bouquet" style="width:30%;" data-original="https://cdn.igp.com/f_auto,q_auto,t_prodth/products/p-red-rose-bouquet-110406-m.jpg" src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" class="img-responsive customer-story-avatar lazy" />
                    </a>
                </div>
            </div>

        <div class="feedback">
            <div class="review-name">
                <p>"The delivery was very timely and the service was excellent .. "</p>
                <div class="custname">Anindita Malhotra</div><br>
            </div>
            <div class="review-footer">
            <div>Date: 08-03-2022</div>
            <div>Location: New Delhi</div>
            <div>Occasion: General Gifting</div>
            </div>
        </div>

    </div>
</div>

                                    <div class="col s4">
    <div class="review-card  z-depth-1" style="position:relative">
       <div class="generate-star">
              <img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img><img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img><img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img><img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img><img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img>
       </div>
            <div class="c-story-review-w">
                <div class="image-holder">
                    <a href="/p-sunshine-sweetness-145595">
                        <img alt="Sunshine Sweetness" style="width:30%;" data-original="https://cdn.igp.com/f_auto,q_auto,t_prodth/products/p-sunshine-sweetness-145595-m.jpg" src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" class="img-responsive customer-story-avatar lazy" />
                    </a>
                </div>
            </div>

        <div class="feedback">
            <div class="review-name">
                <p>"igp is a genuinely delivering the things as shown on website. The package received is exactly same no difference at all. I am highly impressed with igp. Thank you So much."</p>
                <div class="custname">Madhulika Singh Sis</div><br>
            </div>
            <div class="review-footer">
            <div>Date: 07-03-2022</div>
            <div>Location: Gurgaon</div>
            <div>Occasion: General Gifting</div>
            </div>
        </div>

    </div>
</div>

                                    <div class="col s4">
    <div class="review-card  z-depth-1" style="position:relative">
       <div class="generate-star">
              <img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img><img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img><img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img><img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img><img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img>
       </div>
            <div class="c-story-review-w">
                <div class="image-holder">
                    <a href="/p-fresh-fruit-almond-cake-half-kg--110227-el">
                        <img alt="Fresh Fruit Almond Cake (Eggless) (Half Kg)" style="width:30%;" data-original="https://cdn.igp.com/f_auto,q_auto,t_prodth/products/p-fresh-fruit-almond-cake-half-kg--110227-m.jpg" src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" class="img-responsive customer-story-avatar lazy" />
                    </a>
                </div>
            </div>

        <div class="feedback">
            <div class="review-name">
                <p>"Very polite customer service staff. Really nice at helping and support"</p>
                <div class="custname">Hiral Thakkar</div><br>
            </div>
            <div class="review-footer">
            <div>Date: 07-03-2022</div>
            <div>Location: Ahmedabad</div>
            <div>Occasion: General Gifting</div>
            </div>
        </div>

    </div>
</div>

                                    <div class="col s4">
    <div class="review-card  z-depth-1" style="position:relative">
       <div class="generate-star">
              <img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img><img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img><img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img><img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img><img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img>
       </div>
            <div class="c-story-review-w">
                <div class="image-holder">
                    <a href="/p-creme-rose-decorated-chocolate-cake-half-kg--140128">
                        <img alt="Creme Rose Decorated Chocolate Cake (Half Kg)" style="width:30%;" data-original="https://cdn.igp.com/f_auto,q_auto,t_prodth/products/p-creme-rose-decorated-chocolate-cake-half-kg--140128-m.jpg" src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" class="img-responsive customer-story-avatar lazy" />
                    </a>
                </div>
            </div>

        <div class="feedback">
            <div class="review-name">
                <p>"Excellent service delivery boys was very polite and helpful"</p>
                <div class="custname">Vikash Kumar  Gupta</div><br>
            </div>
            <div class="review-footer">
            <div>Date: 07-03-2022</div>
            <div>Location: Kolkata</div>
            <div>Occasion: General Gifting</div>
            </div>
        </div>

    </div>
</div>

                                    <div class="col s4">
    <div class="review-card  z-depth-1" style="position:relative">
       <div class="generate-star">
              <img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img><img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img><img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img><img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img><img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img>
       </div>
            <div class="c-story-review-w">
                <div class="image-holder">
                    <a href="/p-rose-plant-in-jute-wrapping-with-plastic-planter-118559">
                        <img alt="Rose Plant in Jute Wrapping with Planter" style="width:30%;" data-original="https://cdn.igp.com/f_auto,q_auto,t_prodth/products/p-rose-plant-in-jute-wrapping-with-planter-118559-m.jpg" src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" class="img-responsive customer-story-avatar lazy" />
                    </a>
                </div>
            </div>

        <div class="feedback">
            <div class="review-name">
                <p>"Thank you so much for duch an efficient delivery. You guys are actually connecting us with our beloved ones. God bless you all :) Kudos to the Excellent Team."</p>
                <div class="custname">Moumita Sarkar</div><br>
            </div>
            <div class="review-footer">
            <div>Date: 07-03-2022</div>
            <div>Location: Zirakhpur</div>
            <div>Occasion: General Gifting</div>
            </div>
        </div>

    </div>
</div>

                                    <div class="col s4">
    <div class="review-card  z-depth-1" style="position:relative">
       <div class="generate-star">
              <img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img><img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img><img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img><img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img><img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img>
       </div>
            <div class="c-story-review-w">
                <div class="image-holder">
                    <a href="/p-roses-carnations-in-ceramic-bowl-139339">
                        <img alt="Roses &amp; Carnations in Ceramic Bowl" style="width:30%;" data-original="https://cdn.igp.com/f_auto,q_auto,t_prodth/products/p-roses-carnations-in-ceramic-bowl-139339-m.jpg" src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" class="img-responsive customer-story-avatar lazy" />
                    </a>
                </div>
            </div>

        <div class="feedback">
            <div class="review-name">
                <p>"Super service.. always recommend IGP :-) The flowers were so fresh!!!"</p>
                <div class="custname">Mrinalini Nandi</div><br>
            </div>
            <div class="review-footer">
            <div>Date: 06-03-2022</div>
            <div>Location: Kolkata</div>
            <div>Occasion: General Gifting</div>
            </div>
        </div>

    </div>
</div>

                                    <div class="col s4">
    <div class="review-card  z-depth-1" style="position:relative">
       <div class="generate-star">
              <img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img><img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img><img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img><img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img><img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img>
       </div>
            <div class="c-story-review-w">
                <div class="image-holder">
                    <a href="/p-deep-love-with-chocolates-and-teddy-in-a-basket-153623">
                        <img alt="Deep Love With Chocolates And Teddy In A Basket" style="width:30%;" data-original="https://cdn.igp.com/f_auto,q_auto,t_prodth/products/p-deep-love-with-chocolates-and-teddy-in-a-basket-153623-m.jpg" src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" class="img-responsive customer-story-avatar lazy" />
                    </a>
                </div>
            </div>

        <div class="feedback">
            <div class="review-name">
                <p>"Nice packing and delivery man was also very polite"</p>
                <div class="custname">Krishna Keshari</div><br>
            </div>
            <div class="review-footer">
            <div>Date: 06-03-2022</div>
            <div>Location: Noida</div>
            <div>Occasion: General Gifting</div>
            </div>
        </div>

    </div>
</div>

                                    <div class="col s4">
    <div class="review-card  z-depth-1" style="position:relative">
       <div class="generate-star">
              <img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img><img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img><img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img><img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img><img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img>
       </div>
            <div class="c-story-review-w">
                <div class="image-holder">
                    <a href="/p-personalised-antique-gold-finish-notebook-and-pen-131839">
                        <img alt="Personalised Antique Gold Finish Notebook and Pen" style="width:30%;" data-original="https://cdn.igp.com/f_auto,q_auto,t_prodth/products/p-personalised-antique-gold-finish-notebook-and-pen-131839-m.jpg" src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" class="img-responsive customer-story-avatar lazy" />
                    </a>
                </div>
            </div>

        <div class="feedback">
            <div class="review-name">
                <p>"Igp I just love this app...i always place order by using igp...on every occasion...the quality and  delivery all are just another level...love igp.. "</p>
                <div class="custname">Bhavna Vashisth</div><br>
            </div>
            <div class="review-footer">
            <div>Date: 06-03-2022</div>
            <div>Location: Pune</div>
            <div>Occasion: General Gifting</div>
            </div>
        </div>

    </div>
</div>

                                    <div class="col s4">
    <div class="review-card  z-depth-1" style="position:relative">
       <div class="generate-star">
              <img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img><img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img><img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img><img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img><img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img>
       </div>
            <div class="c-story-review-w">
                <div class="image-holder">
                    <a href="/p-deliciously-healthy-gift-pack-144159">
                        <img alt="Deliciously Healthy Gift Pack" style="width:30%;" data-original="https://cdn.igp.com/f_auto,q_auto,t_prodth/products/p-deliciously-healthy-gift-pack-144159-m.jpg" src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" class="img-responsive customer-story-avatar lazy" />
                    </a>
                </div>
            </div>

        <div class="feedback">
            <div class="review-name">
                <p>"It&#x27;s really nice app &amp; the quality&#x27;s of the product is really good ..."</p>
                <div class="custname">Aayushi Aggarwal</div><br>
            </div>
            <div class="review-footer">
            <div>Date: 05-03-2022</div>
            <div>Location: Jaipur</div>
            <div>Occasion: General Gifting</div>
            </div>
        </div>

    </div>
</div>

                                    <div class="col s4">
    <div class="review-card  z-depth-1" style="position:relative">
       <div class="generate-star">
              <img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img><img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img><img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img><img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img><img style="width:14px; height:14px; margin-left:2px;" alt="half star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/half-star.svg"/>
       </div>
            <div class="c-story-review-w">
                <div class="image-holder">
                    <a href="/p-personalized-adventure-ride-caricature-with-wooden-stand-122702">
                        <img alt="Personalized Adventure Ride Caricature with Wooden Stand" style="width:30%;" data-original="https://cdn.igp.com/f_auto,q_auto,t_prodth/products/p-personalized-adventure-ride-caricature-with-wooden-stand-122702-m.jpg" src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" class="img-responsive customer-story-avatar lazy" />
                    </a>
                </div>
            </div>

        <div class="feedback">
            <div class="review-name">
                <p>"Very beautiful caricature..loved it.."</p>
                <div class="custname">Versha Sharma</div><br>
            </div>
            <div class="review-footer">
            <div>Date: 05-03-2022</div>
            <div>Location: New Delhi</div>
            <div>Occasion: General Gifting</div>
            </div>
        </div>

    </div>
</div>

                                    <div class="col s4">
    <div class="review-card  z-depth-1" style="position:relative">
       <div class="generate-star">
              <img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img><img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img><img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img><img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img><img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img>
       </div>
            <div class="c-story-review-w">
                <div class="image-holder">
                    <a href="/p-chocolate-oreo-cake-half-kg--145973">
                        <img alt="Chocolate Oreo Cake (Half kg)" style="width:30%;" data-original="https://cdn.igp.com/f_auto,q_auto,t_prodth/products/p-chocolate-oreo-cake-half-kg--145973-m.jpg" src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" class="img-responsive customer-story-avatar lazy" />
                    </a>
                </div>
            </div>

        <div class="feedback">
            <div class="review-name">
                <p>"Beautifully delivered. Looks exactly shown in the picture "</p>
                <div class="custname">vibha dhir</div><br>
            </div>
            <div class="review-footer">
            <div>Date: 05-03-2022</div>
            <div>Location: New Delhi</div>
            <div>Occasion: General Gifting</div>
            </div>
        </div>

    </div>
</div>

                                    <div class="col s4">
    <div class="review-card  z-depth-1" style="position:relative">
       <div class="generate-star">
              <img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img><img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img><img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img><img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img><img alt="full star img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/full-star.svg"></img>
       </div>
            <div class="c-story-review-w">
                <div class="image-holder">
                    <a href="/p-personalized-pillow-for-girl-113960">
                        <img alt="Personalized Pillow for Girl" style="width:30%;" data-original="https://cdn.igp.com/f_auto,q_auto,t_prodth/products/p-personalized-pillow-for-girl-113960-m.jpg" src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" class="img-responsive customer-story-avatar lazy" />
                    </a>
                </div>
            </div>

        <div class="feedback">
            <div class="review-name">
                <p>"Completely satisfied with the product and delivered on time as requested. Thank you IGP "</p>
                <div class="custname">Latha a</div><br>
            </div>
            <div class="review-footer">
            <div>Date: 04-03-2022</div>
            <div>Location: New Delhi</div>
            <div>Occasion: General Gifting</div>
            </div>
        </div>

    </div>
</div>

                </div>
                </div>
                </div>
            </section>
        <!-- Customer Stories Section ends -->
</div>

<script type="text/javascript" async src="https://accounts.google.com/gsi/client"></script>
<script>
    window.addEventListener('load', function() {
        if (typeof google !== 'undefined' && google.accounts && !($('.user-details').length)) {
            google.accounts.id.initialize({
                client_id: '775835448573-j0aeqrjolttnhh179fsm8dmsid7gplmi.apps.googleusercontent.com',
                callback: handleCredentialResponse
            });
            google.accounts.id.prompt();
        }
    }, true);
    function handleCredentialResponse (res) {
        var userData = $("#user-data");
        console.log('handleCredentialResponse', res);
        var user = {
            "gClientID": res['clientId'],
            "gCred": res['credential'],
            "usrc": userData.data('usrc'),
            "fkasid": storeid,
            "appdevice": 'desktop'
        };
        $.ajax({
            url : '/google/onetapSignIn',
            method : 'POST',
            data : {data:JSON.stringify(user)},
            beforeSend : function(xhr){
                console.log("before send");
            },
            success: function(data,status,xhr){
                console.log(JSON.stringify(data));
                if(data.status === 'Success' && data.data.l){
                    window.location.href = '/';
                }
            },
            error: function(data){
                console.log("error");
            }
        });
    }
</script>
        
<!-- Customer Stories Section begins -->


    <section id="recViewed" class="hidden"></section>


<!-- Customer Stories Section ends -->

    
        
            <form id="c-check-email" novalidate="novalidate" autocomplete="off">
                <div class="row subscription-main">
                    <div class="subscription-main-container">
                        <h6 class="subscription-main-header">Get unique &amp; trendy gift ideas and best offers delivered to your inbox.</h6>
                        <p  class="subscription-main-successPara hide">
                            Congratulations! Your newsletter subscription has been activated.<br/>We will not share your email address except as described in our Privacy Policy.
                        </p>
                        <p class="subscription-main-errorPara hide">Thank you, email-id is already subscribed with us.</p>
                        <div class="subscription-main-inpbtn">
                            <input id="c-s-user1" type="email" name="email" placeholder="enter email address" class="subscription-main-c-input-field input required email">
                            <button class="subscription-main-btn" type="submit" id="subscribeNews">Subscribe</button>
                        </div>
                        <p class="subscription-main-errorEmail hide">Please provide valid email-id</p>
                    </div>
                </div>
            </form>

    <div class="  relative footer-div">
            <div class="top-footer-wrapper">
                <div class="top-footer">
                    <div class="footer-text"><h2><strong>Welcome to IGP.com! The No.1 Online Gift Shop</strong></h2>
<p>&nbsp;</p>
<p style="font-size: 22px;"><strong>Create Blissful Memories with Unique Online Gifts</strong></p>
<p>Life is full of varied experiences and experiences count. They help us stride through tough times and make our lives meaningful. We at IGP are committed to giving you and loved one's experiences that are sure to be cherished for a very long time. We are India's best<strong> online gift store</strong> wherein you will find amazing gift ideas for all your special relationships. With an experience of over 15 years in the gifting industry, we at <strong>IGP (Indian Gifts Portal)</strong> exactly know what impact a thoughtful gift can have on the mind of the receiver. Picking a perfect gift is an art. Making the right gift selection takes planning, research, and personal attention. While selecting the best gifts for loved ones, you need to take into consideration the recipients likes and dislikes, their personality, and preferences. Also, the gift needs to be thoughtful and user-friendly at the same time. When choosing a gift for someone special, you need to put in that extra effort to ensure a "wow" moment for the receiver when the wrapping paper comes off.</p>
<p>At IGP.com, we know that you are busy. And with special occasions on the way, sometimes you recall buying a gift last-minute. Thus, we bring you the coolest and most unusual gifts online with anywhere gifts delivery in India and across the World.</p>
<p>&nbsp;</p>
<h2>Send Gifts to India, anytime and anywhere from IGP.com</h2>
<table style="width: 100%; padding: 5px;">
<thead>
<tr>
<th style="width: 13%;">
<p style="font-size: 20px;">Gifts by Type</p>
</th>
<th style="width: 15%;">
<p style="font-size: 20px;">Gift Ideas</p>
</th>
<th style="width: 15%;">
<p style="font-size: 20px;">Shipping Type</p>
</th>
</tr>
</thead>
<tbody>

<tr>
<td>
<p style="font-size: 15px;">Flowers</p>
</td>
<td class="black">
<p style="font-size: 15px;">Bouquet of Flowers, Roses, Lilies, Carnations</p>
</td>
<td class="black">
<p style="font-size: 15px;">Same Day Delivery</p>
</td>
</tr>
<tr>
<td>
<p style="font-size: 15px;">Cakes</p>
</td>
<td class="black">
<p style="font-size: 15px;">Chocolate Truffle Cake, Black Forest,&nbsp; Butterscotch Cakes, etc.</p>
</td>
<td class="black">
<p style="font-size: 15px;">Same Day &amp; Midnight Delivery</p>
</td>
</tr>
<tr>
<td>
<p style="font-size: 15px;">Plants</p>
</td>
<td class="black">
<p style="font-size: 15px;">Air Purifying Plants, Indoor Plants, Money Plants, Bamboo Plants, Medicinal Plants</p>
</td>
<td class="black">
<p style="font-size: 15px;">Free Shipping in India &amp; Abroad</p>
</td>
</tr>
<tr>
<td>
<p style="font-size: 15px;">Personalized Gifts</p>
</td>
<td class="black">
<p style="font-size: 15px;">Photo Gifts, Photo Frames, Mugs &amp; Cushions, Key-chains, LED Lights, etc.</p>
</td>
<td class="black">
<p style="font-size: 15px;">Express Delivery Worldwide</p>
</td>
</tr>
</tbody>
</table>
<h3>Raksha Bandhan 2021 - Sunday, 22nd August</h3>

<p>How much ever the brothers and sisters fight, they would surely express their love for each other on Raksha Bandhan. It is a promising day for both to protect each other from all the evils. When the date heads closer, sisters start hopping every retail outlet for beautiful rakhis. While, on the other hand, brothers fetch for the best rakhi gifts for sister.&nbsp;<br><br>To ease your daunting task, IGP.com, presents to you with a diverse range of beautiful rakhis, handmade rakhi, silver rakhi, photo rakhi and rakhi gift for sisters. Those sisters who want to celebrate Raksha Bandhan in a unique manner, we have also incorporated rakhi gift for brothers. This Raksha Bandhan 2021, deliver rakhis to your brother residing anywhere across the globe. We provide Free Shipping in India &amp; Express Delivery to USA, UK, UAE, Canada, Singapore, and Australia. If you want to <a href="https://www.igp.com/rakhi" title="send Rakhi online to India">send Rakhi online to India</a>, we also offer Same Day(One Day, within 24 Hours) or Next Day Delivery as a value-added service.</p><br>

<h3>Best Birthday Gifts for Her/Him</h3>
<p>Birthdays are truly special, whether ours or of our loved ones. Everyone looks forward to experiencing joyous celebrations. We at IGP, house best gifts online for birthdays celebrations. Our <a title="special birthday gifts" href="https://www.igp.com/birthday-gifts">special&nbsp;birthday gift</a>&nbsp;items range from cakes and flowers to accessories, to grooming gifts to toys and games, personalized gifts and much more. So if you wish to send gifts for the birthday of a dear one, you can easily do so by placing an order on our website. Order gifts online for the birthday of your sibling or your best friend and celebrate this special occasion joyously. You can easily send gifts online with a few clicks on our website.</p>
<p>&nbsp;</p>
<h3>Anniversary Gifts - Buy/Send Wedding Anniversary Gifts Online India</h3>
<p>Celebrate companionship with your beloved with gifts from IGP, India's best gifts shop. We offer impressive gifts that will steal your beloved heart once again. Buy gifts online and make your <a title="anniversary gifts" href="https://www.igp.com/anniversary-gifts">anniversary gifts</a> memorable. Choose gifts that she/he has been wanting for a long time or go for a surprise gift to create a happy moment for your beloved. Order best gifts online for your wife consisting of personalized photo frames, jewellery, apparels, traditional or contemporary handbags and so on. You can also buy fresh flowers for this special occasion comprising of roses, lilies or mixed flower bouquets. Choose mid midnight cakes and flower delivery and add an element of surprise to your special occasion. You can also celebrate anniversaries of your loved ones by choosing online gift delivery from our website. Find amazing gifts for 1st Anniversary, 5th anniversary, 10th anniversary, silver jubilee, golden jubilee of your friends, family, and colleagues.</p>
<p>&nbsp;</p>
<h3>Order Cake and Flowers Online</h3>
<p>Cakes and flower are one of the most appreciated gifts for all special occasions. IGP is an <strong>online gift shop</strong>&nbsp;that houses some of the tastiest cakes and fresh flowers. Our range of cakes comprises of tempting chocolate, black forest, strawberry, vanilla, butterscotch and much more. We also provide you designer cakes that are exclusive gifts available at IGP. We also house photo cakes in vanilla, chocolate and dark chocolate flavours. So if you wish to send Cake to Mumbai or cake to Delhi for your loved ones, you can easily do so by choosing <a title="online cake delivery India" href="https://www.igp.com/cakes">online cake delivery</a> from our website. We house fresh flower bouquets that you can pick to please a dear one on a special occasion. Fresh roses, carnations, orchids, gerberas are some flowers that are always high in demand on our website. So order cakes online along with flowers and make your dear one's occasions even more special with your thoughtful gifts. We offer same day delivery and midnight delivery of flowers and cakes in India. So pick the best flower and cake gifts for your loved ones in India even if you are abroad and celebrate their moment of joy with great fervour.</p>
<p>&nbsp;</p>
<h3>Unique Personalized Gifts</h3>
<p>Unique personalized gifts are a perfect representation of your emotions. These gifts exhibit the efforts one puts in buying a gift for the receiver. We house impressive <a title="personalized gifts" href="https://www.igp.com/personalized-gifts">personalised gifts</a> like <a href="https://www.igp.com/personalized-mugs-sippers" title="Customized Mugs">mugs</a>, <a href="https://www.igp.com/personalized-cushions-pillows" title="Personalised Cushions">cushions</a>, <a href="https://www.igp.com/photo-frames" title="Photo Frame Online">photo frames</a>, perfumes, games, kitchen and barware accessories and much more. So if you wish to send your best wishes to a recently married couple, then buy personalized photo frames and help them preserve their fond memories. You can also order personalized gifts for your boyfriend/ husband consisting of beer mugs, wine glasses, ashtrays if he is a party lover. Choose stunning personalized accessories for women like bracelets and pendant sets and express your love and affection for them.</p>
<p>&nbsp;</p>
<h3>Thank You Gifts</h3>
<p>If you want to thank someone for being one of your biggest support systems, or for being an important person in your life, or for any other reason, gifting exciting? Thank You? presents to them is a failsafe and special thing to do. We have a varied range of thank you gifts at our gift store, e.g. greeting cards, personalized cushions, canvases, puzzles, and mugs. So, send thank you gifts to your close ones on any special occasion online from IGP, and thank them in a special way!</p>
<p>&nbsp;</p>
<h3>Housewarming Gifts</h3>
<p>A new house is a source of immense happiness as it is a place that gives them a sense of belonging and helps in a peaceful and happy existence. Buying a house is a big event that is usually celebrated with utmost joy and excitement, so the housewarming gifts you buy for your close ones have to be special, too. We have a varied range of housewarming gifts, e.g. home decor gifts, kitchen and barware gifts, paintings, posters, flowers, furnishings, and personalized gifts. So, show how much their happiness means to you with exciting housewarming gifts via IGP!</p>
<p>&nbsp;</p>
<h3>Personalized Gift Cards</h3>
<p>Giving your close ones an experience that they cherish forever is the best gift you can present to them. There are plenty of unique personalized gift cards available at IGP, e.g. Amazon gift cards, Starbucks gift cards, Kohl's gift cards, Subway gift cards, and JCPenney gift cards. So, choose the perfect gift cards for your close ones based on their interests and make them feel a sudden sense of vast joy! We also have unique personalized gift cards, which you can customize with high-resolution pictures or messages, and gift card hampers. You can find <a title="gift cards online" href="https://www.igp.com/personalized-gift-cards">gift cards online</a> for any occasion at IGP, be it wedding, anniversary, birthday, and Valentine's Day. Also&nbsp;Send gift cards to USA online with Free Shipping.</p>
<p>&nbsp;</p>
<h3>Unique Gifts Delivery for Him/Her in India</h3>
<p>We know how difficult it is to find a gift for someone who has everything, and we all know one of those! Indian Gifts Portal (IGP.com) lets you discover a whole new world of perfect and unusual <strong>gift items online</strong>. We have got a plethora of <a title="gifts for men" href="https://www.igp.com/gifts-for-men">gifts for men</a> and best <a title="gift ideas for women" href="https://www.igp.com/gifts-for-women">gift ideas for women</a>. The best part about buying gifts at IGP is that we house gifts according to personality, age, relationship, and occasion. So if you are in search of gifts based on these parameters, you can easily do so on our website. We have thousands of gifts for romantic, geek, creative, fashionable and other personality types. We have got you covered for gift ideas for boyfriend, girlfriend, wife, mother, and all your special relationships. Send gifts to India&nbsp;24x7 online with Free Shipping.</p>
<p>&nbsp;</p>
<h3>Same Day Delivery Gifts - Same Day Flowers &amp; Cake Delivery Online</h3>
<p>Our flawless online gifts delivery services ensure that your gifts get delivered to the doorstep of your loved ones in time. We offer <a title="same day delivery of gifts" href="https://www.igp.com/same-day-delivery-gifts">same day delivery gifts</a> anywhere in India, especially on flowers and cakes. So if you wish to send unique best birthday gifts comprising of exclusive flower bouquet and tempting designer cakes, you can so easily do so from our website. We also provide midnight delivery of flowers and cakes in several parts of the country. So if you wish to send photo cakes along with flowers at 12 o'clock sharp, just upload an image and leave the rest to us. You can also express your love to a dear one living in India by <strong>sending gifts online</strong> from abroad through IGP. Doesn't matter from which country you are placing your order from, your gift delivery in India will happen on the same day itself. Free shipping is one another benefit why you should choose IGP as your gift delivery partner. So send gifts to India and connect with your loved ones living in the country.</p>
<p>&nbsp;</p>
<h2>Send Gifts to India from USA, UK, UAE, Canada, Australia, Singapore &amp; Worldwide with Free Shipping</h2>
<p>With a delivery network in over 90 countries and our collaboration with the best in class courier services, we ensure that the delivery of your gifts in India and worldwide happens on time. IGP is one of the best online gift sites in India that people prefer to buy gifts from irrespective of the place they are residing. We are India's preferred and only discovery-based gift shop website. We ensure that our customers remain the focus. Our algorithms to find best-suited gifts are based on the personality, age, relationship and gender of the recipient. We deliver to various countries across the globe including the <a title="Send Gifts to USA from India" href="https://www.igp.com/usa">gifts to USA&nbsp;from India</a>, the UK, Australia, Canada, UAE, Singapore and other global destinations. At IGP.com,&nbsp;find the perfect gifts online for all occasions and relationships.</p>
<p>&nbsp;</p>
<h2>Why Shop at IGP.com via Web or IGP App?</h2>
<p>As a highly reliable gift portal, IGP offers a satisfying online gifting experience to all its customers. We are known for our trustable <strong>online gift delivery</strong> service, the diverse range of gifts that we offer, and our broad gift categorization based on personality, occasion, age, and relationship helps you choose perfect gifts for your loved ones. We take immense joy in livening up the celebrations of any joyous festival or occasion for you, be it a Wedding, Anniversary, Birthday, Ganesha Chaturthi, Teachers Day,&nbsp;Diwali, Bhai Dooj, Karwa Chauth, Christmas, New Year, Pongal,&nbsp;Valentine's Day, Women's Day, Holi,&nbsp;Mother's Day, Father's Day,&nbsp;Friendship Day&nbsp;and Rakhi. Our unique offerings like midnight delivery, same day delivery, and express delivery in India set us apart, and our fully connected global network forms the basis of hassle-free international gift delivery. We provide free shipping all over India. So, choose exciting gifts for your close ones or colleagues online from IGP, and let us send your love to them on your behalf, without any inconvenience.</p>
<p>So, relish the best online gift shopping experience via IGP.com. The <b>No.1&nbsp;Online Gifting site</b>. Now SAVE MORE with <a title="IGP Coupons and Deals - Rakhi Offers" href="https://www.igp.com/offers-coupons-deals">IGP Coupons and Deals</a>. Get the latest and up-to-date coupons, Mother's Day offers, Father's Day offers, Rakhi offers, Karwa Chauth offers, Diwali offers, Bhai Dooj offers, Promo codes, Deals &amp; Discount E-Gift Cards for 2021.</p><br>

<h3>Order or Send Unique Gifts, Flowers, Cakes via <b>IGP App</b></h3>

<p>Your online gift store now at your fingertips. Now choose fresh flowers, delicious cakes, unique personalized, handmade gifts, birthday gifts, wedding anniversary gifts right from your mobile. <a href="https://www.igp.com/mobile-app" title="IGP Gift App, Birthday Gift App">IGP gift app</a> is home to hand-curated collection segmented in different categories for easy selection.</p>
<br>
<h2>Send Gifts to International Free Shipping</h2>
<p>We, at IGP, believe in letting you enliven your loved ones? a celebration of any joyous occasion with exclusive gifts, regardless of where they are. So, we also offer international shipping on all the gift categories available at our online gift store. We have a fully connected global network, and we deliver gifts across 90+ countries all over the world, e.g. Canada, UK, the US, the UAE, Singapore, New Zealand, and Australia.</p></div>
                </div>
                 <div class="read-more">Show more</div>
            </div>
           
            <a href="/sale" class="footer-banner" data-item_url='/sale' data-item_name="Sales banner" data-banner_category='footer' data-item_position="1" onclick="onclickDataLayer('banner_click', {'item_url': 'https://www.igp.com/sale', 'item_name': 'Sales banner', 'banner_category': 'footer', 'item_position':1, 'micrositename': })"><img src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" data-original="https://cdn.igp.com/f_auto,q_auto,t_pnoptprodlp/banners/igp_sale_20180216.jpg" class="img-responsive lazyIcons" alt="IGP Sale 2022" /></a>
            <a href="/covid-safety-checks" class="footer-banner" data-item_url='/covid-safety-checks' data-item_name="Covid Safety Checks" data-banner_category='footer' data-item_position="1"><img src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" data-original="https://cdn.igp.com/f_auto,q_auto,t_pnoptprodlp/banners/covid-strip-3.jpg?v=5" class="img-responsive lazyIcons" alt="Sale 2020" style="margin-top: 1em;"/></a>

    </div>

    <footer class="  relative">
        <div class="bottom-footer-wrapper">

            <div class="row no-margin stats-row">

                <div class="col s4 stats-col b-right text-center">
                    <p class="stat-value number stat-block">400+</p>

                    <p class="stat-name text-semibold">Cities having same day delivery</p>
                </div>

                <div class="col s4 stats-col b-right text-center">
                    <p class="stat-value number stat-block">100+</p>

                    <p class="stat-name text-semibold">Countries being served with happiness</p>
                </div>

                <div class="col s4 stats-col b-right text-center">
                    <p class="stat-value number stat-block">5 Million+</p>

                    <p class="stat-name text-semibold">Gift boxes delivered worldwide</p>
                </div>
                <div class="line_footer-home"></div>
            </div>
            
            <div class="row no-margin newsletter footerLinks">

               <div class="t-14ext p-b-5 mainFooterLinks">
                        <span class="ext-p-title">Know About IGP: &nbsp;</span><a class="text-semibold" href="/all-about-igp">Who We Are</a> &nbsp;|&nbsp; <a class="text-semibold" href="/press-releases">Press Releases</a> &nbsp;|&nbsp; <a class="text-semibold" href="http://listicles.igp.com/">Blog</a> &nbsp;|&nbsp; <a class="text-semibold" href="/contact-us">Contact Us</a> &nbsp;|&nbsp; <a class="text-semibold" href="/searchorder">Track Order</a> &nbsp;|&nbsp; <a class="text-semibold" href="/orderhistory">Order History</a> &nbsp;|&nbsp;<a class="text-semibold" href="/complaint">Complaints</a> &nbsp;|&nbsp; <a class="text-semibold" href="/terms">Terms &amp; Policies</a> &nbsp;|&nbsp; <a class="text-semibold" href="/faq">FAQ</a>&nbsp;|&nbsp; <a class="text-semibold" href="/privacy-policy">Privacy Policy</a>
                </div>
                <div class="t-14ext p-b-5 mainFooterLinks">
                        <a href="/gift-ideas-recipient"><span class="ext-p-title">Gifts by Recipient: &nbsp;</span></a><a class="text-semibold" href="/gifts-for-women">Gifts for Her</a> &nbsp;|&nbsp; <a class="text-semibold" href="/gifts-for-men">Gifts for Him</a> &nbsp;|&nbsp; <a class="text-semibold" href="/gifts-for-girl-6-12-year">Gifts For Girls/Teenage Girls</a> &nbsp;|&nbsp; <a class="text-semibold" href="/gifts-for-boy-3-6-year">Gifts for Boys</a> &nbsp;|&nbsp; <a class="text-semibold" href="/gifts-for-couples">Gifts for Couples</a> &nbsp;|&nbsp; <a class="text-semibold" href="/gifts-for-kids-infants">Gifts for Kids & Infants</a>
                </div>
                <div class="t-14ext p-b-5 mainFooterLinks">
                        <a href="/gift-ideas-relationship"><span class="ext-p-title">Gifts by Relationship: &nbsp;</span></a><a class="text-semibold" href="/gifts-for-husband">Gifts for Husband</a> &nbsp;|&nbsp; <a class="text-semibold" href="/gifts-for-wife">Gifts for Wife</a> &nbsp;|&nbsp; <a class="text-semibold" href="/gifts-for-boyfriend">Gifts for Boyfriend</a> &nbsp;|&nbsp; <a class="text-semibold" href="/gifts-for-girlfriend">Gifts for Girlfriend</a> &nbsp;|&nbsp; <a class="text-semibold" href="/gifts-for-father">Gifts for Father</a> &nbsp;|&nbsp; <a class="text-semibold" href="/gifts-for-mother">Gifts for Mother</a> &nbsp;|&nbsp; <a class="text-semibold" href="/gifts-for-son">Gifts for Son</a> &nbsp;|&nbsp; <a class="text-semibold" href="/gifts-for-daughter">Gifts for Daughter</a> &nbsp;|&nbsp; <a class="text-semibold" href="/gifts-for-brother">Gifts for Brother</a> &nbsp;|&nbsp; <a class="text-semibold" href="/gifts-for-sister">Gifts for Sister</a> &nbsp;|&nbsp; <a class="text-semibold" href="/gifts-for-friend">Gifts for Friend</a>
                </div>
                <div class="t-14ext p-b-5 mainFooterLinks">
                        <a href="/gift-ideas-category"><span class="ext-p-title">Gifts by Category: &nbsp;</span></a><a class="text-semibold" href="/plants">Plants</a> &nbsp;|&nbsp; <a class="text-semibold" href="/flowers">Flowers</a> &nbsp;|&nbsp; <a class="text-semibold" href="/cakes">Cakes</a> &nbsp;|&nbsp; <a class="text-semibold" href="/handmade-gifts">Handmade Gifts</a> &nbsp;|&nbsp; <a class="text-semibold" href="/personalized-gifts">Personalized Gifts</a> &nbsp;|&nbsp; <a class="text-semibold" href="/personalized-gift-cards">Gift Cards</a> &nbsp;|&nbsp; <a class="text-semibold" href="/same-day-delivery-gifts">Same Day Delivery Gifts</a> &nbsp;|&nbsp; <a class="text-semibold" href="/corporate-gifts">Corporate Gifts</a> &nbsp;|&nbsp; <a class="text-semibold" href="/home-living-gifts">Home & Living Gifts</a> &nbsp;|&nbsp; <a class="text-semibold" href="/toys-games">Kids Toys & Games</a> &nbsp;|&nbsp; <a class="text-semibold" href="/fashion-lifestyle-gifts">Fashion Lifestyle Gifts</a> &nbsp;|&nbsp; <a class="text-semibold" href="/jewellery">Jewellery Gifts</a> &nbsp;|&nbsp; <a class="text-semibold" href="/gourmets">Gourmet Gifts</a>
                </div>
                <div class="t-14ext p-b-5 mainFooterLinks">
                        <a href="/gift-ideas-festivals"><span class="ext-p-title">Gift Ideas by Festivals/Occasions: &nbsp;</span></a><a class="text-semibold" href="/mothers-day">Mother's Day</a> &nbsp;|&nbsp; <a class="text-semibold" href="/fathers-day">Father's Day</a> &nbsp;|&nbsp; <a class="text-semibold" href="/gifts-for-parents">Parents Day Gifts</a> &nbsp;|&nbsp; <a class="text-semibold" href="/friendship-day-gifts">Friendship Day</a> &nbsp;|&nbsp; <a class="text-semibold" href="/rakhi">Rakhi</a> &nbsp;|&nbsp; <a class="text-semibold" href="/teachers-day-gifts">Teacher's Day</a> &nbsp;|&nbsp; <a class="text-semibold" href="/grandparents-day-gifts">Grandparents Day</a> &nbsp;|&nbsp; <a class="text-semibold" href="/gifts-for-daughter">Daughter's Day Gifts</a> &nbsp;|&nbsp; <a class="text-semibold" href="/boss-day-gifts">Boss Day</a> &nbsp;|&nbsp; <a class="text-semibold" href="/diwali">Diwali</a> &nbsp;|&nbsp; <a class="text-semibold" href="/bhai-dooj">Bhaidooj</a> &nbsp;|&nbsp; <a class="text-semibold" href="/karwa-chauth">Karwa Chauth</a> &nbsp;|&nbsp; <a class="text-semibold" href="/christmas">Christmas</a> &nbsp;|&nbsp; <a class="text-semibold" href="/new-year">New Year</a> &nbsp;|&nbsp; <a class="text-semibold" href="/lohri">Lohri</a> &nbsp;|&nbsp; <a class="text-semibold" href="/valentines-day">Valentine's Day</a> &nbsp;|&nbsp; <a class="text-semibold" href="/holi">Holi</a> &nbsp;|&nbsp; <a class="text-semibold" href="/womens-day-gifts">Women's Day</a>
                </div>
                <div class="t-14ext p-b-5 mainFooterLinks">
                        <a href="/gift-ideas-occasion"><span class="ext-p-title">Gift Ideas by Special Occasions: &nbsp;</span></a><a href="/birthday-gifts" class="text-semibold">Birthday</a> &nbsp;|&nbsp; <a href="/anniversary-gifts" class="text-semibold">Anniversary</a> &nbsp;|&nbsp; <a href="/wedding-gifts" class="text-semibold">Wedding</a> &nbsp;|&nbsp; <a href="/housewarming-gifts" class="text-semibold">Housewarming</a> &nbsp;|&nbsp; <a href="/best-wishes-gifts" class="text-semibold">Best Wishes</a> &nbsp;|&nbsp; <a href="/baby-shower-gifts" class="text-semibold">Baby Shower</a>
                </div>
            </div>
            <div class="clear"></div>

            <div class="line_footer2-home"></div>

                <div class="extended-footer">
                    <div class="ext-footer-body">
                            <div class="ext-footer-row"  data-canonicalurl="/www.igp.com">
        <span class="ext-p-title">
            
                 POPULAR SEARCHES AT IGP 2022 
            
        </span> 
         <span class="ext-p-title-arrow"> >> </span> 
            <span class="ext-c-title">
                 
            </span>
            

                <span class="child">
                            <a href="/valentines-day" title="Valentines Day Gifts">

                    Lovers Day Gift

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/valentines-day-gifts-for-him" title="Valentine Gifts for Him">

                    Valentines Day Gifts for Him

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/valentines-day-gifts-for-her" title="Valentine&#x27;s Day Gifts for Her">

                    Valentines Day Gifts for Her

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/valentines-day-gifts-for-husband" title="Valentines Day Gifts for Husband">

                    Valentines Day Gifts for Husband

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/valentines-day-gifts-for-wife" title="Valentines Day Gifts for Wife">

                    Valentine Day Gift for Wife

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/valentines-day-gifts-for-boyfriend" title="Valentine Gifts for Boyfriend">

                    Valentine Gifts for Boyfriend

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/valentines-day-gifts-for-girlfriend" title="Valentine Gifts for Girlfriend">

                    Valentine Gifts for Girlfriend

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/valentines-day-week-gifts" title="Valentine Week Days Gifts">

                    Valentine Week Gifts for Boyfriend/Girlfriend

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/valentines-day-teddy-bears" title="Valentines Day Teddy Bears">

                    Valentines Day Teddy Bears

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/valentines-day-romantic-love-gifts-for-her" title="Valentine&#x27;s Day Romantic Gifts for Her">

                    Love Gifts for Her

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/valentines-day-romantic-love-gifts-for-him" title="Romantic Valentine Gifts for Him">

                    Valentine&#x27;s Day Romantic Love Gifts for Him

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/valentines-day-gifts-to-usa-free-shipping" title="Valentine&#x27;s Day Gifts to USA">

                    Valentine Gifts to USA

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/valentines-day-gifts-to-canada-free-shipping" title="Valentine&#x27;s Day Gifts to Canada">

                    Valentine Gifts to Canada

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/valentines-day-gifts-to-uk" title="Valentines Day Gifts to UK">

                    Valentine Gifts to UK

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/valentines-day-gifts-to-australia" title="Valentines Day Gifts to Australia">

                    Valentine Gifts to Australia

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/valentines-day-gifts-to-uae" title="Valentines Day Gifts to UAE">

                    Valentine Gifts to UAE

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/valentines-day-gifts-worldwide-free-shipping" title="Send Valentines Gifts Worldwide">

                    Send Valentine Gifts to Worldwide

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/valentines-day/mumbai" title="Valentine&#x27;s Day Gifts to Mumbai">

                    Send Valentines Day Gifts to Mumbai

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/valentines-day/new-delhi" title="Valentine&#x27;s Day Gifts to Delhi">

                    Valentine Gifts to Delhi

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/valentines-day/kolkata" title="Send Valentine&#x27;s Day Gifts to Kolkata">

                    Valentine Gifts to Kolkata

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/valentines-day/chennai" title="Send Valentine&#x27;s Day Gifts to Chennai">

                    Valentine Gifts to Chennai

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/valentines-day/bengaluru" title="Valentine&#x27;s Day Gifts to Bangalore">

                    Valentine Gifts to Bangalore

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/valentines-day/jaipur" title="Valentine&#x27;s Day Gifts to Jaipur">

                    Valentine Gifts to Jaipur

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/valentines-day/hyderabad" title="Valentine&#x27;s Day Gifts to Hyderabad">

                    Valentine Gifts to Hyderabad

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/valentines-day/pune" title="Send Valentine&#x27;s Day Gifts to Pune">

                    Valentine Gifts to Pune

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/valentines-day/ahmedabad" title="Send Valentine&#x27;s Day Gifts to Ahmedabad">

                    Valentine Gifts to Ahmedabad

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/valentines-day/chandigarh" title="Send Valentine&#x27;s Day Gifts to Chandigarh">

                    Valentine Gifts for Husband to Chandigarh

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/valentines-day/gurgaon" title="Send Valentine&#x27;s Day Gifts to Gurgaon">

                    Valentine Gifts to Gurgaon

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/valentines-day/lucknow" title="Send Valentine&#x27;s Day Gifts to Lucknow">

                    Valentine Gifts to Lucknow

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/valentines-day-personalized-gifts" title="Personalized Valentines Day Gifts">

                    Personalized Valentine&#x27;s Day Gifts

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/valentines-day-personalized-heart-shaped-gifts" title="Heart Themed Gifts">

                    Heart Shaped Gifts

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/valentines-day-personalized-photo-gifts" title="Personalized Photo Gifts for Valentines Day">

                    Valentines Day Photo Frame Gift

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/valentines-day-flowers" title="Valentines Day Flowers">

                    Valentine&#x27;s Day Flowers

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/valentines-day-roses" title="Valentine&#x27;s Day Roses">

                    Valentines Day Roses

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/valentines-day-cakes" title="Valentine&#x27;s Day Cakes">

                    Valentines Day Cake

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/flowers-with-cake" title="Cake and Flowers Combo">

                    Cake and Flower Delivery

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/roses" title="Roses">

                    Roses Online Delivery

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/red-flowers" title="Red Flowers">

                    Red Roses Online

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/birthday-flowers" title="Birthday Flowers">

                    Birthday Flowers

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/anniversary-flowers" title="Anniversary Flowers">

                    Anniversary Flowers

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/birthday-cakes" title="Birthday Cakes">

                    Birthday Cake

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/anniversary-cakes" title="Anniversary Cake Online">

                    Anniversary Cake

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/birthday-gifts" title="Birthday Gifts">

                    Gifts for Birthday

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/birthday-gifts-for-mother" title="Birthday Gifts for Mother">

                    Birthday Gifts for Mother

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/birthday-gifts-for-father" title="Birthday Gifts for Father">

                    Birthday Gifts for Father

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/birthday-gifts-for-husband" title="Birthday Gifts for Husband">

                    Birthday Gifts for Husband

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/birthday-gifts-for-wife" title="Birthday Gifts for Wife">

                    Birthday Gifts for Wife

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/birthday-gifts-for-men" title="Birthday Gifts for Men">

                    Birthday Gifts for Him

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/birthday-gifts-for-women" title="Birthday Gifts for Women">

                    Birthday Gifts for Her

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/birthday-gifts-for-girlfriend" title="Birthday Gifts for Girlfriend">

                    Birthday Gifts for Girlfriend

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/birthday-gifts-for-boyfriend" title="Birthday Gifts for Boyfriend">

                    Birthday Gifts for Boyfriend

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/anniversary-gifts-for-husband" title="Anniversary Gifts for Husband">

                    Anniversary Gifts for Husband

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/anniversary-gifts-for-wife" title="Anniversary Gifts for Wife">

                    Anniversary Gifts for Wife

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/anniversary-gifts-for-couples" title="Anniversary Gifts for Couples">

                    Anniversary Gifts for Couples

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/anniversary-gifts-for-parents" title="Anniversary Gifts for Parents">

                    Anniversary Gifts for Parents

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/anniversary-gifts" title="Anniversary Gifts">

                    Anniversary Gifts

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/wedding-gifts" title="Wedding Gifts Online">

                    Wedding Gifts

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/wedding-gifts-for-friend" title="Wedding Gifts for Friend">

                    Wedding Gifts for Friend

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/wedding-gifts-for-brother" title="Wedding Gifts for Brother">

                    Wedding Gifts for Brother

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/wedding-gifts-for-sister" title="Wedding Gifts for Sister">

                    Wedding Gifts for Sister

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/personalized-anniversary-gifts" title="Personalized Anniversary Gifts">

                    Personalized Anniversary Gifts

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/personalized-wedding-gifts" title="Personalized Wedding Gifts">

                    Personalized Wedding Gifts

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/personalized-gifts" title="Personalized Gifts">

                    Personalised Gifts

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/personalized-gifts-for-him" title="Personalized Gifts for Him">

                    Personalized Gifts for Him

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/personalized-gifts-for-her" title="Personalized Gifts for Her">

                    Personalized Gifts for Her

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/personalized-photo-gifts" title="Photo Gifts">

                    Personalized Photo Gifts 

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/personalized-birthday-gifts" title="Birthday Gifts">

                    Personalized Birthday Gifts

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/personalized-mugs-sippers" title="Personalized Mugs">

                    Personalised Mugs 

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/personalized-photo-frames" title="Personalised Photo Frames">

                    Personalized Photo Frames

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/sarees" title="Sarees Online">

                    Sarees Online Shopping

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/jewellery" title="Jewellery Gifts">

                    Jewellery Gifts for Valentine&#x27;s Day

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/kurtis" title="Women&#x27;s Kurtis">

                    Kurtis Online Shopping

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/gifts-for-religious" title="Religious Gifts">

                    Religious Gifts for Him/Her

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/teddy-bears" title="Teddy Bear Online">

                    Teddy Bear Online

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/sweets" title="Sweets">

                    Sweets Online

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/dry-fruits" title="Dry Fruits">

                    Dry Fruits

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/chocolates" title="Chocolates">

                    Valentine Chocolates Box

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/puja-accessories" title="Pooja Accessories">

                    Pooja Items Online

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/valentines-day-bestseller-gifts" title="Valentine&#x27;s Day Best Sellers">

                    Valentine&#x27;s Day Bestseller Gifts

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/valentines-day-soft-toys" title="Valentines Soft Toys Gifts">

                    Valentine&#x27;s Day Soft Toys

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/flowers-with-teddy" title="Flowers With Teddy Bears Online">

                    Flowers with Teddy

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/q-rose-bookey-online" title="">

                    Rose Bookey Online

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/personalized-jewellery" title="Custom Name Pendant">

                    Customised Jewelry

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/valentines-day-regular-cakes" title="Valentine&#x27;s Day Regular Cakes">

                    Love Shaped Cakes

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/valentines-day-heart-shaped-cakes" title="Valentine Heart Shaped Cakes">

                    Heart Shaped Valentine Chocolate Cake

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/valentines-day-greeting-cards-for-her" title="Valentines Day Greeting Cards for Her">

                    Valentine Day Greeting Card

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/valentines-day-chocolate-cakes" title="Valentine Chocolate Cakes">

                    Valentines Day Chocolate Cakes

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/gifts-for-men" title="Gifts for Men">

                    Valentine Gifts for Him Romantic

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/valentines-day-couple-t-shirts" title="Apparels for Him">

                    Valentines Day t-Shirts

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/valentines-day-romantic-chocolate-hampers" title="Valentines Romantic Chocolate Hampers">

                    Valentine&#x27;s Day Chocolate Hampers

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/gifts-for-girl-6-12-year" title="Gifts for Girls">

                    Valentine Gifts for Girls

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/gifts-for-boy-6-12-year" title="Gifts for Boys">

                    Valentine Gifts for Boys

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/gifts-for-boyfriend" title="Gifts for Boyfriend">

                    First Valentines Presents for Boyfriend

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/p-heart-shaped-red-velvet-cake-half-kg--109167" title="">

                    Heart Shape Red Velvet Cake

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/heart-shaped-cakes" title="Heart Shaped Cakes">

                    Love|Heart Shaped Cakes

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/photo-frames" title="Photo Frame Online">

                    Photo Frames for Valentines Day

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/gifts-for-romantic-husband" title="Valentines Day Gifts for Husband">

                    Romantic Gifts for Husband

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/valentines-day-handbags-clutches-for-her" title="Valentines Handbags and Clutches for Her">

                    Handbags &amp; Clutches for Her

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/valentines-day-fashion-trendy-gifts-for-her" title="Valentines Fashion Gifts for Her">

                    Fashion Gifts for Her

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/valentines-day-jewellery-gifts-for-her" title="Jewellery &amp; Watches Gifts for Her">

                    Valentine&#x27;s Jewellery|Rings for Her

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/p-i-love-you-personalized-photo-frame-109417" title="">

                    I love you photo frame

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/p-personalized-led-bottle-lamp-78650" title="">

                    LED Lights &amp; Bottle Lamp

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/p-colorful-personalized-rotating-crystal-cube-with-led-46756" title="">

                    Crystal Cube with LED Light

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/p-silver-sequin-personalized-magic-pillow-74133" title="">

                    Customised Magic Pillow

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/p-rose-gold-toned-heart-pendant-necklace-125097" title="">

                    Rose Gold Heart Shapes Necklace

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/p-love-memories-personalized-wooden-photo-frame-75303" title="">

                    Love Wooden Photo Frame

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/p-birthday-wishes-personalized-greeting-card-46629" title="">

                    Personalised Greeting Cards

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/p-led-keychain-124812" title="">

                    Led Keychain

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/p-black-forest-cake-half-kg--13461" title="">

                    Black Forest Cake Order Online

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/p-heart-shaped-basket-of-red-roses-with-teddy-112472" title="">

                    Heart Shaped Red Roses with Teddy

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/p-valentine-day-personalized-planter-pot-set-78640" title="">

                    Valentine&#x27;s Day Craft Pots|Planter Pot Set

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/p-personalized-ceramic-planters-set-for-mom-81853" title="">

                    Ceramic Plant Pots

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/p-heart-shaped-personalized-led-fur-cushion-72982" title="">

                    Heart Shaped LED Cushions

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/rose-day" title="Rose Day Gifts">

                    7th Feb Rose Day

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/propose-day" title="Propose Day Gifts">

                    8th Feb Propose Day

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/chocolate-day" title="Chocolate Day">

                    9th Feb Chocolate Day

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/teddy-day" title="Teddy Day Gifts">

                    10th Feb Teddy Day

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/promise-day" title="Promise Day Gifts">

                    11th Feb Promise Day

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/hug-day" title="Hug Day Gifts">

                    12th Feb Hug Day

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/kiss-day" title="Kiss Day Gifts">

                    13th Feb Kiss Day

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/gifts-for-couples" title="Gifts for Couples">

                    Romantic Gifts for Couples

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/valentines-day/valentines-day-gifts-for-friend" title="Valentine Gifts for Friends">

                    Valentine Gifts for Friend

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/valentines-day-personalized-mugs-cushions" title="Valentine&#x27;s Day Personalized Mugs &amp; Cushions">

                    Valentine Mugs &amp; Cushions

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/valentines-day-sale" title="Valentines Day Sale - Upto 60% Off">

                    Valentines Day Sale

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/offers-coupons-deals" title="">

                    Valentines Day Offers 2022

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/valentines-day-express-delivery" title="Valentine&#x27;s Day Gifts Same Day Delivery">

                    Valentines Day Gifts Same Day Delivery

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/valentines-day-chocolate-gifts" title="Valentines Chocolate Gift Packs">

                    Valentine Chocolates

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/valentines-day-chocolates-soft-toys" title="Valentine Chocolates &amp; Soft Toys Online">

                    Chocolates &amp; Soft Toys

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/valentines-day-valentine-serenades-gifts" title="Valentine&#x27;s Day Serenades">

                    Serenades

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/cakes" title="Order Cakes Online">

                    Order Cakes Online

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/flowers" title="Online Flower Delivery">

                    Online Flower Delivery

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/usa/cakes" title="Send Cakes to USA Online">

                    Send Cakes to USA

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/cakes/bengaluru" title="Cake Delivery in Bangalore">

                    Cake Delivery in Bangalore

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/cakes/chennai" title="Cake Delivery in Chennai">

                    Cake Delivery in Chennai

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/cakes/gurgaon" title="Cake Delivery in Gurgaon">

                    Cake Delivery in Gurgaon

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/cakes/hyderabad" title="Cake Delivery in Hyderabad">

                    Cake Delivery in Hyderabad

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/cakes/kolkata" title="Cake Delivery in Kolkata">

                    Cake Delivery in Kolkata

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/cakes/lucknow" title="Cake Delivery in Lucknow">

                    Cake Delivery in Lucknow

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/cakes/mumbai" title="Send Cakes to Mumbai">

                    Send Cakes to Mumbai

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/cakes/new-delhi" title="Cake Delivery in Delhi">

                    Send Cakes to Delhi

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/cakes/noida" title="Cake Delivery in Noida">

                    Send Cakes to Noida

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/cakes/pune" title="Cake Delivery in Pune">

                    Send Cakes to Pune

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/cakes/ahmedabad" title="Send Cakes to Ahmedabad">

                    Send Cakes to Ahmedabad

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/usa/flowers" title="Send Flowers to USA">

                    Send Flowers to USA

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/flowers/bengaluru" title="Flower Delivery in Bangalore">

                    Flower Delivery in Bangalore

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/flowers/chennai" title="Send Flowers to Chennai">

                    Flower Delivery in Chennai

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/flowers/gurgaon" title="Flower Delivery in Gurgaon">

                    Flower Delivery in Gurgaon

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/flowers/hyderabad" title="Send Flowers to Hyderabad">

                    Flower Delivery in Hyderabad

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/flowers/kolkata" title="Flower Delivery in Kolkata">

                    Flower Delivery in Kolkata

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/flowers/lucknow" title="Send Flowers to Lucknow">

                    Flower Delivery in Lucknow

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/flowers/mumbai" title="Send Flowers to Mumbai">

                    Send Flowers to Mumbai

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/flowers/new-delhi" title="Send flowers to Delhi">

                    Send Flowers to Delhi

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/flowers/noida" title="Send Flowers to Noida">

                    Send Flowers to Noida

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/flowers/pune" title="Send Flowers to Pune">

                    Send Flowers to Pune

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/flowers/ahmedabad" title="Flower Delivery in Ahmedabad">

                    Send Flowers to Ahmedabad

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/same-day-delivery-gifts" title="Same Day Delivery Gifts">

                    Same Day Delivery Gifts

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/corporate-gifts" title="">

                    Corporate Gifts

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/usa" title="Gifts to USA - Free Shipping">

                    Send Love Gifts to USA

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/uk" title="Send Gifts to UK">

                    Send Gifts to London, UK

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/canada" title="Gifts to Canada - Free Shipping">

                    Send Love Gifts to Canada

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/uae" title="Send Gifts to UAE (Dubai)">

                    Send Romantic Love Gifts to Dubai, UAE

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/australia" title="Send Gifts to Australia">

                    Send Love Gifts to Australia

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/singapore" title="Send Gifts to Singapore">

                    Send Gifts to Singapore

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/business" title="">

                    Employee Rewards and Recognition

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/covid19-prevention-gear" title="Covid19 Prevention Gear">

                    Covid19 Prevention Gear Kit: Face Masks, Immunity Booster Gift Basket, Corona Non-Contact Infrared Thermometer

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/covid-safety-checks" title="">

                    Coronavirus (COVID-19) Safety Measures

                            </a>
                </span>
                
    </div>
    <div class="ext-footer-row"  data-canonicalurl="/www.igp.com">
        <span class="ext-p-title">
            
                 Send Gifts to India 
            
        </span> 
         <span class="ext-p-title-arrow"> >> </span> 
            <span class="ext-c-title">
                 
            </span>
            

                <span class="child">
                            <a href="/mumbai" title="Online Gift Delivery in Mumbai">

                    Online Gift Delivery Mumbai

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/new-delhi" title="Gifts to Delhi">

                    Online Gift Delivery Delhi

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/bengaluru" title="Send Gifts to Bangalore">

                    Online Gift Delivery Bangalore

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/chennai" title="Send Gifts to Chennai">

                    Online Gift Delivery Chennai

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/hyderabad" title="Send Gifts to Hyderabad">

                    Online Gift Delivery Hyderabad

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/kolkata" title="Send Gifts to Kolkata">

                    Online Gift Delivery Kolkata

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/pune" title="Send Gifts to Pune">

                    Pune Online Gifts

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/gurgaon" title="Send Gifts to Gurgaon">

                    Gurgaon Online Gifts

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/noida" title="Send Gifts to Noida">

                    Send Gifts to Noida

                            </a>
                </span>
                
    </div>
    <div class="ext-footer-row"  data-canonicalurl="/www.igp.com">
        <span class="ext-p-title">
            
                 Send Gifts to USA &amp; Worldwide 
            
        </span> 
         <span class="ext-p-title-arrow"> >> </span> 
            <span class="ext-c-title">
                 
            </span>
            

                <span class="child">
                            <a href="/usa" title="Gifts to USA - Free Shipping">

                    Send Gifts to USA

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/usa/bestsellers" title="Send Bestselling Gifts to USA (Free Shipping)">

                    BestSelling Gifts to USA

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/usa/flowers" title="Send Flowers to USA">

                    Send Flowers to USA

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/usa/cakes" title="Send Cakes to USA Online">

                    Send Cakes to USA

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/usa/chocolates" title="Send Chocolates to USA">

                    Send Chocolates to USA

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/usa/sweets-dryfruits" title="Send Sweets &amp; Dry Fruits to USA">

                    Send Sweets to USA

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/usa/jewellery" title="Send JeweIlery Gifts to USA">

                    Jewellery to USA

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/usa/gift-cards" title="Send Gift Cards to USA">

                    Gift Cards to USA

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/usa/personalized-gifts" title="Send Personalized Gifts to USA">

                    Personalized Gifts to USA

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/uk" title="Send Gifts to UK">

                    Gifts to UK

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/canada" title="Gifts to Canada - Free Shipping">

                    Gifts to Canada

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/uae" title="Send Gifts to UAE (Dubai)">

                    Gifts to UAE

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/australia" title="Send Gifts to Australia">

                    Gifts to Australia

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/singapore" title="Send Gifts to Singapore">

                    Gifts to Singapore

                            </a>
                </span>
                
    </div>
    <div class="ext-footer-row"  data-canonicalurl="/www.igp.com">
        <span class="ext-p-title">
            
                 Send Flowers to 
            
        </span> 
         <span class="ext-p-title-arrow"> >> </span> 
            <span class="ext-c-title">
                 
            </span>
            

                <span class="child">
                            <a href="/flowers" title="Online Flower Delivery">

                    Send Flowers Online

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/flowers/new-delhi" title="Send flowers to Delhi">

                    Flower Delivery in Delhi

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/flowers/gurgaon" title="Flower Delivery in Gurgaon">

                    Send Flowers to Gurgaon

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/flowers/noida" title="Send Flowers to Noida">

                    Send Flowers to Noida

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/flowers/faridabad" title="Send Flowers to Faridabad">

                    Send Flowers to Faridabad

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/flowers/jaipur" title="Flower Delivery in Jaipur">

                    Send Flowers to Jaipur

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/flowers/ghaziabad" title="Send Flowers to Ghaziabad">

                    Send Flowers to Ghaziabad

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/flowers/mumbai" title="Send Flowers to Mumbai">

                    Flower Delivery in Mumbai

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/flowers/ahmedabad" title="Flower Delivery in Ahmedabad">

                    Flower Delivery in Ahmedabad

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/flowers/bengaluru" title="Flower Delivery in Bangalore">

                    Send Flowers to Bangalore

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/flowers/chennai" title="Send Flowers to Chennai">

                    Send Flowers to Chennai

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/flowers/pune" title="Send Flowers to Pune">

                    Send Flowers to Pune

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/flowers/hyderabad" title="Send Flowers to Hyderabad">

                    Flower Delivery in Hyderabad

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/flowers/kolkata" title="Flower Delivery in Kolkata">

                    Order Flower in Kolkata

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/flowers/chandigarh" title="Send Flowers to Chandigarh">

                    Send Flowers to Chandigarh

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/same-day-delivery-gifts" title="Same Day Delivery Gifts">

                    Same Day Flowers Delivery

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/flowers/flowers-with-chocolates" title="">

                    Flowers with Chocolate Delivery

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/flowers-bouquets-bunches" title="Flower Bouquet">

                    Flowers Bouquet &amp; Bunches

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/roses" title="Roses">

                    Send Roses

                            </a>
                </span>
                
    </div>
    <div class="ext-footer-row"  data-canonicalurl="/www.igp.com">
        <span class="ext-p-title">
            
                 Send Cakes to 
            
        </span> 
         <span class="ext-p-title-arrow"> >> </span> 
            <span class="ext-c-title">
                 
            </span>
            

                <span class="child">
                            <a href="/cakes" title="Order Cakes Online">

                    Online Cake Delivery

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/cakes/mumbai" title="Send Cakes to Mumbai">

                    Cake Delivery in Mumbai

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/cakes/new-delhi" title="Cake Delivery in Delhi">

                    Cake Delivery in Delhi

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/cakes/bengaluru" title="Cake Delivery in Bangalore">

                    Cake Delivery in Bangalore

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/cakes/hyderabad" title="Cake Delivery in Hyderabad">

                    Hyderabad Cakes Online

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/cakes/chennai" title="Cake Delivery in Chennai">

                    Cake Delivery in Chennai

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/cakes/pune" title="Cake Delivery in Pune">

                    Cake Delivery in Pune

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/cakes/jaipur" title="Cake Delivery in Jaipur">

                    Cake Delivery in Jaipur

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/cakes/gurgaon" title="Cake Delivery in Gurgaon">

                    Cake Delivery in Gurgaon

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/cakes/ahmedabad" title="Send Cakes to Ahmedabad">

                    Cake Delivery in Ahmedabad

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/cakes/kolkata" title="Cake Delivery in Kolkata">

                    Cake Delivery in Kolkata

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/cakes/chandigarh" title="Cake Delivery in Chandigarh">

                    Cake Delivery in Chandigarh

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/cakes/ghaziabad" title="Cake Delivery in Ghaziabad">

                    Cake Delivery in Ghaziabad

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/cakes/noida" title="Cake Delivery in Noida">

                    Cake Delivery in Noida

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/cakes/faridabad" title="Cake Delivery in Faridabad">

                    Cake Delivery in Faridabad

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/heart-shaped-cakes" title="Heart Shaped Cakes">

                    Heart Shaped Cakes

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/chocolate-cakes" title="Chocolate Cakes Online">

                    Chocolate Cakes

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/black-forest-cakes" title="Black Forest Cakes">

                    Black Forest Cake Online

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/cupcakes-dry-cakes" title="Cupcakes and Dry Cakes">

                    Cupcakes

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/strawberry-cakes" title="Strawberry Cake">

                    Strawberry Cake

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/pineapple-cakes" title="Pineapple Cakes">

                    Pineapple Cake

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/butterscotch-cakes" title="Butterscotch Cakes">

                    Butterscotch Cake

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/vanilla-cakes" title="Vanilla Cakes">

                    Vanilla Cake

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/photo-cakes" title="Photo Cakes">

                    Photo Cakes

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/designer-cakes" title="Designer Cakes">

                    Designer Cakes

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/flowers-with-cake" title="Cake and Flowers Combo">

                    Cake and Flowers Delivery

                            </a>
                </span>
                <span class="ext-footer-pipe"> | </span>
                <span class="child">
                            <a href="/q-eggless-birthday-cake" title="">

                    Eggless Birthday Cake

                            </a>
                </span>
                
    </div>



                    </div>
                </div>
<div class="d-flex">
    <div class="footer-link-list" style="width: 50%">
        <p class="footer-s-title text-center">Download IGP App:</p>
    <div class="row no-margin newsletter text-center d-flex justify-content-center" >
        <div class="" style="width: 25%">
            <a href="https://play.google.com/store/apps/details?id=com.igp.android&hl=en" target="_blank"><img class="img-responsive lazyIcons"  src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" data-original="https://cdn.igp.com/f_auto,q_auto/banners/googleStoreIcon.png" alt="youtube" onclick="onclickDataLayer('footer_click', {'item_name': 'Google Play'})"></a>
        </div>
        <div class="" style="width: 25%">
            <a href="https://apps.apple.com/us/app/igp-india-ki-gifting-site/id1470378219" target="_blank"><img class="img-responsive lazyIcons"  src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" data-original="https://cdn.igp.com/f_auto,q_auto/banners/iosStoreIcon.png" alt="youtube" onclick="onclickDataLayer('footer_click', {'item_name': 'App Store'})"></a>
        </div>
    </div>
        
    </div>
    <div class="row no-margin newsletter text-center" style="width: 50%">
                <div class="footer-link-list">
                    <p class="footer-s-title">Follow Us:</p>

                    <div class="row footer-social-row" style="padding-top: 10px;">
                        <div class="col s12">
                            <ul class="social-icons" style="margin-left:0;">
                                <li class="social-icons-item">
                                    <a href="https://www.facebook.com/MyIGP" target="_blank" onclick="onclickDataLayer('footer_click', {'item_name': 'Facebook'})">
                                        <div class="icon-wrapper social-icons-svg">
                                            <img class="img-responsive" alt="fb img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/fb.svg"></img>
                                        </div>
                                    </a>
                                </li>
                                <!--<li>-->
                                <!--<div class="icon-wrapper social-icons-svg">-->
                                <!--<svg viewBox="0 0 2 2" class="s-icon">-->
                                <!--<use xlink:href="https://cdn.igp.com/raw/upload/assets/svgs/main_v1.svg#shape-g-plus"></use>-->
                                <!--</svg>-->
                                <!--</div>-->
                                <!--</a>-->
                                <!--</li>-->
                                <li class="social-icons-item">
                                    <a href="https://twitter.com/IGPcom" target="_blank" onclick="onclickDataLayer('footer_click', {'item_name': 'Twitter'})">
                                        <div class="icon-wrapper social-icons-svg">
                                            <img class="img-responsive" alt="twitter img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/twitter.svg"></img>
                                        </div>
                                    </a>
                                </li>
                                <!--<li>-->
                                <!--<a href="http://www.pinterest.com/giftsportal" target="_blank">-->
                                <!--<div class="icon-wrapper social-icons-svg">-->
                                <!--<svg viewBox="0 0 2 2" class="s-icon">-->
                                <!--<use xlink:href="https://cdn.igp.com/raw/upload/assets/svgs/main_v1.svg#shape-pinterest"></use>-->
                                <!--</svg>-->
                                <!--</div>-->
                                <!--</a>-->
                                <!--</li>-->
                                <li class="social-icons-item">
                                    <a href="https://www.linkedin.com/company/igpcom" target="_blank" onclick="onclickDataLayer('footer_click', {'item_name': 'Linkedin'})">
                                        <div class="icon-wrapper social-icons-svg">
                                            <img class="img-responsive" alt="linkedin img" src="https://cdn.igp.com/raw/upload/assets/svg-icons/linkedin.svg"></img>
                                        </div>
                                    </a>
                                </li>

                                <li class="social-icons-item">
                                    <a href="https://www.youtube.com/channel/UCctmXlUZP2SoIy4WfZJvf1w" target="_blank" onclick="onclickDataLayer('footer_click', {'item_name': 'Youtube'})">
                                        <div class="icon-wrapper social-icons-svg">
                                            <img class="img-responsive lazyIcons"  src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" data-original="https://cdn.igp.com/raw/upload/assets/images/youtube_72.png?v=1" alt="youtube">
                                        </div>
                                    </a>
                                </li>

                                <li class="social-icons-item">
                                    <a href="https://www.instagram.com/igpcom" target="_blank" onclick="onclickDataLayer('footer_click', {'item_name': 'Instagram'})">
                                        <div class="icon-wrapper social-icons-svg">
                                            <img class="img-responsive lazyIcons" src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" data-original="https://cdn.igp.com/raw/upload/assets/images/instagram_72.png" alt="instagram">
                                        </div>
                                    </a>
                                </li>

                            </ul>
                        </div>
                        <div class="clear"></div>
                    </div>
                </div>
    </div>
</div>
            

        </div>

        <div class="clear"></div>
        <div class="footer-bottom-strip">
            <div class="row no-margin">

                <div class="col s5">
                    <div class="row no-margin">
                        <div class="col s3 no-padding">
                            <p class="b-footer-title">Secure Shopping:</p>
                        </div>

                        <div class="col s4">
                                <span>
                                    <img style="cursor:pointer;" src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" data-original="https://cdn.igp.com/raw/upload/assets/images/siteseal_gd_3_h_l_m.png" onclick="verifySeal();" class="lazyIcons" alt="SSL site seal - click to verify">
                                </span>
                        </div>
                        <div class="clear"></div>
                    </div>

                </div>
                <div class="col s2">
                    &nbsp;
                </div>

                <div class="col s5 pull-right">
                    <div class="row no-margin">
                        <div class="col s2">&nbsp;</div>
                        <div class="col s5">
                            <p class="b-footer-title pull-right">Payment Methods:</p>
                        </div>
                        <div class="col s5 no-padding" style="margin-top: 10px;">

                            <div class="col s4">
                                <i class="sprite-footer sprite-footer-visa">

                                </i>
                            </div>
                            <div class="col s4">
                                <i class="sprite-footer sprite-footer-mastercard">

                                </i>
                            </div>
                            <div class="col s4">
                                <i class="sprite-footer sprite-footer-amex">

                                </i>
                            </div>
                        </div>
                        <div class="clear"></div>
                    </div>
                </div>
            </div>
            <div class="igp-icon center">
                <img class="igpIcon lazyIcons" src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" data-original="https://cdn.igp.com/raw/upload/assets/images/IGPlogonew.png?v=2" alt="IGP Gifts India" />
                <div class="copyright-text">Copyright © 2000-2022. IGP.com. All rights reserved.</div>
            </div>
        </div>
    </footer>

    </div>
</div>
    <div class="ab_homerevamp hidden">default</div>
<!-- Merge Cart Pop up begins -->
<div class="m-cart-container z-depth-1" id="m-cart-container">
    <div class="m-cart">
        <div class="row">
            <div class="col s12">
                <p class="m-cart-text">You have products in multiple carts. What would you like to do?</p>
            </div>
        </div>
        <div class="row">
            <div class="col s6">
                &nbsp;
            </div>
            <div class="col s3 text-center">
                <a class="merge-cart m-cart-btn m-cart-cancel z-depth-1 hoverable waves-effect" data-mcart="2"
                   id="merge-cancel">Don't Merge</a>
            </div>
            <div class="col s3 text-center">
                <a class="merge-cart m-cart-btn m-cart-merge z-depth-1 hoverable waves-effect" data-mcart="1"
                   id="merge-cart">Merge</a>
            </div>
        </div>
    </div>
</div>


<!-- Merge Cart Pop up ends -->

    <!-- Push Menu Begins : Slides in from the right and pushes the content of the site to left -->

    <!-- Push Menu Ends -->

    <!-- Shopping Cart Begins -->

    <div id="cart" class="s-cart-wrapper ">
        <div class="s-cart-header">
            <p class="no-margin cart-header-content">Cart</p>
            <div class="icon-wrapper a-header-icon float-icon ip-cart-icon">
                <img class="img-responsive" src="https://cdn.igp.com/raw/upload/assets/svg-icons/cart.svg"></img>
            </div>
            <span id="close-cart" class="close-menu number">X</span>
        </div>

        <div class="s-cart-body">

            <div class="cart-list-wrapper">
                <div class="cart-list">

                    <ul class="cart-items-loading-list">

                    </ul>

                </div>
                <div class="list-nav-top"><p class="text-center"><i class="fa fa-chevron-up"></i></p></div>
                <div class="list-nav-bottom"><p class="text-center"><i class="fa fa-chevron-down"></i></p></div>
            </div>

            <div class="cart-b-content">
                <div class="row total-price">
                    <div class="col s12">
                        <p class="text-center total-price-text">Total :  <span
                                class="c-tval animated-background small-background"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>&nbsp;/-
                        </p>
                    </div>
                </div>

                <!--<div class="row cart-icons no-margin">
                    <div class="col s6">
                        <div class="bg-cart-icons">
                            <div>Secure Payments</div>
                            <div class="icon-wrapper cart-svg-icon">
                                <svg viewBox="0 0 2 2" class="">
                                    <use xmlns:xlink="http://www.w3.org/1999/xlink"
                                         xlink:href="https://cdn.igp.com/raw/upload/assets/svgs/main_v1.svg#shape-secure-payment"></use>
                                </svg>
                            </div>
                        </div>
                    </div>
                    <div class="col s6">
                        <div class="bg-cart-icons">
                            <div>Same Day Delivery</div>
                            <div class="icon-wrapper cart-svg-icon">
                                <svg viewBox="0 0 2 2" class="">
                                    <use xmlns:xlink="http://www.w3.org/1999/xlink"
                                         xlink:href="https://cdn.igp.com/raw/upload/assets/svgs/main_v1.svg#shape-same-day-b"></use>
                                </svg>
                            </div>
                        </div>
                    </div>
                </div>-->

                <div class="row cart-sugg">
                    <div class="col s12">
                        <!--<a class="checkout-btn u-case" href="/cart">Select Addons and Checkout</a>-->
                        <a class="checkout-btn u-case" href="/cart">Proceed To Checkout</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Shopping Cart Ends-->

    <!-- Shortlist layer begins -->
        <div class="slist-container z-depth-1">
            <div class="slist-header">
                <p>Shortlist</p>
                <div class="slist-close">
                    &#x2715;
                </div>

                <div class="slist-star-left">
                    <div class="icon-wrapper slist-icon sl-star-icon">
                        <img class="img-responsive" src="https://cdn.igp.com/raw/upload/assets/svg-icons/heart-2.svg"></img>
                    </div>
                </div>
            </div>
            <div class="slist-body">
                <ul class="slist-items">
                    <li class="row cart-l-item z-depth-1">
                        <div class="col s4 no-padding">
                            <div class="square-l-div-c">
                                <div class="animated-background square-l-div"></div>
                            </div>
                        </div>
                        <div class="col s8">
                            <div class="cart-info">
                                <p class="cart-item-name animated-background ">&nbsp;</p>
                                <p class="cart-item-name animated-background loading-80">&nbsp;</p>
                                <p class="cart-item-name animated-background loading-60">&nbsp;</p>
                            </div>
                        </div>
                    </li>

                    <li class="row cart-l-item z-depth-1">
                        <div class="col s4 no-padding">
                            <div class="square-l-div-c">
                                <div class="animated-background square-l-div"></div>
                            </div>
                        </div>
                        <div class="col s8">
                            <div class="cart-info">
                                <p class="cart-item-name animated-background ">&nbsp;</p>
                                <p class="cart-item-name animated-background loading-80">&nbsp;</p>
                                <p class="cart-item-name animated-background loading-60">&nbsp;</p>
                            </div>
                        </div>
                    </li>

                    <li class="row cart-l-item z-depth-1">
                        <div class="col s4 no-padding">
                            <div class="square-l-div-c">
                                <div class="animated-background square-l-div"></div>
                            </div>
                        </div>
                        <div class="col s8">
                            <div class="cart-info">
                                <p class="cart-item-name animated-background ">&nbsp;</p>
                                <p class="cart-item-name animated-background loading-80">&nbsp;</p>
                                <p class="cart-item-name animated-background loading-60">&nbsp;</p>
                            </div>
                        </div>
                    </li>
                </ul>
            </div>

        </div>

    <!-- Shortlist layer ends  -->


        <!-- Login/Sign Up Block Begins -->
        <div id="acc-menu"  class="login-block block-top ">
        </div>
        <!-- Login/Sign Up Block Ends -->

    <!-- Content Mask Begins -->

    <div id="c-mask" class="c-mask"></div>
    <div id="u-mask" class="u-mask "></div>
    <div id="h-mask" class="h-mask"></div>
    <div id="d-mask" class="d-mask"></div>
    <div id="s-mask" class="h-mask"></div>
    <div class="overlay"></div>

    <div class="sl-overlay " id="sl-overlay"></div>

    <div class="ie-mask-layer">
        <!--<img src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" data-original="https://cdn.igp.com/raw/upload/assets/images/ie-w.png?v=1" class="img-responsive" alt="ie mask" />-->
    </div>
    <!-- Content Mask Ends -->

<div id="m-mask" class="h-mask"></div>
<!-- Javascript Includes -->
    <script type="application/ld+json">
    {
    "@context": "http://schema.org",
    "@type": "Organization",
    "name" : "IGP.com",
    "url": "https://www.igp.com",
    "logo": "https://cdn.igp.com/raw/upload/assets/images/igp-logo.png",
     "sameAs" : [
    "https://www.facebook.com/myigp",
    "https://www.linkedin.com/company/igpcom",
    "https://www.instagram.com/myigp",
    "https://twitter.com/myigp"
    ],
    "telephone": "+91-(22) 4343-3333",
    "address": {
    "@type": "PostalAddress",
    "addressLocality": "Chandivali Farm Road, Andheri (E)",
    "addressRegion": "Mumbai, Maharashtra",
    "streetAddress": "Join Ventures Private Limited, Unit No A1-005/006, Wing A, Lower Ground floor, Boomerang, ",
    "postalCode": "400072"
  	}
    }
</script>
    <script type="application/ld+json">
    {
      "@context": "http://schema.org",
      "@type": "LocalBusiness",
      "name" : "IGP.com",
      "url": "https://www.igp.com",
      "logo": "https://cdn.igp.com/raw/upload/assets/images/igp-logo.png",
      "image": "https://cdn.igp.com/raw/upload/assets/images/igp-logo.png",
      "description": "IGP is Indiaís largest full-stack online gifting company, providing one of the best curated collection of gifts, flowers, cakes, hampers & personalized products for all personal occasions & festivals (both domestic & international).",
  	"telephone": "+91-(22) 4343-3333",
	"address": {
    "@type": "PostalAddress",
    "addressLocality": "Chandivali Farm Road, Andheri (E)",
    "addressRegion": "Mumbai, Maharashtra",
    "streetAddress": "Join Ventures Private Limited, Unit No A1-005/006, Wing A, Lower Ground floor, Boomerang, ",
    "postalCode": "400072"
  	}
  }
</script>

<script defer src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
<script type="text/javascript">var currencyConfig = {"INR":"Rs.","USD":"USD","CAD":"CAD","GBP":"GBP","AED":"AED","AUD":"AUD","NZD":"NZD","SGD":"SGD","EUR":"EUR","Pts":"Pts","SGC":"SGC"}, currency = "INR", cdn = {"assetsBaseURL":"https://cdn.igp.com/","assetsURL":"https://cdn.igp.com/raw/upload/assets/","bannersURL":"https://cdn.igp.com/f_auto,q_auto,t_pnoptprodlp/banners/","bannersOLDURL":"https://cdn.igp.com/f_auto,q_auto/banners/","inPageBannersURLD":"https://cdn.igp.com/f_auto,q_auto/banners/","inPageBannersURLM":"https://cdn.igp.com/f_auto,q_auto/banners/","bannersURLTMres":"https://cdn.igp.com/f_auto,q_auto,t_mres/banners/","cardsURL":"https://cdn.igp.com/f_auto,q_auto/cards/","cardsURLTMres":"https://cdn.igp.com/f_auto,q_auto,t_mres/cards/","productsURL":"https://cdn.igp.com/","productsURLTransformationF":"f_auto,q_auto,t_prodf/","productsURLTransformationL":"f_auto,q_auto,t_prodl/","productsURLTransformationM":"f_auto,q_auto,t_prodm/","productsURLTransformationMEco":"f_auto,q_auto,t_prodm/","productsURLTransformationTH":"f_auto,q_auto,t_prodth/","productsURLTransformationFNew":"f_auto,q_auto,t_pnoptprodlp/","productsURLTransformationLNew":"f_auto,q_auto,t_pnoptprodlp/","productsURLTransformationMNew":"f_auto,q_auto,t_pnoptprodlp/","productsURLTransformationMEcoNew":"f_auto,q_auto,t_pnoptprodlp/","productsURLTransformationTHNew":"f_auto,q_auto,t_pnoptprodlp/","productsURLBestSellerFlag":"g_south_east,l_tag","blogImageURL":"f_auto,q_auto,t_blogcard/blogs/","productsURLFolder1":"products/","persURL":"https://d1xs5fw35mbn8b.cloudfront.net/pers/","videoURLTransformationTH":"video/upload/q_auto,t_vth/","videoURLTransformationL":"video/upload/q_auto,t_prodl/","videoURLWatermark":"video/upload/t_vrw","videoURLWatermarkReview":"video/upload/q_auto:low","videoURL":"video/upload/t_vdl","video_bannser_URL":"https://cdn.igp.com/video/upload/f_auto,q_auto/banners/","ccsBanner":"f_auto,q_auto,t_ccstp/banners/","showcaseNanner":"f_auto,q_auto,t_cathprect/banners/"}, cdnURL = "&quot;https://d1wmfjb8yjmitg.cloudfront.net/uinewigp/&quot;", cdnURL1 = "https://d24xvrq60ees0a.cloudfront.net/myshop/", env = "production", user = "", sameDayLimit = 18, corpLabel = false, micrositename = "IGP";;cdn.assetsURL = "https://cdn.igp.com/raw/upload/assets/",cdn.bannersURL= "https://cdn.igp.com/f_auto,q_auto,t_pnoptprodlp/banners/", cdn.cardsURL = "https://cdn.igp.com/f_auto,q_auto/cards/", cdn.productsURL = "https://cdn.igp.com/", cdn.productsURLFolder1 = "products/", cdn.persURL = "https://d1xs5fw35mbn8b.cloudfront.net/pers/", dateToday = new Date("Sat Mar 12 2022 04:44:10 GMT+0000 (Coordinated Universal Time)");
var hoursPassed = dateToday.getHours();
var storeid = "5";
var isWhitelable = ["5","830"].indexOf(('' + storeid)) !== -1 ? false : true;
var isPhone = false;
</script>
<!-- chat sticky icon start -->
<div class="icon-chat chat-me">
    <span class="chatIcon">Chat</span>
</div>
<!-- chat sticky icon end -->
<!--js from hbs widgets-->
    <script defer src="https://cdn.igp.com/raw/upload/assets/passets/js/baseHomeJS-317.js"></script>
    <script defer src="https://cdn.igp.com/raw/upload/assets/passets/js/commonJS-457.js"></script>
    <script defer src="https://cdn.igp.com/raw/upload/assets/passets/js/homeJS-374.js"></script>



<!-- js form hbswidgets ends-->


<input type="text" id="uemail1" name="uemail1" value="" style="display:none;visibility:hidden"/>
<input type="text" id="uemail2" name="uemail2" value="" style="display:none;visibility:hidden"/>
<input type="text" id="uemail3" name="uemail3" value="" style="display:none;visibility:hidden"/>
<div id="cc-source" data-countrysource="" data-citysource=""></div>
<div id="user-data" data-usrc="8b580f04-6c12-4622-942a-84d098e834c4" data-userid=""></div>
</body>
</html>