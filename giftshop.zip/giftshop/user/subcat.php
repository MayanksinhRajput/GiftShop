<?php
include('conn.php');
include('hhh.php');
?>
       
         <!-- Start Category Area -->
         <section class="htc__category__area ptb--100">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12">
                        <div class="section__title--2 text-center">
                            <h2 class="title__line">Subcategory</h2>
                            
                        </div>
                    </div>
                </div>
                <div class="htc__product__container">
                    <div class="row">
                        <div class="product__list clearfix mt--30">
                            <!-- Start Single Category -->
                          
                               
                           <?php
                        $cid=$_GET['x'];
                         $q=mysqli_query($con,"select * from subcategory where cid=$cid");
                         while($row=mysqli_fetch_array($q))
                         {
                            
                        
                    ?>
                            <div class="col-md-4 col-lg-3 col-sm-4 col-xs-12">
                                <div class="category">
                                    <div class="ht__cat__thumb">
                                        
                                        <?php echo "<a href='pro.php?x=$row[0]'><image src='../admin/images/$row[photo]' height=300 width=400></a>";?>
                                        
                                    </div>
                                    
                    
                                    <div class="fr__hover__info">
                                        <ul class="product__action">
                                          
                                        </ul>
                                    </div>
                                    <div class="fr__product__inner">
                                        <h4><a href="product-details.html"><?php echo "<a href='pro.php?x=$row[0]'>".$row['subname']."</a>";?></a></h4>
                                       
                                 </div>
                                </div>
                            </div>
                            <?php
                         }
                         ?>
                            <!-- End Single Category -->
                           
                            
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- End Category Area -->
        <?php
        include('fff.php');
        ?>