<?php
        include('conn.php');
        include('hhh.php');
        ?>
               
                 <!-- Start Category Area -->
                 <section class="htc__category__area ptb--100">
                    <div class="container">
                        <div class="row">
                            <div class="col-xs-12">
                                <div class="section__title--2 text-center">
                                    <h2 class="title__line">Product</h2>
                                    
                                </div>
                            </div>
                        </div>
                        <div class="htc__product__container">
                            <div class="row">
                                <div class="product__list clearfix mt--30">
                                    <!-- Start Single Category -->
                                  
                                       
                                   <?php
                                $sid=$_GET['x'];
                                 $q=mysqli_query($con,"select * from product where sid=$sid");
                                 while($row=mysqli_fetch_array($q))
                                 {
                                    
                                
                            ?>
                                    <div class="col-md-4 col-lg-3 col-sm-4 col-xs-12">
                                        <div class="category">
                                            <div class="ht__cat__thumb">
                                                <a href="product-details.html">
                                                <?php echo "<a href='productdetail.php?x=$row[0]'><image src='../admin/images/$row[photo]' height=300 width=400></a>";?>
                                                </a>
                                            </div>
                                            
                            
                                            <div class="fr__hover__info">
                                                <ul class="product__action">
                                                    <li> <?php
                                                        echo "<a href='hidd.php?pid=$row[0]'>"?><i class="icon-heart icons"></i></a></li>
        
                                                    <li>
                                                        <?php
                                                        echo "<a href='hidden.php?pid=$row[0]'>"?><i class="icon-handbag icons"></i></a></li>
        
                                                    <li><a href="#"><i class="icon-shuffle icons"></i></a></li>
                                                </ul>
                                            </div>
                                            <div class="fr__product__inner">
                                                <h4><a href="product-details.html"><a href="product-details.html"><?php echo "<a href='productdetail.php?x=$row[0]'>".$row['pname']."</a>";?></a></h4>
                                                <ul class="fr__pro__prize">
                                            <li><?php echo $row['pprice']?></li>
                                        </ul>
                                         </div>
                                        </div>
                                    </div>
                                    <?php
                                 }
                                 ?>
                                    <!-- End Single Category -->
                                   
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <!-- End Category Area -->
                <?php
                include('fff.php');
                ?>