<?php
session_start();
include('hhh.php');

include('conn.php');
if(isset($_POST['submit']))
{
    $sotp=$_SESSION['sotp'];
    $email=$_SESSION['email'];
    echo $email;
    
    $otp=$_POST['otp'];
    if($sotp==$otp)
    {
        $q=mysqli_query($con,"update user_master set status=1 where email='$email'");
      echo "<script>window.location.assign('login.php');</script>";
    }
    else
    {
        echo"<script>alert('Check ur mail');</script>";

    }
}
?>
<form method=post>
    <input type=text name=otp><br>
    <input type=submit name=submit value="Verify">
</form>
<?php
include('fff.php');
?>