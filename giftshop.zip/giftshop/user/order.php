<?php
session_start();
include('conn.php');
include('hhh.php');
?>
 <!-- Start Bradcaump area -->
 <div class="ht__bradcaump__area" style="background: rgba(0, 0, 0, 0) url(images/bg/) no-repeat scroll center center / cover ;">
            <div class="ht__bradcaump__wrap">
                <div class="container">
                    <div class="row">
                        <div class="col-xs-12">
                            <div class="bradcaump__inner">
                                <nav class="bradcaump-inner">
                                  <a class="breadcrumb-item" href="index.html">Home</a>
                                  <span class="brd-separetor"><i class="zmdi zmdi-chevron-right"></i></span>
                                  <span class="breadcrumb-item active">checkout</span>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Bradcaump area -->
        <!-- cart-main-area start -->
        <div class="checkout-wrap ptb--100">
            <div class="container">
                <div class="row">
                    <div class="col-md-8">
                        <div class="checkout__inner">
                            <div class="accordion-list">
                                <div class="accordion">
                                    <div class="accordion__title">
                                        Address Information
                                    </div>
                                    <div class="accordion__body">
                                        <div class="bilinfo">
                                        <?php
                                            if(isset($_POST['btnins']))
                                            {
                                                $uid=$_SESSION['uid'];
                                                $uname=$_POST['txtuname'];
                                                $email=$_POST['txtemail'];
                                                $saddress=$_POST['txtsaddress'];
                                                $address=$_POST['txtaddress'];
                                                $city=$_POST['txtcity'];
                                                $pincode=$_POST['txtpincode'];
                                                $mobno=$_POST['txtmobno'];
                                                $odate=date('y/m/d');
                                                $q=mysqli_query($con,"insert into orders values('',$uid,'$uname','$email','$saddress','$address','$city','$pincode','$mobno','$odate',0)");
                                                if ($q)
                                                {
                                                    $qty1=$_SESSION['qty1'];
                                                    $qty2=$_SESSION['qty2'];
                                                    $pid=$_SESSION['pid'];
                                                    //echo $qty2 . $qty1 .$pid;
                                                    mysqli_query($con,"update product set quantity=$qty2-$qty1 where pid=$pid");
                                                    
                                                    echo  "<script>alert('Order has been added ');</script>";
                                                    echo  "<script>window.location.assign('TxnTest.php');</script>";

                                                }
                                                 else
                                                {
                                                    echo "not inserted";
                                                }
                                            }
                                        ?>

                                            <form method=post  enctype="multipart/form-data">
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="single-input">
                                                            <input type="text" placeholder="First name" name='txtuname'>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-12">
                                                        <div class="single-input">
                                                            <input type="text" placeholder="Street Address" name='txtsaddress'>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-12">
                                                        <div class="single-input">
                                                            <input type="text" placeholder="Apartment/Block/House" name='txtaddress'>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="single-input">
                                                            <input type="text" placeholder="City/State" name='txtcity'>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="single-input">
                                                            <input type="text" placeholder="Post code/ zip" name='txtpincode'>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="single-input">
                                                            <input type="email" placeholder="Email address" name='txtemail'>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="single-input">
                                                            <input type="text" placeholder="Phone number" name='txtmobno'>
                                                        </div>
                                                       
                                                    </div>
                                                    <input type=submit name=btnins value="submit" >
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                    
                                    <div class="accordion__body">
                                        
                                       
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-4">
                        <div class="order-details">
                            <h5 class="order-details__title">Your Order</h5>
                           
                            <div class="order-details__item">
                            <?php
                                        $uid=$_SESSION['uid'];
                                        $q=mysqli_query($con,"select * from cart where uid=$uid");
                                        while($row=mysqli_fetch_array($q))
                                        {
                                            $pid=$row['pid'];
                                            $q1=mysqli_query($con,"select * from product where pid=$pid");
                                            while($row1=mysqli_fetch_array($q1))
                                            {
                                        ?>
                                <div class="single-item">
                                    <div class="single-item__thumb">
                                    <?php echo "<image src='../admin/images/$row1[photo]'>";?>
                                    </div>
                                    <div class="single-item__content">
                                        <a href="#"><?php
                                                echo $row1['pname'];
                                            ?></a>
                                        <span class="price"><?php echo $row1['pprice']; ?></span>
                                    </div>
                                    <div class="single-item__remove">
                                    <?php
                                                echo "<a href='odelet.php?x=$row[0]'>";
                                                ?><i class="zmdi zmdi-delete"></i></a>
                                    </div>
                                </div>
                                <?php
                                            }
                                        }
                                        ?>
                            </div>
                            
                          <!--  <div class="order-details__count">
                           
                                <div class="order-details__count__single">
                                    <h5>sub total</h5>
                                    <span class="price"><?php echo $total=$row[$subtotal];?></span> 
                                </div>
                                <div class="order-details__count__single">
                                    <h5>Tax</h5>
                                    <span class="price">$9.00</span>
                                </div> 
                            </div> 
                            <div class="ordre-details__total">
                                <h5>Order total</h5>
                                <span class="price">$918.00</span>
                            </div> -->s
                       
                        </div>
                        
                    </div>
                   
                </div>
                
            </div>
            
        </div>
       
        <!-- cart-main-area end -->
        
                                                         
                                        
<?php
include('fff.php');
?>