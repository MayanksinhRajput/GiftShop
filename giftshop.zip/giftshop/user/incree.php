<?php
session_start();
include('conn.php');
$cartid=$_GET['cartid'];
$q=mysqli_query($con,"update cart set qty=qty+1 where cartid=$cartid");
if($q)
    header('location:addtocart.php');
else
    echo "not";
?>