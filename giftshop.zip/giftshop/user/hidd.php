<?php
include('conn.php');
session_start();
$uid=$_SESSION['uid'];

if(isset($uid))
{
    
    $pid=$_GET['pid'];
   
    $wdate=date('y/m/d');
   $q=mysqli_query($con,"insert into wishlist values('',$pid,$uid,'$wdate',1)");
   //echo "insert into whishlist values('',$pid,$uid,'$wdate',1)";
   if($q)
   {
       echo "inserted";
    echo "<script>alert('Your item has been  added into Wishlist..')</script>";
    echo "<script>window.location.assign('index.php')</script>";
   }
}
else
{
    header('location:login.php');
}
?>