<?php
include('conn.php');
include('hhh.php');
?>
 <!-- Start Bradcaump area -->
<div class="ht__bradcaump__area" style="background: rgba(0, 0, 0, 0) url(images/contact2.jpg) no-repeat scroll center center / cover ;">
            <div class="ht__bradcaump__wrap">
                <div class="container">
                    <div class="row">
                        <div class="col-xs-12">
                            <div class="bradcaump__inner">
                                <nav class="bradcaump-inner">
                                  <a class="breadcrumb-item" href="index.html">Home</a>
                                  <span class="brd-separetor"><i class="zmdi zmdi-chevron-right"></i></span>
                                  <span class="breadcrumb-item active">FAQ</span>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Bradcaump area -->
        <!-- cart-main-area start -->
        <div class="checkout-wrap ptb--100">
            <div class="container">
                <div class="row">
                    <div class="col-md-8">
                        <div class="checkout__inner">
                            <div class="accordion-list">
                                <div class="accordion">
                                <?php
                         $q=mysqli_query($con,"select * from contect_us");
                         while($row=mysqli_fetch_array($q))
                         {

                    ?>
                                    <div class="accordion__title">
                                         <?php echo $row['name'];?>
                                    </div>
                                    <div>
                                         <?php echo $row['address'];?>
                                    </div>
                                    <div>
                                        <?php echo $row['mobno'];?>
                                    </div> 
                                    <div>
                                        <?php echo $row['webaddress'];?>
                                    </div>
                                    <div>
                                        <?php echo $row['email'];?>
                                    </div>
                                    <div class="accordion__body">
                                        <div class="bilinfo">
                                        
                                            <form metod=post action="#" enctype="multipart/form-data">
                                                <div class="row">
                                                    <div class="col-md-12">
                                                
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                    
                                       
                                    </div>
                                    <?php
                         }
                         ?>
                                </div>
                            </div>
                        </div>
                    </div>
</div>
</div>
</div>
<?php
include('fff.php');
?>