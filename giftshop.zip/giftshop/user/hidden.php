<?php
include('conn.php');
session_start();
if(isset($_SESSION['uid']))
{
    $pid=$_GET['pid'];
    $uid=$_SESSION['uid'];
    $cdate=date('d/m/y');
   $q=mysqli_query($con,"insert into cart values('',$pid,$uid,'$cdate',1,0,0)");
   if($q)
   {
    echo "<script>alert('Your item has been  added into cart..')</script>";
    echo "<script>window.location.assign('index.php')</script>";
   }
}
else
{
    header('location:login.php');
}
?>