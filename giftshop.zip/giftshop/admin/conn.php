<?php
$con=mysqli_connect("localhost","root","","giftshop") or die("not onnected");
?>