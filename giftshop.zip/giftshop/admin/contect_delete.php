<?php
 include('conn.php');
 $id=$_GET['x'];
 $q=mysqli_query($con,"delete from contect_us where id=$id");
 if($q)
    header('location:contect_us.php');
else
    echo "<script>alert('not deleted');</script>";
?>