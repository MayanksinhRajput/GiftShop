<?php
include('conn.php');
$gid=$_GET['x'];
$q=mysqli_query($con,"delete from gallery_master where gid=$gid");
if($q)
    header('location:gallery_view.php');
else 
    echo"<script>alret('not deleted');</script>";
?>

