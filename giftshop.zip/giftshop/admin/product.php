<?php
include('conn.php');
include('hhh.php');
?>
<?php
if(isset($_POST['btnins']))
{


$sid=$_POST['ddlsid'];
$pname=$_POST['txtpname'];
$pdescription=$_POST['txtpdescription'];
$pprice=$_POST['txtpprice'];
$pic=$_FILES["txtpic"]["name"];
$dst="./images/".$pic;
$quantity=$_POST['txtquantity'];
$q=mysqli_query($con,"insert into product values('',$sid,'$pname','$pdescription',$pprice,'$pic',$quantity)");
if ($q)
{
    move_uploaded_file($_FILES['txtpic']['tmp_name'],$dst);
}
else
{
    echo "not inserted";
}
}
?>
<form method=post form class="form-horizontal" enctype="multipart/form-data">
    <h1>Product</h1>

<div class="form-group">
<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Select subcategory </label>
<div class="col-sm-9">
    <select name=ddlsid>
  <?php
  $q=mysqli_query($con,"select * from subcategory");
  while($row=mysqli_fetch_array($q))
  {
      echo "<option value=$row[0]>$row[2]</option>";
  }
  ?>
  </select>
</div>
</div>
<div class="form-group">
<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Product name </label>
<div class="col-sm-9">
    <input type="txt" id="form-field-1" name=txtpname placeholder="Product name" class="col-xs-10 col-sm-5" />
</div>
</div>
<div class="form-group">
<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Product description </label>
<div class="col-sm-9">
    <input type="txt" id="form-field-1" name=txtpdescription placeholder="Product description" class="col-xs-10 col-sm-5" />
</div>
</div>
<div class="form-group">
    <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Product price </label>
    <div class="col-sm-9">
        <input type="txt" id="form-field-1" name=txtpprice placeholder="Product price" class="col-xs-10 col-sm-5" />
    </div>
</div>

<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Photo </label>
        <div class="col-sm-9">
			<input type="file" id="form-field-1" name=txtpic class="col-xs-10 col-sm-5" />
		</div>
	</div>
    <div class="form-group">
<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Quantity </label>
<div class="col-sm-9">
    <input type="txt" id="form-field-1" name=txtquantity placeholder="Quantity" class="col-xs-10 col-sm-5" />
</div>
</div>
<div class="clearfix form-actions">
<div class="col-md-offset-3 col-md-9">
    <input class="btn btn-info" type="submit" name=btnins value="Submit">
    <button class="btn" type="reset">
    <i class="ace-icon fa fa-undo bigger-110"></i>
        Reset
</button>
</div>
</div>
</form>
<div class="row">
        <div class="table-header" align="center">
            Product
        </div>  
       <!-- div.table-responsive -->

        <!-- div.dataTables_borderWrap -->
        <div>
            <table id="dynamic-table" class="table table-striped table-bordered table-hover">
                <thead>
                    <tr>
                       
                        <th>Subcategoey</th>
                        <th>Product name</th>
                        <th>Product description</th>
                        <th>Product price</th>
                        <th>photo</th>
                        <th>quantity</th>
                        <th>Action</th>
                    </tr>
                </thead>

                <tbody>
                    <?php
                         $q=mysqli_query($con,"select s.*,p.* from subcategory s, product p where s.sid=p.sid" );
                         while($row=mysqli_fetch_array($q))
                         {

                    ?>
                    <tr>
                       
                        <td><?php echo $row['subname'];?></td>
                        <td><?php echo $row['pname'];?></td>
                        <td><?php echo $row['pdescription'];?></td>
                        <td><?php echo $row['pprice'];?></td>
                        <td><?php echo "<image src='../admin/images/$row[photo]' height=100 width=100>";?></td>
                        <td><?php echo $row['quantity'];?></td>
                         <td>
                            <div class="hidden-sm hidden-xs action-buttons">
                           
                               <?php 
                               echo "<a class='green' href=product_edit.php?x=$row[5]>";
                                echo "<i class='ace-icon fa fa-pencil bigger-130'></i>";
                                echo "</a>";

                               echo "<a class='red' href=product_delete.php?x=$row[5]>";
                               echo  "<i class='ace-icon fa fa-trash-o bigger-130'></i>";
                               echo" </a>";
                                 
                                ?>
                            </div>

                            <div class="hidden-md hidden-lg">
                                <div class="inline pos-rel">
                                    <button class="btn btn-minier btn-yellow dropdown-toggle" data-toggle="dropdown" data-position="auto">
                                        <i class="ace-icon fa fa-caret-down icon-only bigger-120"></i>
                                    </button>

                                    <ul class="dropdown-menu dropdown-only-icon dropdown-yellow dropdown-menu-right dropdown-caret dropdown-close">
                                    <li>
										<a href="#" class="tooltip-info" data-rel="tooltip" title="View">
											<span class="blue">
												<i class="ace-icon fa fa-search-plus bigger-120"></i>
											</span>
										</a>
									</li>
                                    <li>
										<a href="#" class="tooltip-success" data-rel="tooltip" title="Edit">
											<span class="green">
												<i class="ace-icon fa fa-pencil-square-o bigger-120"></i>
											</span>
										</a>
									</li>
																		

                                        <li>
                                            <a href=cdelete.php?x=$row[0] class="tooltip-error" data-rel="tooltip" title="Delete">
                                                <span class="red">
                                                    <i class="ace-icon fa fa-trash-o bigger-120"></i>
                                                </span>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </td>
                   </tr>
 <?php                      
                            }
 ?>
 </tbody>
         </table>
        </div>           
    </div>
</div>

<?php
include('fff.php');
?>