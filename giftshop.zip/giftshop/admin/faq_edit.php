<?php
include('hhh.php');
include('conn.php');
$id=$_GET['x'];
$q=mysqli_query($con,"select * from faq where id=$id");
$row=mysqli_fetch_array($q);
?>
<form method=post form class="form-horizontal" enctype="multipart/form-data">
	<h1>FAQ :-</h1>

    <div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Question </label>
        <div class="col-sm-9">
			<input type="txt" id="form-field-1" name=txtquestion placeholder="Question" class="col-xs-10 col-sm-5" value="<?php echo $row['question'];?>" />
		</div>
	</div>
	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Answer </label>
        <div class="col-sm-9">
			<input type="txt" id="form-field-1" name=txtanswer placeholder="Answer" class="col-xs-10 col-sm-5" value="<?php echo $row['answer'];?>" />
		</div>
	</div>
    <div class="clearfix form-actions">
		<div class="col-md-offset-3 col-md-9">
		    <input class="btn btn-info" type="submit" name=btnup value="Update">
			<button class="btn" type="reset">
			<i class="ace-icon fa fa-undo bigger-110"></i>
				Reset
		</button>
        </div>
	</div>
</form>
<?php
if(isset($_POST['btnup']))
{
   
    $question=$_POST['txtquestion'];
    $answer=$_POST["txtanswer"];
    $q=mysqli_query($con,"update faq set question='$question',answer='$answer' where id=$id");
    if($q)
    {
     echo "<script>window.location.assign('faq.php')</script>";
    }
    else
    {
        echo "not updated";
    }
}
?>
<?php
include('fff.php');
?>
