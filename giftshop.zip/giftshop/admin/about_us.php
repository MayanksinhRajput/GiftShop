<?php
include('hhh.php');
include('conn.php');
?>
<form method=post form class="form-horizontal" enctype="multipart/form-data">
	<h1>About us</h1>

    <div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Title </label>
        <div class="col-sm-9">
			<input type="txt" id="form-field-1" name=txttitle placeholder="Title" class="col-xs-10 col-sm-5" />
		</div>
	</div>
	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Description </label>
        <div class="col-sm-9">
			<input type="txt" id="form-field-1" name=txtdescription placeholder="Description" class="col-xs-10 col-sm-5" />
		</div>
	</div>
    <div class="clearfix form-actions">
		<div class="col-md-offset-3 col-md-9">
		    <input class="btn btn-info" type="submit" name=btnins value="Submit">
			<button class="btn" type="reset">
			<i class="ace-icon fa fa-undo bigger-110"></i>
				Reseto
		</button>
        </div>
	</div>
</form>
<?php
//insert
if(isset($_POST['btnins']))
{
$title=$_POST['txttitle'];
$description=$_POST['txtdescription'];
$q=mysqli_query($con,"insert into about_us values('','$title','$description')");
if ($q)
{
    
    echo"inserted";
}
else
{
    echo "not inserted";
}
}
?>
<table>
<div class="hr hr-18 dotted hr-double"></div>

<div class="row">
   
        <div class="table-header" align="center">
            About us
        </div>

        <!-- div.table-responsive -->

        <!-- div.dataTables_borderWrap -->
        <div>
            <table id="dynamic-table" class="table table-striped table-bordered table-hover">
                <thead>
                    <tr>
                       
                        <th>Ttile</th>
                        <th>Description</th>
                        <th>Action</th>
                    </tr>
                </thead>

                <tbody>
                    <?php
                         $q=mysqli_query($con,"select * from about_us");
                         while($row=mysqli_fetch_array($q))
                         {

                    ?>
                    <tr>
                        
                        <td><?php echo $row['title'];?></td>
                        <td><?php echo $row['description'];?></td>
                        <td>
                            <div class="hidden-sm hidden-xs action-buttons">
                               <?php 
                               echo "<a class='green' href=aboutus_edit.php?x=$row[0]>";
                                echo "<i class='ace-icon fa fa-pencil bigger-130'></i>";
                                echo "</a>";

                               echo "<a class='red' href=aboutus_delete.php?x=$row[0]>";
                               echo  "<i class='ace-icon fa fa-trash-o bigger-130'></i>";
                               echo" </a>";
                                 
                                ?>
                            </div>

                            <div class="hidden-md hidden-lg">
                                <div class="inline pos-rel">
                                    <button class="btn btn-minier btn-yellow dropdown-toggle" data-toggle="dropdown" data-position="auto">
                                        <i class="ace-icon fa fa-caret-down icon-only bigger-120"></i>
                                    </button>

                                    <ul class="dropdown-menu dropdown-only-icon dropdown-yellow dropdown-menu-right dropdown-caret dropdown-close">
									<li>
										<a href="#" class="tooltip-info" data-rel="tooltip" title="View">
											<span class="blue">
												<i class="ace-icon fa fa-search-plus bigger-120"></i>
											</span>
										</a>
									</li>
                                    <li>
										<a href="#" class="tooltip-success" data-rel="tooltip" title="Edit">
											<span class="green">
												<i class="ace-icon fa fa-pencil-square-o bigger-120"></i>
											</span>
										</a>
									</li>
																		

                                        <li>
                                            <a href=cdelete.php?x=$row[0] class="tooltip-error" data-rel="tooltip" title="Delete">
                                                <span class="red">
                                                    <i class="ace-icon fa fa-trash-o bigger-120"></i>
                                                </span>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </td>
                   </tr>
 <?php                      
                            }
 ?>
 </tbody>
                        </table>
        </div>           
    </div>
</div>

<?php
include('fff.php');
?>