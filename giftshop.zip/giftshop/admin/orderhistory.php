<?php
include('conn.php');
include('hhh.php');

?>
<div class="row">
        <div class="table-header" align="center">
            Orders
        </div>  
       <!-- div.table-responsive -->

        <!-- div.dataTables_borderWrap -->
        <div>
            <table id="dynamic-table" class="table table-striped table-bordered table-hover">
                <thead>
                    <tr>
                        <th>Product Name</th>
                        <th>Product Image</th>
                        <th>Quantity</th>
                        
                        <th>Total</th>
                    </tr>
                </thead>

                <tbody>
                    <?php
                        $uid=$_GET['uid'];
                        $q=mysqli_query($con,"select * from carthistory where uid=$uid");
                        while($row=mysqli_fetch_array($q))
                         {

                    ?>
                    <tr>
                    <td><?php echo $row['pname'];?></td>
                    <td><?php echo "<image src='../admin/images/$row[pimage]' height=100 width=100>";?></td>
                    <td><?php echo $row['qty'];?></td>
                     <td><?php echo $row['total'];?></td>
                        
                         
                   </tr>
 <?php                      
                            }
 ?>
 </tbody>
         </table>
        </div>           
    </div>
</div>

<?php
include('fff.php');
?>