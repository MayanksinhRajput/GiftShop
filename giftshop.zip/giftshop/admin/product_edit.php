<?php
include('hhh.php');
include('conn.php');
$pid=$_GET['x'];
$q=mysqli_query($con,"select * from product where pid=$pid");
$row=mysqli_fetch_array($q);
?>
<form method=post class="form-horizontal" enctype="multipart/form-data">
    <h1>Product</h1>
    <div class="form-group">
        <label class="col-sm-3 control-label no-padding-right"  for="form-field-1"> Select Subcategory </label>
        <div class="col-sm-9">
            <select name="ddlsid" class="col-xs-10 col-sm-5">
        <?php
        $q=mysqli_query($con,"select * from subcategory");
        while($row=mysqli_fetch_array($q))
        {
            echo "<option value=$row[0]>$row[2]</option>";
        }
        ?>
        </select>
        </div>
    </div>
<div class="form-group">
<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Product Name </label>
<div class="col-sm-9">
    <input type="text" id="form-field-1" name="txtpname" class="col-xs-10 col-sm-5" placeholder="Product name" value="<?php echo $row['pname'];?>"/>
</div>
</div>
<div class="form-group">
<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Product Description </label>
<div class="col-sm-9">
    <input type="text" id="form-field-1" name="txtpdescription" class="col-xs-10 col-sm-5" placeholder="Product Description" value="<?php echo $row['pdescription'];?>" />
</div>
</div>
<div class="form-group">
<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Product Price </label>
<div class="col-sm-9">
    <input type="text" id="form-field-1" name="txtpprice"  class="col-xs-10 col-sm-5" placeholder="Product Price" value="<?php echo $row['pprice'];?>" />

</div>
</div>

<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Photo </label>
        <div class="col-sm-9">
			<input type="file"  id="form-field-1"  name=txtpic class="col-xs-10 col-sm-5" value="<?php echo $row['photo'];?>" />
		</div>
	</div>
    <div class="form-group">
<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Quantity </label>
<div class="col-sm-9">
    <input type="text"  id="form-field-1"  name=txtquantity class="col-xs-10 col-sm-5" placeholder="Quantity" value="<?php echo $row['quantity'];?>" />
</div>
</div>
<div class="clearfix form-actions">
<div class="col-md-offset-3 col-md-9">
    <input class="btn btn-info" type="submit" name="btnup" value="Update">
    <button class="btn" type="reset">
    <i class="ace-icon fa fa-undo bigger-110"></i>
        Reset
</button>
</div>
</div>
</form>

<?php
if(isset($_POST['btnup']))
{
$sid=$_POST['ddlsid']; 
$pname=$_POST['txtpname'];
$pdescription=$_POST['txtpdescription'];
$pprice=$_POST['txtpprice'];
$pic=$_FILES["txtpic"]["name"];
$dst="./images/".$pic;
$quantity=$_POST['txtquantity'];
$q=mysqli_query($con,"update product set sid=$sid, pname='$pname',pdescription='$pdescription',pprice=$pprice,photo='$pic',quantity='$quantity' where pid=$pid");
if ($q)
{
    move_uploaded_file($_FILES['txtpic']['tmp_name'],$dst);
   echo "<script>window.location.assign('product.php')</script>";
   
}
else
{
    echo "not updated";
}
}
?>

<?php
include('fff.php');
?>