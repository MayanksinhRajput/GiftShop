<?php
 include('conn.php');
 $cid=$_GET['x'];
 $q=mysqli_query($con,"delete from category_master where cid=$cid");
 if($q)
    header('location:category_master.php');
else
    echo "<script>alert('not deleted');</script>";
?>