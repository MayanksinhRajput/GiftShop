<?php
include('hhh.php');
include('conn.php');
$id=$_GET['x'];
$q=mysqli_query($con,"select * from about_us where id=$id");
$row=mysqli_fetch_array($q);
?>
<form method=post form class="form-horizontal" enctype="multipart/form-data">
	<h1>About us:-</h1>

    <div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Title </label>
        <div class="col-sm-9">
			<input type="txt" id="form-field-1" name=txttitle placeholder="Title" class="col-xs-10 col-sm-5" value="<?php echo $row['title'];?>" />
		</div>
	</div>
	<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Description </label>
        <div class="col-sm-9">
			<input type="txt" id="form-field-1" name=txtdescription placeholder="Description" class="col-xs-10 col-sm-5" value="<?php echo $row['description'];?>"/>
		</div>
	</div>
    <div class="clearfix form-actions">
		<div class="col-md-offset-3 col-md-9">
		    <input class="btn btn-info" type="submit" name=btnup value="Submit">
			<button class="btn" type="reset">
			<i class="ace-icon fa fa-undo bigger-110"></i>
				Reset
		</button>
        </div>
	</div>
</form>

<?php
//update
if(isset($_POST['btnup']))
{
   
    $title=$_POST['txttitle'];
    $description=$_POST["txtdescription"];
    $q=mysqli_query($con,"update about_us set title='$title', description='$description' where id=$id");
    if($q)
    {
     echo "<script>window.location.assign('about_us.php')</script>";
    }
    else
    {
        echo "not updated";
    }
}
?>
<?php
include('fff.php');
?>