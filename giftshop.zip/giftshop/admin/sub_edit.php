<?php
include('hhh.php');
include('conn.php');
$sid=$_GET['x'];
$q=mysqli_query($con,"select * from subcategory where sid=$sid");
$row=mysqli_fetch_array($q);
?>
<form method=post form class="form-horizontal" enctype="multipart/form-data">

<div class="form-group">
<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Select category </label>
<div class="col-sm-9">
    <select name=ddlcid>
  <?php
  $q=mysqli_query($con,"select * from category_master");
  while($row=mysqli_fetch_array($q))
  {
      echo "<option value=$row[0]>$row[1]</option>";
  }
  ?>
  </select>
</div>
</div>
<div class="form-group">
<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Subcategory name </label>
<div class="col-sm-9">
    <input type="txt" id="form-field-1" name=txtsubname placeholder="Subcategory_name" class="col-xs-10 col-sm-5" value="<?php echo $row['subname'];?>"/>
</div>
</div>

<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Photo </label>
        <div class="col-sm-9">
			<input type="file" id="form-field-1" name=txtpic class="col-xs-10 col-sm-5" value="<?php echo $row['photo'];?>"/>
		</div>
	</div>
<div class="clearfix form-actions">
<div class="col-md-offset-3 col-md-9">
    <input class="btn btn-info" type="submit" name=btnup value="Update">
    <button class="btn" type="reset">
    <i class="ace-icon fa fa-undo bigger-110"></i>
        Reset
</button>
</div>
</div>
</form>
<?php
if(isset($_POST['btnup']))
{
$cid=$_POST['ddlcid'];
$subname=$_POST['txtsubname'];
$pic=$_FILES["txtpic"]["name"];
$dst="./images/".$pic;
$q=mysqli_query($con,"update subcategory set cid=$cid, subname='$subname', photo='$pic' where sid=$sid");
if ($q)
{
    move_uploaded_file($_FILES['txtpic']['tmp_name'],$dst);
    echo "<script>window.location.assign('subcategory.php')</script>";
}
else
{
    echo "not updated";
}
}
?>

<?php
include('fff.php');
?>
