<?php
include ('conn.php');
include('hhh.php');
?>
<div class="row">
        <div class="table-header" align="center">
            Orders
        </div>  
       <!-- div.table-responsive -->

        <!-- div.dataTables_borderWrap -->
        <div>
            <table id="dynamic-table" class="table table-striped table-bordered table-hover">
                <thead>
                    <tr>
                        <th>Order Date</th>
                        <th>Customer Name</th>
                        <th>Address</th>
                        <th>Apartment/block/house</th>
                        <th>city</th>
                        <th>Pin coad/zip</th>
                        <th>Phone No</th>
                        <th>Action</th>
                    </tr>
                </thead>

                <tbody>
                    <?php
                         $q=mysqli_query($con,"select * from orders" );
                         while($row=mysqli_fetch_array($q))
                         {

                    ?>
                    <tr>
                    <td><?php echo $row['odate'];?></td>
                        <td><?php echo $row['uname'];?></td>
                        <td><?php echo $row['saddress'];?></td>
                        <td><?php echo $row['address'];?></td>
                        <td><?php echo $row['city'];?></td>
                        <td><?php echo $row['pincode'];?></td>
                        <td><?php echo $row['mobno'];?></td>
                        <td><?php echo "<a href='orderhistory.php?uid=$row[uid]'>";?>confirm</a></td>
                    
                            
                            </div>
                        </td>
                   </tr>
 <?php                      
                            }
 ?>
 </tbody>
         </table>
        </div>           
    </div>
</div>
<?php
include ('fff.php');
?>