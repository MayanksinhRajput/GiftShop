<html>
    <body>
        <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
            Email:<input name="email" type="text"><br><br>
            Subject:<input name="subject" type="text"><br><br>
            Message:<br>
            <textarea name="message" rows="15" cols="50"></textarea><br><br>
            <input name="esubmit" type="submit">
        </form>
    </body>
</html>


<?php
    if(isset($_POST['esubmit']))
    {
    
        $to_email = $_POST['email'];
        $subject = $_POST['subject'];     //"Simple Email Test via PHP";
        $message = $_POST['message'];    //"Hi, This is test email send by";
        $headers = "From:giftsgiftshop2@gmail.com";
        
        if (mail($to_email, $subject, $message, $headers)) 
        {
            echo "Email successfully sent to $to_email...";
        }
        else 
        {
            echo "Email sending failed...";
        }
    }
?>