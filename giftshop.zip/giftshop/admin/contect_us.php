<?php 
include('hhh.php');
?>
<form method=post form class="form-horizontal" enctype="multipart/form-data">
<h1>Contact us</h1>
     <div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Name </label>
        <div class="col-sm-9">
			<input type="text" id="form-field-1" name=txtname placeholder="Name" class="col-xs-10 col-sm-5" />
		</div>
	</div>
    <div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Address </label>
        <div class="col-sm-9">
			<input type="text" id="form-field-1" name=txtaddress placeholder="Address" class="col-xs-10 col-sm-5" />
		</div>
	</div>
    <div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Mobile no </label>
        <div class="col-sm-9">
			<input type="text" id="form-field-1" name=txtmobileno placeholder="mobile no" class="col-xs-10 col-sm-5" />
		</div>
	</div>
    <div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Webaddress </label>
        <div class="col-sm-9">
			<input type="text" id="form-field-1" name=txtwebaddress placeholder="Webaddress" class="col-xs-10 col-sm-5" />
		</div>
	</div>
    <div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Email </label>
        <div class="col-sm-9">
			<input type="email" id="form-field-1" name=txtemail placeholder="email" class="col-xs-10 col-sm-5" />
		</div>
	</div>
    <div class="clearfix form-actions">
		<div class="col-md-offset-3 col-md-9">
		    <input class="btn btn-info" type="submit" name=btnins value="Submit">
            <button class="btn" type="reset">
			<i class="ace-icon fa fa-undo bigger-110"></i>
				Reset
		</button>
         </div>
        
</div>

</form>
<?php
//connection
  include('conn.php');
//insert
if(isset($_POST['btnins']))
{
$name=$_POST['txtname'];
$address=$_POST['txtaddress'];
$mobno=$_POST['txtmobileno'];
$webaddress=$_POST['txtwebaddress'];
$email=$_POST['txtemail'];
$q=mysqli_query($con,"insert into contect_us values('','$name','$address','$mobno','$webaddress','$email')");
if ($q)
{
    echo"inserted";
}
else
{
    echo "not inserted";
}
}
?>
<table>
<div class="hr hr-18 dotted hr-double"></div>

<div class="row">
  
        <div class="table-header" align="center">
            Contact us
        </div>

        <!-- div.table-responsive -->

        <!-- div.dataTables_borderWrap -->
        <div>
            <table id="dynamic-table" class="table table-striped table-bordered table-hover">
                <thead>
                    <tr>
                       
                        <th>Name</th>
                        <th>Address</th>
                        <th>Mobile no</th>
                        <th>Webaddress</th>
                        <th>Email</th>
                        <th>Acion</th>
                    </tr>
                </thead>

                <tbody>
                    <?php
                         $q=mysqli_query($con,"select * from contect_us");
                         while($row=mysqli_fetch_array($q))
                         {

                    ?>
                    <tr>
                        
                        <td><?php echo $row['name'];?></td>
                        <td><?php echo $row['address'];?></td>
                        <td><?php echo $row['mobno'];?></td>
                        <td><?php echo $row['webaddress'];?></td>
                        <td><?php echo $row['email'];?></td>
                        <td>
                            <div class="hidden-sm hidden-xs action-buttons">
                               <?php 
                               echo "<a class='green' href=contect_edit.php?x=$row[0]>";
                                echo "<i class='ace-icon fa fa-pencil bigger-130'></i>";
                                echo "</a>";

                               echo "<a class='red' href=contect_delete.php?x=$row[0]>";
                               echo  "<i class='ace-icon fa fa-trash-o bigger-130'></i>";
                               echo" </a>";
                                 
                                ?>
                            </div>

                            <div class="hidden-md hidden-lg">
                                <div class="inline pos-rel">
                                    <button class="btn btn-minier btn-yellow dropdown-toggle" data-toggle="dropdown" data-position="auto">
                                        <i class="ace-icon fa fa-caret-down icon-only bigger-120"></i>
                                    </button>

                                    <ul class="dropdown-menu dropdown-only-icon dropdown-yellow dropdown-menu-right dropdown-caret dropdown-close">
									<li>
										<a href="#" class="tooltip-info" data-rel="tooltip" title="View">
											<span class="blue">
												<i class="ace-icon fa fa-search-plus bigger-120"></i>
											</span>
										</a>
									</li>
                                    <li>
										<a href="#" class="tooltip-success" data-rel="tooltip" title="Edit">
											<span class="green">
												<i class="ace-icon fa fa-pencil-square-o bigger-120"></i>
											</span>
										</a>
									</li>
																		

                                        <li>
                                            <a href=cdelete.php?x=$row[0] class="tooltip-error" data-rel="tooltip" title="Delete">
                                                <span class="red">
                                                    <i class="ace-icon fa fa-trash-o bigger-120"></i>
                                                </span>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </td>
                   </tr>
 <?php                      
                            }
 ?>
 </tbody>
                        </table>
        </div>           
    </div>
</div>

<?php
include('fff.php');
?>