
<?php
	include('hhh.php');
 	//$con=mysqli_connect("localhost","root","","onlineforum");
	 include('conn.php');
?>
<style>
#a7
{
	border-style: solid;
	margin: 60px;
	padding: 20px;
	width: 300px;
	height: 200px;	
	padding-top: 20px;
    border-radius: 30px;	

}
</style>
<h1><b>Dashboard</b></h1>
<table bgcolor="pink" height="200" width="1000" cellspacing="7" cellspacing="7" border="0">

	<form method="post">
		<tr align="center">
			<td bgcolor="skyblue" width="180" id=a7><img src='images/user.png'/width='80'height='80'></br><b>Total User</b></br>
			<?php
				$q=mysqli_query($con,"select * from registration");
				$u=mysqli_num_rows($q);
				echo $u;
			?>
			</br><hr><a href="UserMastervieww.php"></a></td>&nbsp;
			<td bgcolor="lightgreen" width="180" id=a7><img src='images/category.png'/width='80'height='80'></br><b>Category</b></br>
            <?php
                                                        $q=mysqli_query($con,"select * from category_master");
                                                        $cnt=mysqli_num_rows($q);
                                                        echo $cnt;
                                                    
			?>
			</br><hr><a href="category_master.php">View Details</a></td>&nbsp;
			<td bgcolor="orange" width="180" id=a7><img src='images/subcategory.webp'/width='80'height='80'></br><b>Subcategory</b></br>
            <?php
                                                         $q=mysqli_query($con,"select * from subcategory");
                                                         $cnt=mysqli_num_rows($q);
                                                         echo $cnt;
                                                         ?>
			</br><hr><a href="subcategory.php">View Details</a></td>&nbsp;
			<td bgcolor="red" width="180" id=a7><img src='images/product.png'/width='80'height='80'></br><b>Product</b></br>
            <?php
                                                         $q=mysqli_query($con,"select * from product");
                                                         $cnt=mysqli_num_rows($q);
                                                         echo $cnt;
                                                    ?>
			</br><hr><a href="product.php">View Details</a></td>&nbsp;

		</tr>
	</form>
</table>
<?php
include('fff.php');
?>
