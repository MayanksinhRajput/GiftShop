<?php
include('hhh.php');
include('conn.php');
?>

<form method=post form class="form-horizontal" enctype="multipart/form-data">
<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Select Product </label>
    <select name=ddlpid>
   
  <?php
  $q=mysqli_query($con,"select * from product");
  while($row=mysqli_fetch_array($q))
  {
      echo "<option value=$row[0]>$row[2]</option>";
  }
  ?>
  </select>
 
		<input type=submit class="btn btn-sm btn-info no-radius" name=btnview value="View">
    </form>
    <br>
    <html>
<head>
<style>
div.gallery {
  margin: 5px;
  border: 1px solid #ccc;
  float: left;
  width: 180px;
}

div.gallery:hover {
  border: 1px solid #777;
}

div.gallery img {
  width: auto;
  height: 100%;;
}

div.desc {
  padding: 15px;
  text-align: center;
}
</style>
</head>
<body>
<div class="container">
  <div class="row">
  
  <?php
    if(isset($_POST['btnview']))
    {
        $pid=$_POST['ddlpid'];
      //  $gid=$_GET['y'];
        $q=mysqli_query($con,"select * from gallery_master  where pid=$pid");
        while($row=mysqli_fetch_array($q))
        {
            echo "<div class='col-sm-4' >";
            echo "<br><image src='images/$row[photo]' height=300 width=300><br>";
            echo "<a href=gallery_delete.php?x=$row[0]>DELETE</a>";
            echo "</div>";
        }
                      
    }
 ?>

</div>
 
</div>               
<?php
 include('fff.php');
?>