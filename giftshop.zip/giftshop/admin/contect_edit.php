<?php
include('hhh.php');
include('conn.php');
$id=$_GET['x'];
$q=mysqli_query($con,"select * from contect_us where id=$id");
$row=mysqli_fetch_array($q);
?>
<form method=post form class="form-horizontal" enctype="multipart/form-data">
     <div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Name </label>
        <div class="col-sm-9">
			<input type="text" id="form-field-1" name=txtname placeholder="Name" class="col-xs-10 col-sm-5" value="<?php echo $row['name'];?>" />
		</div>
	</div>
    <div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Address </label>
        <div class="col-sm-9">
			<input type="text" id="form-field-1" name=txtaddress placeholder="Address" class="col-xs-10 col-sm-5" value="<?php echo $row['address'];?>"  />
		</div>
	</div>
    <div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Mobile no </label>
        <div class="col-sm-9">
			<input type="text" id="form-field-1" name=txtmobileno placeholder="mobile no" class="col-xs-10 col-sm-5" value="<?php echo $row['mobno'];?>"  />
		</div>
	</div>
    <div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Webaddress </label>
        <div class="col-sm-9">
			<input type="text" id="form-field-1" name=txtwebaddress placeholder="Webaddress" class="col-xs-10 col-sm-5" value="<?php echo $row['webaddress'];?>"  />
		</div>
	</div>
    <div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Email </label>
        <div class="col-sm-9">
			<input type="email" id="form-field-1" name=txtemail placeholder="email" class="col-xs-10 col-sm-5" value="<?php echo $row['email'];?>" />
		</div>
	</div>
    <div class="clearfix form-actions">
		<div class="col-md-offset-3 col-md-9">
		    <input class="btn btn-info" type="submit" name=btnup value="Update">
            <button class="btn" type="reset">
			<i class="ace-icon fa fa-undo bigger-110"></i>
				Reset
		</button>
         </div>
        
</div>

</form>
<?php
//update
if(isset($_POST['btnup']))
{
   
    $name=$_POST['txtname'];
    $address=$_POST["txtaddress"];
    $mobno=$_POST['txtmobileno'];
    $webaddress=$_POST['txtwebaddress'];
    $email=$_POST['txtemail'];
    $q=mysqli_query($con,"update contect_us set name='$name',address='$address',mobno='$mobno',webaddress='$webaddress',email='$email' where id=$id");
    if($q)
    {
     echo "<script>window.location.assign('contect_us.php')</script>";
    }
    else
    {
        echo "not updated";
    }
}
?>
<?php
include('fff.php');
?>