<?php
include('hhh.php');
include('conn.php');
?>
<?php
if(isset($_POST['btnins']))
{


$pid=$_POST['ddlpid'];
$pic=$_FILES["txtpic"]["name"];
$dst="./images/".$pic;
$q=mysqli_query($con,"insert into gallery_master values('',$pid,'$pic')");
if ($q)
{
    move_uploaded_file($_FILES['txtpic']['tmp_name'],$dst);
}
else
{
    echo "not inserted";
}
}
?>
<form method=post form class="form-horizontal" enctype="multipart/form-data">
    <h1>Gallery</h1>

<div class="form-group">
<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Select Product </label>
<div class="col-sm-9">
    <select name=ddlpid>
  <?php
  $q=mysqli_query($con,"select * from product");
  while($row=mysqli_fetch_array($q))
  {
      echo "<option value=$row[0]>$row[2]</option>";
  }
  ?>
  </select>
</div>
</div>

<div class="form-group">
		<label class="col-sm-3 control-label no-padding-right" for="form-field-1"> Photo </label>
        <div class="col-sm-9">
			<input type="file" id="form-field-1" name=txtpic class="col-xs-10 col-sm-5" />
		</div>
	</div>
    <div class="form-group">
<div class="clearfix form-actions">
<div class="col-md-offset-3 col-md-9">
    <input class="btn btn-info" type="submit" name=btnins value="Submit">
    <button class="btn" type="reset">
    <i class="ace-icon fa fa-undo bigger-110"></i>
        Reset
</button>
<a href="gallery_view.php">
<input class="btn btn-info" type="view" name=btnview value="View" >
</a>
</div>
</div>
</form>
<?php
include('fff.php');
?>
