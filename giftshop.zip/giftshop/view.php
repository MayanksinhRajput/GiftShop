<?php
//view
    $q=mysqli_query($con,"select * from category_master");
    echo "<table align=center border=1>";
    echo "<th>cid";
    echo "<th>Category";
    echo "<th>photo";
    echo "<th colspan=2>action";
    while($row=mysqli_fetch_array($q))
    {
        echo "<tr>";
        echo "<td>".$row['cid'];
        echo "<td>".$row['cname'];
        echo "<td><image src='images/$row[2]' height=100 width=100>";
        echo"<td><a href=cedit.php?x=$row[0]><image src=images/edit.jpg height=30 width=30></a>";
        echo"<td><a href=cdelete.php?x=$row[0]><image src=images/delete.jpg height=30 width=30></a>";
        echo "</tr>";
    }
    echo "</table>";
?>