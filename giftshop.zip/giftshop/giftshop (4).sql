-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 15, 2022 at 06:44 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 7.3.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `giftshop`
--

-- --------------------------------------------------------

--
-- Table structure for table `about_us`
--

CREATE TABLE `about_us` (
  `id` int(11) NOT NULL,
  `title` varchar(50) NOT NULL,
  `description` varchar(5000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `about_us`
--

INSERT INTO `about_us` (`id`, `title`, `description`) VALUES
(1, 'flowers', 'online flower and ');

-- --------------------------------------------------------

--
-- Table structure for table `category_master`
--

CREATE TABLE `category_master` (
  `cid` int(11) NOT NULL,
  `cname` varchar(30) NOT NULL,
  `photo` varchar(30) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `category_master`
--

INSERT INTO `category_master` (`cid`, `cname`, `photo`, `status`) VALUES
(11, 'Cake', 'ca.jpg', 0),
(13, 'Greeting Card', 'greeting card.png', 0),
(15, 'Flower', 'flower.png.jpeg', 0);

-- --------------------------------------------------------

--
-- Table structure for table `contect_us`
--

CREATE TABLE `contect_us` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `address` varchar(1000) NOT NULL,
  `mobno` varchar(100) NOT NULL,
  `webaddress` varchar(1000) NOT NULL,
  `email` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `faq`
--

CREATE TABLE `faq` (
  `id` int(11) NOT NULL,
  `question` varchar(2000) NOT NULL,
  `answer` varchar(2000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `faq`
--

INSERT INTO `faq` (`id`, `question`, `answer`) VALUES
(1, 'krina', 'dmfbmbgghmgmbb k');

-- --------------------------------------------------------

--
-- Table structure for table `gallery_master`
--

CREATE TABLE `gallery_master` (
  `gid` int(11) NOT NULL,
  `pid` int(11) NOT NULL,
  `photo` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `gallery_master`
--

INSERT INTO `gallery_master` (`gid`, `pid`, `photo`) VALUES
(1, 5, 'p-frosty-chocolate-cake-half-kg--16983-m.png'),
(3, 5, 'p-frosty-chocolate-cake-half-kg--16983-m.png'),
(4, 8, '6b120c0d-690e-46c3-93e3-28cb51f971e4.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `pid` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `pname` varchar(50) NOT NULL,
  `pdescription` varchar(500) NOT NULL,
  `pprice` int(11) NOT NULL,
  `photo` varchar(50) NOT NULL,
  `quantity` int(11) NOT NULL,
  `pstatus` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`pid`, `sid`, `pname`, `pdescription`, `pprice`, `photo`, `quantity`, `pstatus`) VALUES
(5, 15, 'Frosty Chocolate Cake', 'This frosty chocolate cake will be the perfect token of love and best wishes to your dear ones. This delicious half kg chocolate cake is covered with yummy chocolate frosting, which makes it absolutely delectable in taste.', 595, 'p-frosty-chocolate-cake-half-kg--16983-m.png', 1, 0),
(8, 15, 'Unicorn Chocolate Heart Pinata Cake', 'Celebrate your amazing love story with delicious sweetness. Enjoy the day with this awesome 750gms cake in chocolate flavour. Smash your way into each others heart with Valentine special unicorn garnish and icing.', 1499, '6b120c0d-690e-46c3-93e3-28cb51f971e4.jpg', 1, 0),
(9, 15, 'Chocolate Fudge Brownie Cake', 'Everyone loves a good Chocolate Fudge Brownie Cake in Half Kg - its comforting, delicious and well Chocolatey. What make this Moreish Chocolate Fudge Brownie Cake special than any other cake is the layering of milk chocolate and dark chocolate on a warm brownie baked to perfection. ', 645, 'cak.pnj.png', 1, 0),
(10, 15, ' Pink Chocolate Pinata Ball Cake for Birthday ', 'Happiness on birthday comes in pink with the Pinata Ball Cake for Birthday available in 750 gram. Its outer shell looks like marble. Break it, and let a delicious floral-surprise cake greet you. Its all chocolate, comes with hammer, and a tag . Makes a perfect surprise.', 1499, 'pinata ball.png', 1, 0),
(11, 18, 'Chocolate Cupcakes', 'Get your sweet dose of a rich and premium chocolatey affair with these delicious Cupcakes meant to make celebrations better and tastier; this pack of six is meant to be shared but who cares, on a special day, you can devour them all and commit a chocolatey sin.', 645, 'chocolate cupcke.png', 6, 0),
(12, 18, 'Vanilla Cupcakes', ' These perfectly splendid and uber delicious Vanilla Cupcakes  are here to cheer one up. Send this along with your warm wishes to your dearest and receive bounty affection in return, they are also good for an indulgent self-love day.', 645, 'vanilla cupckes.png', 6, 0),
(13, 19, 'Birthday Wishes Personalized Greeting Card', 'The best way to wish someone on birthday is with a Happy birthday personalized card with good wishes for the special day. The card has Happy Birthday with birthday accessories made on it. The inside of the card has a personalized picture with a lovely message for the birthday person.', 345, 'birthday card.png.png', 3, 0),
(14, 19, 'Personalized Birthday Card', 'A Birthday Greeting Card with a quirky message. Give your blessings to the one on their special day by literally saying it with this card. The bright and lively blue color of this card will surely cheer them up.', 345, 'birthday card2.png', 3, 0),
(15, 20, 'Happy Anniversary Personalized Greeting Card', 'Express your beautiful journey of marriage to your lifeline on anniversary day with a personalized happy anniversary card. The card has an animated couple on the with pink hearts around. A personalized picture of the couple with an anniversary message is inside the card.', 138, 'anniversary card1.png', 6, 0),
(16, 20, 'Personalized Anniversary Card', 'Express your beautiful journey of marriage to your lifeline on anniversary day with a personalized happy anniversary card. The couple photo and heart around the photo. A personalized picture of the couple with an anniversary message is inside the card.', 129, 'anniversary card 2.png', 6, 0),
(17, 14, 'Box Of Romantic Roses', 'Red roses are the perfect representation of love, romance, passion, joy and admiration. Convey it to your Valentine with this reusable keepsake box that comes with a bouquet of pretty red roses. A super romantic gift for him/her.', 395, 'roses.png', 6, 0),
(18, 14, 'Dream a Little', 'The enchantment of roses can hardly be matched. Like a dream, full of hope, aspiration and positivity, this bouquet of blush pink roses and gypsos come together in a joyful union making it a sight of sheer happiness.', 1845, 'ros.png', 20, 0),
(19, 14, 'Beautiful Bunch of 15 White Roses', 'This is a flawless gift for a very important person in your life. This bouquet comprises of 15 pristine white roses hand-tied in a tissue wrapping. White is symbolic of grace, elegance, peace and purity. Convey these messages through these gorgeous blooms and be appreciated for the gesture.', 645, 'bouquet of white carnations.webp', 15, 0),
(20, 14, 'Radiant Yellow Rose Arrangement', 'Sprinkle sunshine like confetti on a dear ones special occasion with this Radiant Yellow Roses Bouquet. These bright yellow summer flowers are beautifully arranged in the a handmade basket for unmatched luxury.', 995, 'yellow.png', 18, 0),
(21, 14, 'Assorted Roses in a Vase', 'We all know that the Earth laughs in flowers and this beautiful floral arrangement in a stunning glass vase speaks elegance in a subtle way Assorted Roses handpicked with love, this bouquet will be extra special for a loved one.', 745, 'assorted roses.png', 10, 0),
(22, 21, 'Bouquet of Pink Carnations in Heart-shaped Box', 'Confess love gently to the person your heart admires with the Bouquet of Pink Carnations in Heart-shaped Box. The beautiful pastel pink Roses are carefully placed in the heart-shaped box and tied with a Ribbon to create a persona of innocent love.', 2195, 'pink carnations.png', 30, 0),
(23, 21, 'Bouquet of Red Carnations', 'Spelling love all around is the smashing ensemble of aesthetics- the Bouquet of Red Carnations. These freshly bloomed glorious Red Carnations hand-tied in a Tissue wrapping with Ribbon is perfect for speaking the language of new love or reviving the existing one by spicing it up.', 1745, 'red-carnation.png', 25, 0),
(24, 22, 'Bunch of 10 Pink Oriental Lilies in Tissue', 'Make the moment memorable for a dear one on a special occasion with this awesome gift. This gift contains exotic and fresh pink lilies bundled together in a bouquet. The bouquet with 10 pristine lilies looks even more stunning with tissue wrapping and ribbon on it.', 2595, 'pink lilies.png', 10, 0),
(25, 22, 'Bunch of Beautiful Orange Asiatic Lilies', 'This gift comprising of vibrant orange coloured lilies in a bouquet is beauty at its best These freshly hand-tied lilies in a tissue wrapping and ribbon make a perfect gift for anyone you admire. There are 6 stems of lilies that are freshly picked to create in this bouquet.', 1595, 'orange lilies.png', 6, 0),
(26, 22, 'Emanating Desire', 'Light up a celebration with lilies, and exotic Oriental lilies at that. A sight of grace and elegance, this arrangement includes white oriental Lilies, green Erica Palms and green Kamini for fillers. These fragrant Lilies are put together in a blue Nigella vase.', 2895, 'white liles.png', 15, 0),
(27, 22, 'Bunch of 6 Yellow Asiatic Lilies', 'This gift is complete bliss and a breath of fresh air. The gift comprises of fresh and vibrant yellow lilies arranged in a tissue wrapping and tied with a ribbon. The bouquet holds 6 stems together and makes a perfect gift for all the special people you wish to delight.', 1595, 'yellow liles.png', 6, 0),
(28, 23, 'Elegant Purple Orchids Ribbon Bouquet', 'The queen of all flowers, orchids, beautifully assemble in this coastal blue bouquet to bring the serenity and freshness of natures most beautiful blooms. Purple orchids paired with blue wrapping and satiny ribbons present the most delicate emotions in the most enchanting way on any special occasion.', 545, 'perple orchids.png', 3, 0),
(29, 23, 'Bunch of 10 White Orchids', 'This is a beautiful flower arrangement of exquisite white orchids and it makes a perfect flower gift, regardless of the occasion. The number of stems in the arrangement is 10 and it has been wrapped in a tissue paper, tied with a glossy ribbon.', 1195, 'white orchids.png', 10, 0),
(30, 24, 'Bouquet of 10 Pink Gerberas', 'Surprise your loved ones with these vivid and lively Gerberas. This bunch consists of ten pink Gerberas which will brighten up anyones day, not to mention the joy that it brings along.', 645, 'pink garberas.png', 10, 0),
(31, 24, 'Bunch of 10 Red Gerberas', 'Red Gerberas are considered as the most beautiful flowers one can ever gift to someone. Freshly plucked, richly colored and heavenly fragrant, this bunch of red gerberas are sure to lend that special feel to dear ones, when presented.', 595, 'red gerberas.png', 10, 0),
(32, 24, 'Glass Vase Arrangement of 10 Orange Gerberas', 'This bouquet of 10 orange gerberas is the best gift when it comes to expressing ones feeling of love, warmth and affection towards the other. Orange, being a very bold color, represents and happiness.', 695, 'orangegerberas.png', 10, 0),
(33, 25, 'Pink Lily Roses and Carnations Arranged in a Ribbo', 'L for love, L for lilies, and L for a lovely bouquet blooming with Pink Lilly Roses and Carnations. The elegance and sophistication of this natures surprise makes your special occasion turn truly grand and remarkable. Perfect for gifting.', 2995, 'p-pink-lily-roses-carnations.png', 38, 0),
(34, 25, 'Blooming Tales in a Vase', 'Give the recipient and their home a beautiful surprise with this luxe handpicked collection of blush pink roses and white roses, white disbud, purple alstroemeria and lavender ferns arranged in a vintage white ceramic vase for a sophisticated display.', 2095, 'blooming-tales.png', 22, 0),
(35, 26, 'Divine Black Forest Cake', 'Savour the only happiness in life: being in love and being loved with a Valentines Black Forest Heart Cake in Half Kg. The rich and moist Valentine Black Forest Heart Half kg Cake is cut above the rest with fresh whipped cream, bouncy Chocolate Cake and delectable Chocolate Shavings.', 645, 'p-divine-black-forest.png', 1, 0),
(36, 26, 'Black Forest Heart Cake', 'Turn any celebration into a fun filled and memorable one with this delicious heart shaped mouth watering Half Kg black forest cake. This spongy and succulent cake is decorated with white and chocolate icing along with crushed chocolates and glazed red cherries', 695, 'p-black-forest-heart-cake-half-kg--94104-m.png', 1, 0),
(37, 27, 'Classic Butterscotch Cake', 'A little this, a little that, Butterscotch Cake garnished with stripes of chocolate ganache and uncountable butterscotch chips, this sensational Cake offers an exotic explosion of flavors that will imprint on your palate.', 595, 'p-classic-butterscotch-cake-half-kg--109215-m.png', 1, 0),
(38, 27, 'Butterscotch Swirl Cake', 'When you want a soft and creamy butterscotch cake to turn heads, add a swirl to it with flair. This delicious layered cake has a swirl icing and soft whipped cream as garnish. Enjoy the half kg fresh cream cake on your special day.', 645, 'p-butterscotch-swirl-cake-half-kg--145985-m.png', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `aid` int(11) NOT NULL,
  `aname` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `photo` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`aid`, `aname`, `email`, `password`, `photo`) VALUES
(1, 'abc', 'a@gmail.com', '123', 'pinata ball.png');

-- --------------------------------------------------------

--
-- Table structure for table `subcategory`
--

CREATE TABLE `subcategory` (
  `sid` int(11) NOT NULL,
  `cid` int(11) NOT NULL,
  `subname` varchar(50) NOT NULL,
  `photo` varchar(50) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `subcategory`
--

INSERT INTO `subcategory` (`sid`, `cid`, `subname`, `photo`, `status`) VALUES
(14, 15, 'Roses', 'download.png', 0),
(15, 11, 'Chocolate Cake', 'Capture.jpg', 0),
(18, 11, 'Cup Cake', 'cupcakes.png', 0),
(19, 13, 'Birthday Card', 'birthday card.jpg', 0),
(20, 13, 'Anniversary Card', 'anniversary card.png.jpg', 0),
(21, 15, 'Caranation', 'carnations.png', 0),
(22, 15, 'liles', 'pink lily.png', 0),
(23, 15, 'Orchids', 'orchida.png', 0),
(24, 15, 'Gerberas', 'gerbera.png', 0),
(25, 15, 'Exotic Flowers', 'exotic flowers.png', 0),
(26, 11, 'Black Forest', 'black forest.png', 0),
(27, 11, 'Butterscotch Cake', 'butter scotch.png', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `about_us`
--
ALTER TABLE `about_us`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category_master`
--
ALTER TABLE `category_master`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `contect_us`
--
ALTER TABLE `contect_us`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `faq`
--
ALTER TABLE `faq`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gallery_master`
--
ALTER TABLE `gallery_master`
  ADD PRIMARY KEY (`gid`),
  ADD KEY `pid` (`pid`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`pid`),
  ADD KEY `sid` (`sid`);

--
-- Indexes for table `registration`
--
ALTER TABLE `registration`
  ADD PRIMARY KEY (`aid`);

--
-- Indexes for table `subcategory`
--
ALTER TABLE `subcategory`
  ADD PRIMARY KEY (`sid`),
  ADD KEY `cid` (`cid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `about_us`
--
ALTER TABLE `about_us`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `category_master`
--
ALTER TABLE `category_master`
  MODIFY `cid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `contect_us`
--
ALTER TABLE `contect_us`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `faq`
--
ALTER TABLE `faq`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `gallery_master`
--
ALTER TABLE `gallery_master`
  MODIFY `gid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `registration`
--
ALTER TABLE `registration`
  MODIFY `aid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `subcategory`
--
ALTER TABLE `subcategory`
  MODIFY `sid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `gallery_master`
--
ALTER TABLE `gallery_master`
  ADD CONSTRAINT `pid` FOREIGN KEY (`pid`) REFERENCES `product` (`pid`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `product`
--
ALTER TABLE `product`
  ADD CONSTRAINT `product_ibfk_1` FOREIGN KEY (`sid`) REFERENCES `subcategory` (`sid`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `subcategory`
--
ALTER TABLE `subcategory`
  ADD CONSTRAINT `subcategory_ibfk_1` FOREIGN KEY (`cid`) REFERENCES `category_master` (`cid`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
